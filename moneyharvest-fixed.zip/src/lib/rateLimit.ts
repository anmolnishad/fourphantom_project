// Simple in-memory sliding-window rate limiter (per instance).
// Suitable for a single-node deployment; swap for Redis in production clusters.

interface Bucket {
  timestamps: number[]
}

const buckets = new Map<string, Bucket>()

/**
 * Returns true if the request is allowed, false if rate limit exceeded.
 * @param key unique key e.g. "chat:1.2.3.4"
 * @param limit max requests in the window
 * @param windowMs window length in ms
 */
export function rateLimit(key: string, limit: number, windowMs: number): { allowed: boolean; retryAfterSec: number } {
  const now = Date.now()
  const bucket = buckets.get(key) || { timestamps: [] }
  bucket.timestamps = bucket.timestamps.filter((t) => now - t < windowMs)
  if (bucket.timestamps.length >= limit) {
    const oldest = bucket.timestamps[0]
    buckets.set(key, bucket)
    return { allowed: false, retryAfterSec: Math.max(1, Math.ceil((windowMs - (now - oldest)) / 1000)) }
  }
  bucket.timestamps.push(now)
  buckets.set(key, bucket)
  if (buckets.size > 5000) {
    // opportunistic cleanup
    for (const [k, v] of buckets) {
      if (v.timestamps.every((t) => now - t > windowMs)) buckets.delete(k)
    }
  }
  return { allowed: true, retryAfterSec: 0 }
}

export function getClientIp(req: NextRequestLike): string {
  const fwd = req.headers.get('x-forwarded-for')
  if (fwd) return fwd.split(',')[0].trim()
  return req.headers.get('x-real-ip') || 'local'
}

interface NextRequestLike {
  headers: { get(name: string): string | null }
}
