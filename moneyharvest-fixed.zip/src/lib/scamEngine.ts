// ============================================================================
// Money Harvest — Preliminary Scam Heuristic Engine
// ----------------------------------------------------------------------------
// DOCUMENTED SCORING METHOD (v1):
// Each detector below has a fixed weight reflecting how strongly it correlates
// with documented financial-scam patterns (RBI, SEBI, and National Cyber Crime
// Reporting Portal public advisories). Signals are case-insensitive, matched
// once each (no double counting), and summed into a 0–100+ raw score:
//   0–24  -> "Low Indicated Risk"   (no documented red flags found)
//   25–49 -> "Suspicious"           (multiple moderate warning signs)
//   50+   -> "High Risk"            (strong scam patterns detected)
// A low score is NOT proof of safety — see mandatory limitations in the report.
// If SCAM_INTEL_API_KEY is configured, URL reputation checks would run too;
// when absent, results are explicitly labelled as heuristic-only.
// ============================================================================

export interface Finding {
  code: string
  title: string
  weight: number
  evidence: string[]
  explanation: string
  whatToDo: string
}

export interface ScanResult {
  riskLabel: 'Low Indicated Risk' | 'Suspicious' | 'High Risk'
  riskScore: number
  findings: Finding[]
  recommendations: string[]
  reportingResources: { name: string; detail: string; url: string }[]
  limitations: string[]
  analysisKind: string
  scannedAt: string
  sanitizedContent: string
  urlsFound: string[]
}

interface Detector {
  code: string
  title: string
  weight: number
  patterns: RegExp[]
  explanation: string
  whatToDo: string
}

const join = (...words: string[]) => words.map((w) => w.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('|')

const DETECTORS: Detector[] = [
  {
    code: 'OTP_SECRET_REQUEST',
    title: 'Requests for OTP, PIN, password or card details',
    weight: 35,
    patterns: [
      new RegExp(`\\b(otp|one[- ]time password|pin|cvv|cvv2|passcode)\\b[^.]{0,40}\\b(share|send|tell|batao|confirm|enter|provide|verify|forward)\\b`, 'i'),
      new RegExp(`\\b(share|send|tell|confirm|enter|provide)\\b[^.]{0,30}\\b(otp|one[- ]time password|pin|cvv|password|passcode)\\b`, 'i'),
      /\b(card|debit|credit)[^.]{0,20}\b(number|no\.?|details)\b[^.]{0,40}\b(share|send|confirm|provide)/i,
      new RegExp(`\\b(${join('otp','cvv','pin','password')})\\s*[:=]\\s*\\d{4,8}\\b`, 'i'),
    ],
    explanation:
      'No bank, wallet, or genuine payment app will ever ask you to share an OTP, PIN, CVV or password. Sharing these hands over full control of your account — this is the single most common pattern in UPI and banking fraud reported to the National Cyber Crime Reporting Portal.',
    whatToDo:
      'Never share OTPs/PINs with anyone, including callers claiming to be bank staff. If already shared, immediately freeze the account via your bank app or call your bank, and report to cybercrime.gov.in / helpline 1930.',
  },
  {
    code: 'GUARANTEED_RETURNS',
    title: 'Guaranteed or unrealistic returns promised',
    weight: 30,
    patterns: [
      new RegExp(`\\b(${join('guaranteed','assured','fixed','confirmed','100% safe','risk[- ]free','no risk','zero risk')})\\b[^.]{0,30}\\b(return|returns|profit|income|growth|gain|profit)\\b`, 'i'),
      new RegExp(`\\b(double|triple|\\d{1,3}x|\\d{2,4}%+)\\b[^.]{0,30}\\b(money|return|profit|investment|growth)\\b`, 'i'),
      new RegExp(`\\b(return|profit|interest|income)\\b[^.]{0,20}\\b(\\d{2,3}%\\s*(per|\/|a|each)?\\s*(month|weekly|day|daily))\\b`, 'i'),
      /\b(money doubling|muliple|paisa double|10x returns)\b/i,
    ],
    explanation:
      'All genuine market-linked investments carry risk, and no legitimate institution can "guarantee" abnormally high returns. SEBI and RBI repeatedly warn that promises of fixed high returns are the hallmark of Ponzi and pump-and-dump schemes.',
    whatToDo:
      'Treat guaranteed high returns as a scam signal. Verify any investment platform on SEBI\'s list of registered intermediaries before investing a single rupee.',
  },
  {
    code: 'PRIZE_LOTTERY',
    title: 'Lottery, prize or unexpected windfall claim',
    weight: 30,
    patterns: [
      new RegExp(`\\b(${join('lottery','lottery winner','prize','prize money','lucky draw','jackpot','kbc','congratulations!!','you have won','you won','gift voucher','refund waiting')})\\b`, 'i'),
      /congratulations[^.]{0,60}\b(won|winner|selected|chosen|prize)/i,
      new RegExp(`\\b(claim)\\b[^.]{0,30}\\b(prize|gift|reward|cashback|refund|money)\\b`, 'i'),
    ],
    explanation:
      'Genuine lotteries never require you to pay a fee to receive winnings, and you cannot win a draw you never entered. "Pay a small processing/GST charge to release your prize" is a documented advance-fee fraud pattern.',
    whatToDo:
      'Do not pay any fee or share details. Legitimate prizes never require advance payment. Report the message via Chakshu (sancharsaathi.gov.in) or cybercrime.gov.in.',
  },
  {
    code: 'ADVANCE_FEE_PAYMENT',
    title: 'Advance fee or unusual payment instructions',
    weight: 25,
    patterns: [
      new RegExp(`\\b(processing fee|registration fee|advance (fee|payment|charge)|token (amount|advance)|gst (charge|fee|on refund)|activation fee|release (charge|fee)|commission first)\\b`, 'i'),
      new RegExp(`\\b(send|pay|transfer)\\b[^.]{0,40}\\b(to (my|this|personal)\\b)?[^.]{0,30}\\b(upi|wallet|number|account)\\b[^.]{0,30}\\b(to (verify|activate|unlock|confirm|receive|release))\\b`, 'i'),
      /\bpay(rs?\.?\s*\d{1,3}[,.]?\d{0,3})?\b[^.]{0,30}\b(again|extra|small amount|refundable)\b/i,
      /\b(gift card|google play card|scratch card) code\b/i,
    ],
    explanation:
      'Scammers ask for small "refundable" or "processing" payments to activate prizes, releases, refunds or loans. Once paid, demands escalate. Genuine institutions never collect advance fees over UPI to release money that belongs to you.',
    whatToDo:
      'Refuse to pay anything upfront. Cross-check the claim directly on the official website/app of the organisation — never through contact details given in the same message.',
  },
  {
    code: 'AUTHORITY_IMPERSONATION',
    title: 'Impersonation of bank, RBI, SEBI or government authority',
    weight: 25,
    patterns: [
      new RegExp(`\\b(rbi|reserve bank|sebi|income tax department|customs|cbi|police| narcotics|court|covid grant|pm kisan benefit|government scheme)\\b[^.]{0,60}\\b(verify|suspended|blocked|penalty|notice|kyc|update|lucky|refund|benefit)\\b`, 'i'),
      new RegExp(`\\b(your|your bank|bank)\\b[^.]{0,20}\\b(account)\\b[^.]{0,30}\\b(blocked|suspended|frozen|deactivated|limited|will be closed)\\b`, 'i'),
      new RegExp(`\\b(kyc|e-kyc|pan card|aadhaar)\\b[^.]{0,40}\\b(expired|invalid|suspended|update|renew|pending|verify|re-?submit)\\b`, 'i'),
      /dear (customer|sir|madam|user|account holder)/i,
    ],
    explanation:
      'Impersonating banks and regulators is the most reported fraud pattern in India. RBI has publicly clarified it NEVER involves itself in deposits, KYC expiry calls, lotteries, or refunds via phone/WhatsApp. Caller ID and letterheads are trivially faked.',
    whatToDo:
      'Hang up / ignore. Contact your bank only via the number printed on your card or official app. Verify claims on rbi.org.in / sebi.gov.in. Report impersonation at cybercrime.gov.in.',
  },
  {
    code: 'PHISHING_LINK',
    title: 'Phishing-style link and credential-harvesting pattern',
    weight: 25,
    patterns: [
      new RegExp(`\\b(verify|validate|confirm|update|reactivate|unlock|restore)\\b[^.]{0,40}\\b(account|login|credentials|details|information|KYC|profile)\\b[^.]{0,40}\\b(click|tap|link|below|here|form|app)\\b`, 'i'),
      new RegExp(`\\b(click|tap)\\b[^.]{0,30}\\b(below|here|this link|now)\\b`, 'i'),
      new RegExp(`\\b(login|log[- ]?in|sign[- ]?in)\\b[^.]{0,40}\\b(http|www\.|\.com|\.in|\.net|\.xyz|link)\\b`, 'i'),
      /\b(your account (will be|has been) (closed|limited|disabled) unless)\b/i,
    ],
    explanation:
      'Messages that pressure you to "click a link and verify/update/login" typically lead to fake websites that steal credentials. Genuine organisations direct you to open their official app or type their known web address yourself.',
    whatToDo:
      'Never log in from links in messages. Open the official app or type the organisation\'s address manually. Check for misspelled domains (e.g. sbi-secure-login.com). Report the link at cybercrime.gov.in.',
  },
  {
    code: 'SUSPICIOUS_URL',
    title: 'Structurally suspicious URL',
    weight: 25,
    patterns: [], // handled by URL-specific analysis below
    explanation:
      'Scam links often use IP addresses instead of domains, punycode look-alikes, shorteners that hide the destination, brand names in wrong positions (e.g. "hdfc-bank.secure-login.xyz"), recently-abused TLDs, or plain HTTP for login pages.',
    whatToDo:
      'Do not open the link. Inspect the domain character by character against the official one. When in doubt, use the organisation\'s official app or search for the site yourself.',
  },
  {
    code: 'JOB_TASK_FRAUD',
    title: 'Too-good job / task-based earning offer',
    weight: 20,
    patterns: [
      new RegExp(`\\b(work from home|part[- ]time job|earn (daily|rs?\\.? ?\\d{3,})|daily payout|telegram (task|job|group)|prepaid task|video (like|watch) (job|earn)|earn from (phone|mobile)\\b)\\b`, 'i'),
      new RegExp(`\\b(job|task|work)\\b[^.]{0,40}\\b(like|subscribe|review|rate|deposit|invest|pay)\\b[^.]{0,40}\\b(earn|income|payout|commission)\\b`, 'i'),
      /\b(hotel|flight|movie) booking (job|task|earn)/i,
    ],
    explanation:
      'A documented nationwide fraud where "part-time tasks" (liking videos, reviewing hotels) start with small payouts, then require deposits that are never returned. Genuine employers never ask you to pay money to earn money.',
    whatToDo:
      'Do not deposit any amount, even a "small trial". Block and report. Genuine jobs never require upfront payments.',
  },
  {
    code: 'URGENCY_PRESSURE',
    title: 'Urgency, threat or pressure tactics',
    weight: 15,
    patterns: [
      new RegExp(`\\b(${join('urgent','urgently','immediately','right now','act now','last chance','final (warning|notice|chance)','limited time','today only','expires? (today|tomorrow|soon|in \\d)','within (\\d+ )?(hours|minutes)','hurry','before it.s too late','don.t miss','few slots left','only today')})\\b`, 'i'),
      /\b(account (will be|has been) (blocked|suspended)|legal action|police complaint|arrest warrant|penalty of)\b/i,
    ],
    explanation:
      'Manufactured urgency and fear short-circuit rational checking. "Act within 24 hours or your account closes" is designed to stop you from verifying the claim calmly through official channels.',
    whatToDo:
      'Slow down. No genuine financial matter disappears in 24 hours. Verify independently via official websites/apps before acting on any urgent demand.',
  },
  {
    code: 'OFF_PLATFORM_CONTACT',
    title: 'Push to move conversation to WhatsApp/Telegram',
    weight: 10,
    patterns: [
      new RegExp(`\\b(whatsapp|telegram|signal|imo)\\b[^.]{0,50}\\b(group|join|chat|number|dm|message)\\b`, 'i'),
      /\b(join (our|this) (group|channel|community))\b/i,
    ],
    explanation:
      'Fraudsters steer victims to private messaging platforms where moderation, reporting and traceability are weaker, and where they can apply group-pressure ("others are earning!") without oversight.',
    whatToDo:
      'Stay on verifiable platforms. Be extra cautious of any investment or earnings group on messaging apps — most documented "pig butchering" scams begin exactly this way.',
  },
  {
    code: 'CRYPTO_HYPE',
    title: 'Unregistered crypto / trading-tip promotion',
    weight: 15,
    patterns: [
      new RegExp(`\\b(crypto|bitcoin|btc|usdt|forex|binary|trading)\\b[^.]{0,50}\\b(guaranteed|doubling|tips?|signals?|vip|group|profit|no loss|sure shot)\\b`, 'i'),
      /\b(insider (tips?|information)|pump (it|the) (coin|price)|sure shot (call|tip))/i,
    ],
    explanation:
      '"Sure-shot" crypto/forex tip groups are unregulated. In India, offering crypto investment advice without registration and promising profits violates consumer-protection norms; most such groups are exit scams.',
    whatToDo:
      'Avoid unregistered tip groups. If investing at all, use recognised, regulated channels and understand that crypto is largely unregulated and high-risk in India.',
  },
  {
    code: 'PAYMENT_APP_ABUSE',
    title: 'Request to "send money to receive money"',
    weight: 25,
    patterns: [
      new RegExp(`\\b(send|pay|transfer)\\b[^.]{0,30}\\b(\\d|amount|rs|₹|rupees)\\b[^.]{0,40}\\b(first|then|after|to receive|to get|to unlock|refund back)\\b`, 'i'),
      new RegExp(`\\b(screen ?shot|screenshot)\\b[^.]{0,30}\\b(payment|paid|sent|transfer)\\b`, 'i'),
      /\b(request|collect) (money|payment) (on|via) (gpay|phonepe|paytm|upi)/i,
      /\b(scan (the |this )?qr (code|and pay) (to )?(receive|get|refund|verify))/i,
    ],
    explanation:
      'Classic "you pay first" reversals, including fake screenshots and collect-request QR scams. On UPI, money always goes FROM you TO them — you never need to pay to receive a genuine refund, cashback, or sale proceeds.',
    whatToDo:
      'Never approve a collect request or scan a QR to "receive" money. Refunds and sale payments never require you to pay first. Report to your payment app and helpline 1930.',
  },
]

// ---- URL-specific checks -------------------------------------------------

function analyzeUrls(urls: string[]): { findings: Finding[]; allFlags: string[] } {
  const findings: Finding[] = []
  const allFlags: string[] = []

  for (const raw of urls.slice(0, 5)) {
    const flags: string[] = []
    let candidate = raw.trim()
    if (!/^https?:\/\//i.test(candidate)) candidate = 'http://' + candidate
    try {
      const u = new URL(candidate)
      const host = u.hostname.toLowerCase()

      if (/^\d{1,3}(\.\d{1,3}){3}$/.test(host)) flags.push('Uses a raw IP address instead of a domain name')
      if (host.includes('xn--')) flags.push('Punycode domain — can imitate real letters (look-alike attack)')
      if (/(bit\.ly|tinyurl|cutt\.ly|is\.gd|t\.co|rb\.gy|shorturl|tiny\.cc|rebrand\.ly|bit\.do|urlshortener)/.test(host))
        flags.push('URL shortener hides the true destination')
      if (/\.(xyz|top|icu|club|online|site|website|space|click|link|live|rest|cfd|sbs)(:|\/|$)/.test(host + '/'))
        flags.push('Uses a TLD frequently abused in phishing campaigns')
      if (/^(?!.*(^(https?:\/\/)?(www\.)?(sbi|onlinesbi|hdfcbank|hdfc|icicibank|icici|axisbank|kotak|paytm|phonepe|amazonflipkart|amazon|flipkart|google|facebook|instagram)\.[a-z.]+))(.*(sbi|hdfc|icici|axis|kotak|paytm|phonepe|amazon|flipkart|google|facebook|whatsapp|instagram|paypal|bank)).*(login|secure|verify|account|update|kyc|official|support|care|help)/.test(host))
        flags.push('Brand name combined with security words — common impersonation pattern')
      if (host.split('.').length >= 4 && !/\.co\.in$|\.org\.in$|\.gov\.in$|\.ac\.in$/.test(host))
        flags.push('Unusually deep subdomain chain — can hide the real destination')
      if (/^(http)(?!s)/.test(candidate) && /(login|verify|account|bank|pay|secure)/.test(candidate))
        flags.push('Plain (non-HTTPS) link asking for account action')
      if (/^-|-$/.test(host) === false && (host.match(/-/g)?.length || 0) >= 3)
        flags.push('Excessive hyphens in domain — typical of throwaway phishing hosts')

      if (flags.length > 0) {
        allFlags.push(...flags.map((f) => `${host}: ${f}`))
      }
    } catch {
      allFlags.push(`${raw}: Not a well-formed URL`)
    }
  }

  if (allFlags.length > 0) {
    findings.push({
      code: 'SUSPICIOUS_URL',
      title: 'Structurally suspicious URL',
      weight: 25,
      evidence: allFlags.slice(0, 6),
      explanation: DETECTORS.find((d) => d.code === 'SUSPICIOUS_URL')!.explanation,
      whatToDo: DETECTORS.find((d) => d.code === 'SUSPICIOUS_URL')!.whatToDo,
    })
  }
  return { findings, allFlags }
}

// ---- Sensitive-data sanitisation ----------------------------------------

export function sanitizeSensitive(text: string): { sanitized: string; flagged: string[] } {
  const flagged: string[] = []
  let out = text
  // OTP-like standalone 4-8 digit codes after otp/pin keywords
  out = out.replace(/\b(otp|pin|cvv|password|passcode)\s*[:=\-]?\s*(\d{4,8})\b/gi, (_m, w, d) => {
    flagged.push(`Looks like a real ${String(w).toUpperCase()} was included and has been masked for your safety.`)
    return `${w}: ••••`
  })
  // standalone 4-8 digit numbers that follow the word otp even loosely
  out = out.replace(/\b\d{4,8}\b(?=[^.]{0,10}\b(otp|pin)\b)/gi, (d) => {
    flagged.push('A numeric code that may be a live OTP was masked for your safety.')
    return '••••'
  })
  // card-like numbers 13-19 digits (spaces/dashes allowed)
  out = out.replace(/\b(?:\d[ -]?){13,19}\b/g, (m) => {
    const digits = m.replace(/\D/g, '')
    if (digits.length >= 13 && digits.length <= 19) {
      flagged.push('Something formatted like a full card number was masked for your safety.')
      return `•••• •••• •••• ${digits.slice(-4)}`
    }
    return m
  })
  return { sanitized: out, flagged }
}

// ---- Main entry ----------------------------------------------------------

export function runScamScan(content: string, inputType: string): ScanResult {
  const findings: Finding[] = []
  let score = 0
  const text = content.slice(0, 6000)

  for (const d of DETECTORS) {
    if (d.code === 'SUSPICIOUS_URL') continue
    const evidence: string[] = []
    for (const p of d.patterns) {
      const m = text.match(p)
      if (m) {
        evidence.push(m[0].slice(0, 90).trim())
        if (evidence.length >= 3) break
      }
    }
    if (evidence.length > 0) {
      findings.push({ code: d.code, title: d.title, weight: d.weight, evidence, explanation: d.explanation, whatToDo: d.whatToDo })
      score += d.weight
    }
  }

  const rawUrlMatches = text.match(/\b((https?:\/\/|www\.)[^\s<>"')]+|(?:(?!-)[a-z0-9-]{2,}\.)+[a-z]{2,}(\/[^\s<>"')]*)?)/gi) || []
  const urlMatches = Array.from(new Set(rawUrlMatches)).filter((u) => /\.(com|in|net|org|xyz|top|icu|co|io|ly|me|app|site|online|info|club|link|gov|ac)(\/|$|\b)/i.test(u)).slice(0, 8)

  const hasUrlish = urlMatches.length > 0
  if (hasUrlish) {
    const { findings: urlFindings } = analyzeUrls(urlMatches)
    for (const f of urlFindings) {
      findings.push(f)
      score += f.weight
    }
  }

  const riskLabel: ScanResult['riskLabel'] = score >= 50 ? 'High Risk' : score >= 25 ? 'Suspicious' : 'Low Indicated Risk'

  const recommendations: string[] = []
  if (findings.some((f) => f.code === 'OTP_SECRET_REQUEST'))
    recommendations.push('If you already shared an OTP or PIN: call your bank\'s fraud line NOW and block the account/card, then report at cybercrime.gov.in within the golden hour.')
  if (findings.some((f) => f.code === 'GUARANTEED_RETURNS' || f.code === 'CRYPTO_HYPE'))
    recommendations.push('Check whether the entity is registered using SEBI\'s official lists at sebi.gov.in before any investment.')
  if (hasUrlish)
    recommendations.push('Do not open the link. Type the organisation\'s official address manually or use its official app instead.')
  if (findings.some((f) => f.code === 'PAYMENT_APP_ABUSE' || f.code === 'ADVANCE_FEE_PAYMENT'))
    recommendations.push('Never transfer money to "receive" money. Refunds, prizes and cashbacks never require payment first.')
  recommendations.push('Never share OTPs, PINs, passwords, CVV or full card details with anyone — including people claiming to be from your bank, RBI or a delivery company.')
  recommendations.push(' independently verify claims by contacting the organisation through the number printed on your card or its official website.')
  recommendations.push('Report fraudulent messages via Chakshu (sancharsaathi.gov.in) and financial fraud at cybercrime.gov.in or call 1930.')

  const reportingResources = [
    { name: 'National Cyber Crime Reporting Portal', detail: 'File a complaint online for all cyber fraud including financial fraud', url: 'https://cybercrime.gov.in' },
    { name: 'Cyber Fraud Helpline 1930', detail: '24×7 phone helpline — reporting quickly can freeze money before it moves', url: 'https://cybercrime.gov.in' },
    { name: 'Chakshu Portal (Sanchar Saathi)', detail: 'Report fraudulent calls, SMS, WhatsApp messages and lost mobiles', url: 'https://sancharsaathi.gov.in' },
    { name: 'RBI — Beware of Fraudsters', detail: 'Official RBI awareness materials on banking fraud', url: 'https://www.rbi.org.in' },
    { name: 'SEBI Investor Awareness', detail: 'Verify intermediaries and report investment fraud', url: 'https://investor.sebi.gov.in' },
  ]

  const limitations = [
    'This is a preliminary HEURISTIC analysis based on documented scam language and URL patterns. It is not a legal or forensic conclusion.',
    'A "Low Indicated Risk" result means no documented red-flag patterns were found — it does NOT mean the message, offer, or link is safe. New scams are constantly evolving.',
    'No external URL reputation or threat-intelligence service is currently connected, so links were assessed structurally, not against live blacklists.',
    'Automated analysis can miss subtle or novel manipulation. Always verify unexpected financial requests through official channels independently.',
  ]

  const { sanitized, flagged } = sanitizeSensitive(text)
  const analysisKind = 'Preliminary heuristic analysis (no external threat-intelligence feed connected)'

  if (flagged.length > 0) {
    findings.push({
      code: 'SENSITIVE_DATA_MASKED',
      title: 'Sensitive-looking data was masked',
      weight: 0,
      evidence: flagged.slice(0, 3),
      explanation:
        'Your submission appears to contain live OTPs, PINs, or card numbers. Money Harvest masked them before storing the scan. Money Harvest never asks for and never stores banking passwords, OTPs, PINs or full card details.',
      whatToDo: 'If any code above is genuinely live, treat it as compromised: change/regenerate it immediately.',
    })
  }

  return {
    riskLabel,
    riskScore: Math.min(score, 100),
    findings: findings.sort((a, b) => b.weight - a.weight),
    recommendations,
    reportingResources,
    limitations,
    analysisKind,
    scannedAt: new Date().toISOString(),
    sanitizedContent: sanitized,
    urlsFound: urlMatches,
  }
}
