// Money Harvest — Cybersecurity lessons
import type { LessonSeed } from './lessons-personal'

export const cybersecurityLessons: LessonSeed[] = [
  {
    slug: 'phishing-attacks',
    category: 'cybersecurity',
    topic: 'Phishing attacks',
    title: 'Phishing Attacks: The Con, Not the Click',
    summary: 'How phishing manipulates humans instead of computers, the anatomy of a phishing message, spear-phishing, and the reflexes that neutralise it.',
    level: 'Beginner',
    readMinutes: 7,
    tags: ['phishing', 'email', 'smishing', 'vishing'],
    related: ['fake-websites', 'social-engineering', 'otp-scams', 'password-security'],
    content: {
      intro: 'Phishing is fraud that hacks people instead of machines. The attacker sends a message that creates emotion — fear, greed, urgency — and offers relief through a link, attachment or phone call. No technical genius required; social engineering is cheaper than malware, which is why it dominates all cybercrime statistics.',
      sections: [
        {
          heading: 'The anatomy of a phishing message',
          body: [
            'Four parts recur: (1) a trigger — "account blocked", "KYC expiring", "parcel stuck", "tax refund"; (2) urgency — act within hours; (3) authority cosplay — logos, formal tone, real-sounding names; (4) an action — click, install, reply, call, or "verify".',
            'Variants: email phishing, smishing (SMS), vishing (voice calls), quishing (QR codes) — the medium changes, the anatomy never does. Train yourself to see the shape, not the spelling.',
          ],
        },
        {
          heading: 'The tells that survive spell-check',
          body: [
            'Modern phishing is well-written, so grammar is no longer the tell. Instead check: the actual sender address (long-press on mobile, not just display name), the real link destination (long-press to preview; look for look-alike domains like rnbl vs rbi), unsolicited urgency, and any request for OTP/PIN/password/card data — the universal marker.',
            'Attachments ending .apk, .exe, or "invoice.html" are payload delivery. Genuine institutions do not send APKs, and no bank asks you to "install this update for your account".',
          ],
        },
        {
          heading: 'Spear phishing — when they know you',
          body: [
            'Spear phishing references real details from your leaked data: your name, employer, recent order, or "colleague" requesting an urgent transfer. It feels personal because it is — data from breaches and social media is the raw material.',
            'Defence is process, not suspicion alone: verify money/data requests through a SECOND, independently-known channel (call the person on their saved number; check the order in the official app). A 30-second callback defeats an hour of flawless impersonation.',
          ],
        },
        {
          heading: 'Reflexes that make phishing boring',
          body: [
            'Reflex 1: unexpected + urgent + link = delete. Reflex 2: navigate manually — open the official app or type the site yourself; never from the message. Reflex 3: never share OTPs — with anyone, ever, including "bank staff". Reflex 4: report — Chakshu (sancharsaathi.gov.in) for SMS/calls, 1930/cybercrime.gov.in if money moved or data was shared.',
          ],
        },
      ],
      example: {
        title: 'The courier that cost ₹1.4 lakh',
        body: 'A "FedEx" call said a parcel addressed to "Mrs Sharma" held illegal items and was being "transferred to Mumbai police narcotics". The scripted transfer, fake officers, video calls with official backdrops, and a "verification deposit" extracted ₹1.4 lakh over six hours of psychological siege. The entire case was one anatomy: trigger (fear/legal), urgency, authority cosplay, action (pay to clear your name). No parcel ever existed.',
      },
      keyTerms: [
        { term: 'Smishing', definition: 'Phishing via SMS/WhatsApp messages.' },
        { term: 'Vishing', definition: 'Phishing via voice calls, often with spoofed official numbers.' },
        { term: 'Quishing', definition: 'Phishing via malicious QR codes that bypass link-scanning habits.' },
        { term: 'Look-alike domain', definition: 'A domain imitating a brand with swapped letters (rn for m, 0 for o, hyphens). The definitive check before login.' },
      ],
      takeaways: [
        'Phishing hacks emotion — urgency + authority + link is the shape to recognise.',
        'Check sender addresses and link destinations by long-pressing, not display names.',
        'No institution ever needs your OTP, PIN, password or CVV.',
        'Navigate manually: official app or typed URL, never message links.',
        'Report: Chakshu for messages, 1930/cybercrime.gov.in when money or data is exposed.',
      ],
      externalLinks: [
        { label: 'Chakshu — Report fraudulent messages', url: 'https://sancharsaathi.gov.in', source: 'DoT, Government of India' },
        { label: 'Cyber Crime Reporting Portal', url: 'https://cybercrime.gov.in', source: 'MHA, Government of India' },
      ],
    },
  },
  {
    slug: 'fake-investment-apps',
    category: 'cybersecurity',
    topic: 'Fake investment apps',
    title: 'Fake Investment Apps: The Interface of Trust',
    summary: 'How cloned trading apps and fake dashboards run pig-butchering scams, the initial-small-withdrawal trick, and verification steps before any deposit.',
    level: 'Intermediate',
    readMinutes: 7,
    tags: ['fake app', 'pig butchering', 'trading scam', 'verification'],
    related: ['phishing-attacks', 'upi-fraud', 'risk-and-return', 'stock-market-basics'],
    content: {
      intro: 'The fake investment app is the most profitable scam format of the decade — often called "pig butchering" for the fattening-then-slaughtering cycle. Victims see a professional dashboard showing profits climbing daily. Everything on screen is theatre: the numbers, the chart, the "customer support", sometimes even the app store listing.',
      sections: [
        {
          heading: 'The script you will recognise',
          body: [
            'Stage 1: contact — a "wrong number" that turns friendly, or an old classmate messaging out of nowhere, who casually shares trading profits. Stage 2: the hook — a Telegram/WhatsApp group where "mentors" post wins and members (all bought accounts) cheer. Stage 3: the app — a slick APK or clone "broker" app.',
            'Stage 4: the small win — ₹5,000 deposited shows ₹5,800 and WITHDRAWS successfully; that payout is marketing budget, not trading. Stage 5: the slaughter — deposits grow (₹2–20 lakh, often via loans), then "account frozen for tax/verification", requiring a "release fee". Then the app, group, and people vanish.',
          ],
        },
        {
          heading: 'Why the dashboard lies convincingly',
          body: [
            'The app is not connected to any market. It is a website styled like a trading terminal with a database that displays whatever keeps you depositing — including your "profits". Nothing you see is evidence of anything.',
            'Genuine brokers are SEBI-registered, and money reaches the broker\u2019s registered bank/PMLA account; the app\u2019s "wallet" asking for personal UPI transfers is the confession. No genuine broker collects deposits into strangers\u2019 UPI handles or "USDT addresses".',
          ],
        },
        {
          heading: 'Verification in five minutes',
          body: [
            'Check the entity on SEBI\u2019s registered intermediaries list (sebi.gov.in → Intermediaries). Check the app on the official store and compare publisher name with the broker\u2019s site. Refuse APK links — that alone kills most of these scams. Search "[app name] scam" and check r/IndiaInvestments-style community reports.',
            'If already trapped: stop depositing immediately (release fees are extensions of the scam), collect screenshots, call 1930, file at cybercrime.gov.in, and inform your bank for possible recall. Money sent via UPI within hours is sometimes frozen — speed matters again.',
          ],
        },
      ],
      example: {
        title: '₹18 lakh in a "trading" app',
        body: 'Rohit, 34, met "Ananya" via a wrong-number WhatsApp. Weeks of friendly chat led to a "Quant AI trading" APK. First ₹10,000 "grew" to ₹12,400 and withdrew in minutes — the proof that sealed his trust. Over six weeks he deposited ₹18 lakh, mostly via personal UPI "wallet top-ups". When the "KYC release fee" of ₹2.1 lakh arrived, he paid it too. The group, app and Ananya disappeared the same night. SEBI\u2019s registry never contained the firm.',
      },
      keyTerms: [
        { term: 'Pig butchering', definition: 'Long-con scam: romance/friendship, fake profits, escalating deposits, eventual disappearance.' },
        { term: 'Shill group', definition: 'A chat group of operated accounts celebrating fake wins to manufacture social proof.' },
        { term: 'APK sideload', definition: 'Installing apps outside official stores — the delivery channel of choice for fake apps.' },
        { term: 'Payout window', definition: 'Early small successful withdrawals funded by the scam itself — marketing, not evidence.' },
      ],
      takeaways: [
        'A profitable dashboard proves nothing — fake apps display arbitrary numbers.',
        'The first successful small withdrawal is bait, not verification.',
        'Verify brokers on SEBI\u2019s registry; refuse APK installs and personal-UPI deposits.',
        'Groups full of winners are operated theatre; real investing is boring and lonely.',
        'If trapped: stop paying, preserve evidence, 1930 + cybercrime.gov.in immediately.',
      ],
      externalLinks: [
        { label: 'SEBI — Check registered intermediaries', url: 'https://www.sebi.gov.in', source: 'SEBI' },
        { label: 'Cyber Crime Reporting Portal', url: 'https://cybercrime.gov.in', source: 'MHA, Government of India' },
      ],
    },
  },
  {
    slug: 'otp-scams',
    category: 'cybersecurity',
    topic: 'OTP scams',
    title: 'OTP Scams: The Last Six Digits of Your Money',
    summary: 'Why the OTP is the final lock on your money, the social scripts used to extract it, SIM-swap interception, and the absolute rule that ends the discussion.',
    level: 'Beginner',
    readMinutes: 6,
    tags: ['OTP', 'vishing', 'SIM swap', 'banking fraud'],
    related: ['upi-safety', 'phishing-attacks', 'digital-banking-security', 'social-engineering'],
    content: {
      intro: 'The One-Time Password is the last lock between a fraudster and your money. Everything before it — your card number, leaked password, account details — is preparation. This is why OTP extraction is the entire point of most Indian banking fraud calls: the scammer\u2019s only real job is making you read out six digits.',
      sections: [
        {
          heading: 'The scripts, catalogued',
          body: [
            '"I\u2019m from your bank\u2019s KYC department; share the OTP to update your account." "Your electricity will be cut; pay via this link and the OTP confirms payment." "You\u2019ve received a refund; approve the request." "I accidentally sent you ₹5,000; return it via this link" (it sends instead of receives).',
            'Variations are infinite; the constant is that SOMEONE asks you to share, read, or enter an OTP — or approve a collect request. That person is a thief by definition, regardless of how much they already know about you.',
          ],
        },
        {
          heading: 'When OTPs are stolen without asking',
          body: [
            'SIM swap: after porting your number via forged documents, the fraudster receives your OTPs directly — the moment your phone shows "No Service" you are mid-attack; call your operator and bank at once. Set a SIM-change PIN with your carrier as prevention.',
            'Malicious apps with accessibility/screen-share permissions read OTP notifications silently. This is why "install this support app / join this screen-share for refund processing" ends every legitimate conversation — no real support process needs to watch your screen.',
          ],
        },
        {
          heading: 'The absolute rule',
          body: [
            'No bank, wallet, government office, delivery company, or genuine platform will EVER ask you to share an OTP — not to "verify identity", not to "stop a fraud transaction", not to "receive a refund". The rule has zero exceptions, which is its power.',
            'Banks now also display the counterparty name in OTP SMS: "OTP for transaction at <Merchant>". Read the whole message — if the merchant name is unknown, the OTP is someone else\u2019s purchase attempt on your card.',
          ],
        },
      ],
      example: {
        title: '"I am calling from the fraud department"',
        body: 'Sunita received a call: "₹9,800 fraud transaction is being processed; we can stop it — approve the OTP we send to cancel it." The "cancellation OTP" was, naturally, the transaction itself. She nearly complied — the caller knew her name, bank and last transaction (from a data leak). One habit saved her: she hung up and called the number printed on her card. The "fraud department" did not exist.',
      },
      keyTerms: [
        { term: 'OTP', definition: 'One-Time Password — a single-use code authorising a transaction; equivalent to your signature.' },
        { term: 'Screen-share abuse', definition: 'Remote assistance apps misused to read OTPs and banking screens in real time.' },
        { term: 'Counterparty name', definition: 'The merchant/payer name printed in OTP SMS — always read it before ignoring the code.' },
        { term: 'Spoofed call', definition: 'A call made to display a fake caller ID (bank name), trivially cheap for fraudsters.' },
      ],
      takeaways: [
        'An OTP is your signature — sharing it signs away your money.',
        'Anyone asking for an OTP is a thief; the rule has no exceptions.',
        '"No Service" on your phone = possible SIM swap: operator + bank, immediately.',
        'Never install screen-share apps for "support"; never join remote sessions for refunds.',
        'Read the counterparty name inside OTP SMS before dismissing unknown codes.',
      ],
      externalLinks: [
        { label: 'RBI — Beware of phishing advisories', url: 'https://www.rbi.org.in', source: 'Reserve Bank of India' },
        { label: 'Cyber Fraud Helpline 1930', url: 'https://cybercrime.gov.in', source: 'MHA, Government of India' },
      ],
    },
  },
  {
    slug: 'upi-fraud',
    category: 'cybersecurity',
    topic: 'UPI fraud',
    title: 'UPI Fraud: The Modern Street Pickpocket',
    summary: 'Real UPI fraud patterns in the wild — screen screenshots, request-money reversals, QR scams, payment app phishing — and the mechanics that defeat each.',
    level: 'Beginner',
    readMinutes: 7,
    tags: ['UPI fraud', 'QR scam', 'collect request', 'marketplace'],
    related: ['upi-safety', 'otp-scams', 'online-payment-safety', 'phishing-attacks'],
    content: {
      intro: 'UPI fraud rarely breaks the system — it breaks assumptions. The rails themselves are secure; what fails is the human belief that "payment received" screenshots mean money received, or that approving a request is harmless. Each classic pattern is an assumption harvested.',
      sections: [
        {
          heading: 'Pattern 1: the screenshot seller',
          body: [
            'Marketplace sellers receive a "payment done" screenshot with the buyer urging immediate dispatch. The screenshot is edited, or shows a pending/failed transaction\u2019s success-styled toast. Defence: verify in YOUR bank app\u2019s transaction history — money that arrived is listed there, full stop.',
          ],
        },
        {
          heading: 'Pattern 2: request-to-receive reversal',
          body: [
            '"To receive your refund/cashback/sale amount, approve this request." The request is a DEMAND for money; approval pays them. Related: "send ₹1 to verify the account before we release ₹10,000" — the ₹1 request carries the full amount on tampered flows.',
            'Defence is mechanical: read the request screen — it says YOU PAY ₹X. Refunds never require approvals. Receiving requires no PIN. When a screen contradicts those two facts, the screen is lying.',
          ],
        },
        {
          heading: 'Pattern 3: QR and deep-link traps',
          body: [
            'Stickers pasted over genuine merchant QRs (petrol pumps, parking) redirect your payment to criminals; "instant recharge" QRs in Telegram channels do the same digitally. Deep-link attacks open payment apps mid-scam via crafted links.',
            'Defence: scan only QRs physically verified at reputable merchants, confirm the merchant name on the payment screen before PIN, and never complete a payment initiated by a link someone sent you.',
          ],
        },
        {
          heading: 'Pattern 4: fake payment-app phishing',
          body: [
            'Lookalike apps (extra letters, clone icons) capture your PIN as you "log in". Sideloaded APKs from WhatsApp are the primary vector; accessibility permission is the tell. Defence: official stores only, verify publisher names, deny accessibility permissions to payment apps.',
            'If defrauded through any pattern: in-app report → bank → 1930 → cybercrime.gov.in, within the golden hour. Freeze speed decides recovery odds.',
          ],
        },
      ],
      example: {
        title: 'The ₹1 "verification" on a bike sale',
        body: 'Karthik listed a bicycle for ₹12,000. The "buyer" sent a payment screenshot and a "you must approve ₹1 to verify your UPI before the full amount releases" request. The request screen — read slowly — said "You are paying ₹12,000 to USER HARSH**…". He declined and blocked. The screenshot, of course, corresponded to no transaction in his bank app.',
      },
      keyTerms: [
        { term: 'Collect request', definition: 'A push demand for money; approval + PIN = payment. The core mechanic of "receive money" scams.' },
        { term: 'QR overlay', definition: 'A criminal sticker pasted over a genuine merchant QR.' },
        { term: 'Payment screen truth', definition: 'The only text that matters: the app\u2019s own "You are paying ₹X to NAME" line.' },
        { term: 'In-app dispute', definition: 'Every genuine payment app has a report flow; it creates the record your bank and 1930 need.' },
      ],
      takeaways: [
        'Screenshots prove nothing; your bank app\u2019s history is the only receipt.',
        'Approving a request SENDS money — refunds never need approvals.',
        'Read "You are paying ₹X to NAME" before every PIN entry.',
        'Official app stores + publisher check defeats lookalike apps.',
        'Golden-hour reporting (1930, cybercrime.gov.in) maximises freeze-and-recover odds.',
      ],
      externalLinks: [
        { label: 'NPCI — UPI safety', url: 'https://www.npci.org.in', source: 'NPCI' },
        { label: 'Cyber Crime Reporting Portal', url: 'https://cybercrime.gov.in', source: 'MHA, Government of India' },
      ],
    },
  },
  {
    slug: 'identity-theft',
    category: 'cybersecurity',
    topic: 'Identity theft',
    title: 'Identity Theft: When Someone Becomes You',
    summary: 'How criminals assemble your identity from leaks, the loans-and-SIMs they open in your name, early detection, and a recovery playbook.',
    level: 'Intermediate',
    readMinutes: 7,
    tags: ['identity theft', 'KYC misuse', 'credit report', 'recovery'],
    related: ['credit-scores', 'password-security', 'digital-banking-security', 'phishing-attacks'],
    content: {
      intro: 'Identity theft is not someone stealing your name — it is someone assembling enough of your data (PAN, Aadhaar, phone, DOB) to pass as you to banks, telecoms and lenders. The victim often learns of it months later, when a loan application is rejected because "you" already defaulted on three.',
      sections: [
        {
          heading: 'How identities are assembled',
          body: [
            'Sources: breach dumps (e-commerce, apps), phishing pages that harvest uploads of Aadhaar/PAN photos, discarded physical documents, overshares on social media (full DOB + school + pet name = security answers), and fake "KYC update" forms.',
            'Each fragment is worthless alone; assembled, they pass automated KYC. This is why "just a photo of my Aadhaar for this free gift" is never just a photo.',
          ],
        },
        {
          heading: 'What thieves do with it',
          body: [
            'Open instant-loan apps in your name, port your SIM to intercept OTPs, open wallets and gambling accounts for money-laundering (your identity becomes the criminal\u2019s firewall), and file fake GST or income documents.',
            'A chilling variant: your number appears in fraud call records — police reach you while the real perpetrator used your KYC. Detecting early is everything.',
          ],
        },
        {
          heading: 'Early detection and defence',
          body: [
            'Check your credit report annually (free from each bureau) for unknown accounts or enquiries. Check active SIMs registered to your ID at sancharsaathi.gov.in (TAFCOP) — disconnect any you don\u2019t recognise. Freeze/shred documents; watermark ("issued to X only") any copy you must share.',
            'Never share full ID images in Telegram/WhatsApp groups, refuse "document verification" over calls, and set SMS/email alerts on all financial accounts.',
          ],
        },
        {
          heading: 'The recovery playbook',
          body: [
            'If misused: (1) file at cybercrime.gov.in and get the complaint number — it is your legal anchor; (2) notify the affected bank/bureau in writing requesting a fraud flag; (3) dispute fraudulent accounts with credit bureaus; (4) block the SIM via Sanchar Saathi if phone/SIM involved; (5) keep a dated evidence folder. Recovery is procedural, not fast — patience and paperwork win.',
          ],
        },
      ],
      example: {
        title: 'Three loans nobody took',
        body: 'Vivek\u2019s loan application failed on "existing defaults". His free CIBIL report showed three instant-app loans totalling ₹1.1 lakh — taken with his PAN, whose photo he had once uploaded to a "cashback verification" form. With his cybercrime complaint and written bureau disputes, the entries were removed over five months. The annual-report habit he adopted afterwards is the entire lesson.',
      },
      keyTerms: [
        { term: 'Data breach dump', definition: 'Leaked databases of user details that criminals buy and cross-reference.' },
        { term: 'TAFCOP', definition: 'Telecom Analytics portal at sancharsaathi.gov.in listing SIMs registered to your ID.' },
        { term: 'Fraud flag / freeze', definition: 'A bureau/lender notation that suspends new credit activity on compromised identity data.' },
        { term: 'KYC misuse', definition: 'Using someone\u2019s verified documents to operate accounts as them.' },
      ],
      takeaways: [
        'Fragments of your data assemble into a workable "you" — guard each one.',
        'Annual credit report + TAFCOP SIM check = early detection.',
        'Watermark or refuse document photo requests; full ID images are currency.',
        'Recovery starts with a cybercrime complaint number and written disputes.',
        'Oversharing DOB/school/pet names builds a criminal\u2019s security-question key.',
      ],
      externalLinks: [
        { label: 'Sanchar Saathi — TAFCOP SIM check', url: 'https://sancharsaathi.gov.in', source: 'DoT, Government of India' },
        { label: 'Cyber Crime Reporting Portal', url: 'https://cybercrime.gov.in', source: 'MHA, Government of India' },
      ],
    },
  },
  {
    slug: 'fake-websites',
    category: 'cybersecurity',
    topic: 'Fake websites',
    title: 'Fake Websites: Reading URLs Like a Professional',
    summary: 'How look-alike domains, homoglyphs and cloned layouts steal logins; a five-point URL inspection method; and browser safety settings that help.',
    level: 'Beginner',
    readMinutes: 6,
    tags: ['fake website', 'domain', 'homoglyph', 'browser security'],
    related: ['phishing-attacks', 'password-security', 'online-payment-safety', 'digital-banking-security'],
    content: {
      intro: 'A fake website is a stage set: the facade is pixel-identical to the real bank or shop, the doors lead nowhere good. Everything about it exists to capture what you type. The single skill that defeats the entire category is reading the address bar slowly — a lost art in the app era, and still decisive.',
      sections: [
        {
          heading: 'The look-alike playbook',
          body: [
            'Homoglyphs: "rnbl.org" for "rbi.org" (rn = m at small sizes), "paypa1.com" with a digit one. Subdomain tricks: "secure.hdfcbank.verify-login.xyz" — the REAL domain is the last two segments (verify-login.xyz); everything before the final ".tld" is costume.',
            'New-TLD abuse: .xyz/.top/.icu/.online are cheap and rarely policed. Typos: "sbi-online-kyc.com" — real banks use their exact registered domain; hyphenated extra words are instant suspicion.',
          ],
        },
        {
          heading: 'The five-point URL check',
          body: [
            'One: read the domain RIGHT TO LEFT — brand before the final dot must be exact. Two: check the scheme — https is baseline but NOT a safety certificate (padlocks are free for criminals). Three: beware shorteners hiding destinations. Four: on mobile, long-press links to preview before tapping. Five: for anything money-related, don\u2019t click at all — open the official app or type the known address yourself.',
          ],
        },
        {
          heading: 'Layout tells and browser armour',
          body: [
            'Fake sites often break on interaction: dead menus, broken logo links, payment pages asking for card details plus UPI PIN plus email password (real pages never want your email password), and deadline banners ("offer closes in 09:58").',
            'Browser armour: keep the browser auto-updated; enable built-in phishing protection; never dismiss "This site is not secure" warnings; use bookmarks for financial sites and treat them as the only entrances. Password managers refusing to autofill on a look-alike domain is itself an alarm — listen to it.',
          ],
        },
      ],
      example: {
        title: 'The ₹9 test',
        body: 'A "HDFC KYC" SMS linked to hdfcbank-kyc-update.online — visually flawless, badge-complete. The password manager refused to autofill (domain mismatch) — the alarm bells. Sahil then read right-to-left: the true domain was kyc-update.online. He reported the sender via Chakshu. The real HDFC domain had no hyphens and no .online, and would never have asked for his full card details "for verification".',
      },
      keyTerms: [
        { term: 'eTLD+1', definition: 'The real domain: brand + final TLD (e.g., hdfcbank.com); everything before it is subdomain costume.' },
        { term: 'Homoglyph', definition: 'A visually identical character swap (rn/m, 0/O, 1/l) used to fake domains.' },
        { term: 'Autofill mismatch', definition: 'Password managers refusing to fill credentials on look-alike domains — a useful alarm.' },
        { term: 'TLS padlock fallacy', definition: 'The https padlock proves encryption, not honesty — criminal sites get free certificates too.' },
      ],
      takeaways: [
        'Read domains right-to-left; only the brand immediately before the final TLD counts.',
        'https proves nothing about honesty — padlocks are free.',
        'Long-press to preview links; type financial URLs or use bookmarks.',
        'Password-manager autofill refusals are alarms worth obeying.',
        'Real payment pages never ask for email passwords or "verification" beyond the payment itself.',
      ],
      externalLinks: [
        { label: 'Chakshu — Report fraudulent links/SMS', url: 'https://sancharsaathi.gov.in', source: 'DoT, Government of India' },
        { label: 'Cyber Crime Reporting Portal', url: 'https://cybercrime.gov.in', source: 'MHA, Government of India' },
      ],
    },
  },
  {
    slug: 'social-engineering',
    category: 'cybersecurity',
    topic: 'Social engineering',
    title: 'Social Engineering: Hacking the Wetware',
    summary: 'The persuasion principles criminals exploit — authority, scarcity, reciprocity, fear — real scripted scenarios, and personal firewalls against each.',
    level: 'Intermediate',
    readMinutes: 7,
    tags: ['social engineering', 'manipulation', 'pretexting', 'psychology'],
    related: ['phishing-attacks', 'otp-scams', 'fake-investment-apps', 'identity-theft'],
    content: {
      intro: 'Every technical defence ends at a human who can be persuaded. Social engineering is the craft of bypassing security by talking to it — no exploits, just psychology applied with a script. Understanding the six persuasion levers is the closest thing to an antivirus for people.',
      sections: [
        {
          heading: 'The six levers',
          body: [
            'Authority: "RBI officer here" — humans obey perceived authority reflexively. Urgency/scarcity: "account closes in 30 minutes" — panic disables verification. Fear/intimidation: "legal action, arrest warrant" — fear narrows thinking.',
            'Reciprocity: a small favour or "refund" creates obligation. Social proof: "1,200 members of this group are earning" — crowds feel safe even when fake. Liking/similarity: the friendly wrong-number stranger who shares your language, city and wounds. Every major scam combines two or three levers.',
          ],
        },
        {
          heading: 'Scripted in the wild',
          body: [
            'The digital-arrest scam: callers posing as customs/CBI allege a parcel or SIM crime, escalate to "court proceedings", keep victims on video "under supervision" for days, and extract "verification deposits" — authority + fear + isolation, the scam of 2024\u2019s headlines.',
            'The sweetheart pitch: weeks of genuine-feeling romance, then a "sure-win trading platform" — liking + social proof + reciprocity. The office whaling: an email from the "CEO" requesting an urgent vendor transfer during closing hours — authority + urgency on an employee\u2019s helpfulness.',
          ],
        },
        {
          heading: 'Personal firewalls',
          body: [
            'Firewall 1 — the callback rule: verify any money/credential request via a second, independently-known channel. Firewall 2 — the 24-hour rule: no legitimate financial deadline survives a night\u2019s sleep. Firewall 3 — refuse isolation: any process that wants you alone on a call, camera on, "don\u2019t tell anyone", is announcing itself as fraud.',
            'Firewall 4 — pre-commitment: decide now that OTPs are never shared, screen-shares for "support" never happen, and deposits to unknown platforms never occur. In-crisis you will obey pre-committed rules when improvisation would fail. Firewall 5 — normalise reporting: embarrassment is the scam\u2019s best friend; reporting to family and 1930 saves the next victim and often your money.',
          ],
        },
      ],
      example: {
        title: 'Eleven hours of "digital arrest"',
        body: 'A retired professor spent eleven hours on video call with "Mumbai police narcotics" who "arrested" her digitally, citing a fake money-laundering case. The isolation instruction — "this investigation is confidential; stay on call" — was the single loudest alarm. Her daughter\u2019s callback (firewall 1) and a 1930 call ended it. The lever was never technology; it was obedience plus isolation.',
      },
      keyTerms: [
        { term: 'Pretexting', definition: 'Inventing an authoritative scenario (police, bank, courier) to extract information or money.' },
        { term: 'Digital arrest', definition: 'A scam where victims are held on video under fake legal threats and drained of money.' },
        { term: 'Whaling', definition: 'Social engineering targeting executives/high-value staff with authority-flavoured requests.' },
        { term: 'Callback verification', definition: 'Re-contacting the claimed party via independently-known channels before acting.' },
      ],
      takeaways: [
        'Six levers: authority, urgency, fear, reciprocity, social proof, liking — learn to feel them pulled.',
        'The callback rule defeats nearly every authority scam.',
        'No genuine process requires isolation or secrecy — secrecy is a confession.',
        'Pre-commit your refusals now; panicked improvisation obeys scripts, rules survive.',
        'Report shamelessly: 1930, cybercrime.gov.in, and tell your family.',
      ],
      externalLinks: [
        { label: 'Cyber Crime Reporting Portal', url: 'https://cybercrime.gov.in', source: 'MHA, Government of India' },
        { label: 'RBI — Beware of fraudsters', url: 'https://www.rbi.org.in', source: 'Reserve Bank of India' },
      ],
    },
  },
  {
    slug: 'password-security',
    category: 'cybersecurity',
    topic: 'Password security',
    title: 'Password Security: One Gate, Many Doors',
    summary: 'Why reuse is the real vulnerability, building memorable-strong passphrases, password managers, MFA, and what actually happens in a breach.',
    level: 'Beginner',
    readMinutes: 6,
    tags: ['password', 'MFA', 'password manager', 'breach'],
    related: ['digital-banking-security', 'phishing-attacks', 'identity-theft', 'fake-websites'],
    content: {
      intro: 'Passwords gate almost everything — and their biggest failure is not weakness but reuse. When any one of the hundreds of breached sites leaks your email and password, criminals try that pair everywhere ("credential stuffing"). Your single reused password becomes a master key to mail, banking and everything attached.',
      sections: [
        {
          heading: 'What actually breaks a password',
          body: [
            'Length beats complexity theatrics: a four-word passphrase (correct-horse-battery-style, e.g. "mango-tram-39-harvest") outclasses "P@ssw0rd!" massively. Attackers use dictionaries plus rule-mutations, which defeat human "clever" patterns; length is the parameter they cannot shortcut.',
            'Reuse is the fatal habit: unique per account, or one breach unlocks all. Predictable personal data (birthdays, names, film quotes) feeds attackers\u2019 first guesses — your pet\u2019s name is public via Instagram.',
          ],
        },
        {
          heading: 'The password manager decision',
          body: [
            'A password manager generates and stores unique random passwords behind one strong master password — the single most valuable 30-minute upgrade to your digital life. Browsers\u2019 built-in managers are a fine start; dedicated managers add cross-device sync and security audits.',
            'Objection handled: "what if the manager is hacked?" Reputable managers are zero-knowledge — your vault is encrypted on-device with your master password, which never leaves it. The alternative (humans reusing "Harvest2025!") is the reason breaches cascade.',
          ],
        },
        {
          heading: 'MFA — the second gate',
          body: [
            'Multi-factor authentication means a stolen password alone is no longer enough. App-based codes (TOTP) or hardware keys resist SIM-swap far better than SMS OTPs; enable MFA first on email (the master-reset channel for everything else), then banking, then everything.',
            'Also learn the hygiene trio: never enter passwords after clicking email/SMS links (navigate manually), watch for autofill refusals on look-alike domains, and use the platform\u2019s local Password Strength Checker to test patterns — it runs entirely on your device and never transmits what you type.',
          ],
        },
      ],
      example: {
        title: 'The ₹0 that cost ₹4.6 lakh',
        body: 'A fitness app suffered a breach — no payment data, so users shrugged. Rohit had reused his email password there. Within 48 hours: email takeover → password resets cascading through banking and crypto accounts → ₹4.6 lakh gone. The breach was the app\u2019s; the loss was the reuse. Unique passwords would have made the leaked pair worth exactly ₹0.',
      },
      keyTerms: [
        { term: 'Credential stuffing', definition: 'Automatically replaying leaked email+password pairs across major sites.' },
        { term: 'Passphrase', definition: 'A long multi-word password — length-first, memorable, hard to brute-force.' },
        { term: 'Zero-knowledge', definition: 'A service design where the provider mathematically cannot read your stored secrets.' },
        { term: 'TOTP', definition: 'Time-based one-time codes from an authenticator app — MFA that survives SIM swaps.' },
      ],
      takeaways: [
        'Reuse is the real killer — one leak becomes a master key. Unique everywhere.',
        'Prefer long passphrases over symbol-stuffed short passwords.',
        'Adopt a password manager; let it generate what you could never remember.',
        'Enable MFA, app-based first, starting with your email account.',
        'Only enter credentials by navigating manually — never via message links.',
      ],
      externalLinks: [
        { label: 'Cyber Crime Reporting Portal', url: 'https://cybercrime.gov.in', source: 'MHA, Government of India' },
      ],
    },
  },
  {
    slug: 'online-payment-safety',
    category: 'cybersecurity',
    topic: 'Online payment safety',
    title: 'Online Payment Safety: Buying Without Bleeding',
    summary: 'Safe checkout habits, virtual cards, marketplace meeting-point payments, verifying merchants, and disputing transactions that go wrong.',
    level: 'Beginner',
    readMinutes: 6,
    tags: ['payments', 'e-commerce', 'virtual card', 'chargeback'],
    related: ['upi-safety', 'credit-cards', 'fake-websites', 'digital-banking-security'],
    content: {
      intro: 'Online payment safety is mostly about controlling blast radius: assuming any given checkout might be hostile, and arranging your instruments so that the worst case costs you minutes, not months. A few structural habits make you a persistently bad target.',
      sections: [
        {
          heading: 'Merchant verification before payment',
          body: [
            'New site? Check: real domain (right-to-left read), a working returns/contact page with a physical address, and independent reviews (search "[site] scam"). Instagram/Telegram shops with UPI-to-personal-number payments and "prepaid only" are the classic black hole — money goes, goods never do.',
            'Prefer COD for unknown sellers, or at minimum pay on delivery-verified platforms. A "huge discount, ending today, prepaid only" combination is the pattern — discounts and deadlines are tools, not evidence.',
          ],
        },
        {
          heading: 'Instruments that limit damage',
          body: [
            'Virtual cards (single-use or merchant-locked) from your bank isolate exposure — a compromised virtual card dies without touching your main account. Keep one low-limit card for online use; set SMS/email alerts for every transaction.',
            'UPI users: maintain low limits and a secondary UPI ID for public selling. Never complete card details plus OTP plus CVV plus "upi pin" together on any page — no legitimate Indian checkout needs all of them.',
          ],
        },
        {
          heading: 'When transactions go wrong',
          body: [
            'Undelivered/defective goods: first the platform\u2019s dispute flow, then a written complaint to the seller, then card chargeback via your bank (retain screenshots, order IDs, chats). Consumer forums (e-daakhil) handle persistent e-commerce disputes; amounts matter but precedent matters more.',
            'Unauthorised transactions: zero-liability applies if reported within 3 working days (RBI rules) — report immediately in writing, block the instrument, and escalate to the Banking Ombudsman via the RBI CMS portal if the bank stalls.',
          ],
        },
      ],
      example: {
        title: 'The ₹2,49 sneaker that cost ₹24,900',
        body: 'A Telegram "brand clearance" shop demanded prepaid UPI to a personal handle, with a countdown timer. One buyer paid via a virtual single-use card instead of his main card; the site attempted a follow-up ₹24,900 charge days later — declined instantly on the dead virtual card. Same scam, different instrument, trivial loss.',
      },
      keyTerms: [
        { term: 'Virtual card', definition: 'A disposable/limited card number shielding your real card for online payments.' },
        { term: 'Chargeback', definition: 'A bank-mediated reversal dispute on card transactions for fraud or non-delivery.' },
        { term: 'Zero-liability window', definition: 'RBI rule capping customer loss for unauthorised e-transactions reported within 3 working days.' },
        { term: 'e-daakhil', definition: 'The online portal for filing consumer-forum complaints digitally.' },
      ],
      takeaways: [
        'Verify merchants independently; prepaid-only + personal UPI + fake urgency = walk away.',
        'Use virtual/low-limit cards and alerts to cap blast radius.',
        'No legitimate checkout wants card + CVV + OTP + UPI PIN simultaneously.',
        'Report unauthorised transactions within 3 days for zero-liability protection.',
        'Escalate disputes: platform → seller → bank chargeback → Ombudsman/e-daakhil.',
      ],
      externalLinks: [
        { label: 'RBI — Integrated Ombudsman (CMS)', url: 'https://cms.rbi.org.in', source: 'Reserve Bank of India' },
        { label: 'National Consumer Helpline', url: 'https://consumerhelpline.gov.in', source: 'Government of India' },
      ],
    },
  },
]
