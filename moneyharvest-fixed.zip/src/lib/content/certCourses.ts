// Money Harvest — Certificate course configuration
// A certificate is only claimable when the user has a PASSING quiz attempt
// at or above the configured threshold in the required category (server-verified).

export interface CertCourse {
  key: string
  title: string
  description: string
  quizCategory: string
  passPercent: number // minimum percentage required on the required quiz
  lessonsHint: string[]
  accent: string // hex accent used on certificate design
}

export const certCourses: CertCourse[] = [
  {
    key: 'financial-literacy-fundamentals',
    title: 'Financial Literacy Fundamentals',
    description: 'Core money concepts: budgeting, saving, inflation, compounding and goal planning.',
    quizCategory: 'personal-finance',
    passPercent: 70,
    lessonsHint: ['budgeting-fundamentals', 'saving-money', 'compound-interest', 'understanding-inflation'],
    accent: '#D4A373',
  },
  {
    key: 'personal-finance-essentials',
    title: 'Personal Finance Essentials',
    description: 'Applied personal finance: expense management, emergency funds and financial goal planning.',
    quizCategory: 'personal-finance',
    passPercent: 80,
    lessonsHint: ['managing-expenses', 'emergency-fund', 'financial-goal-planning'],
    accent: '#CCD5AE',
  },
  {
    key: 'investment-awareness',
    title: 'Investment Awareness',
    description: 'Understanding markets, mutual funds, SIPs, risk and long-term investing behaviour.',
    quizCategory: 'investment-basics',
    passPercent: 70,
    lessonsHint: ['stock-market-basics', 'mutual-funds', 'sip', 'risk-and-return'],
    accent: '#D4A373',
  },
  {
    key: 'cybersecurity-awareness',
    title: 'Cybersecurity Awareness',
    description: 'Recognising phishing, protecting credentials, and defending accounts from takeover.',
    quizCategory: 'cybersecurity',
    passPercent: 70,
    lessonsHint: ['phishing-attacks', 'password-security', 'digital-banking-security'],
    accent: '#CCD5AE',
  },
  {
    key: 'digital-banking-safety',
    title: 'Digital Banking Safety',
    description: 'Safe UPI practice, payment verification habits, and dispute rights in digital banking.',
    quizCategory: 'digital-payments',
    passPercent: 75,
    lessonsHint: ['upi-safety', 'upi-fraud', 'online-payment-safety'],
    accent: '#D4A373',
  },
  {
    key: 'scam-awareness-prevention',
    title: 'Scam Awareness and Prevention',
    description: 'Detecting fraud patterns across messages, links and platforms — and reporting them effectively.',
    quizCategory: 'scam-detection',
    passPercent: 75,
    lessonsHint: ['otp-scams', 'fake-investment-apps', 'social-engineering'],
    accent: '#CCD5AE',
  },
]

export function courseByKey(key: string): CertCourse | undefined {
  return certCourses.find((c) => c.key === key)
}
