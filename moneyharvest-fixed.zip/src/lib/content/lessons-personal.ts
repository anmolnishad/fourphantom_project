// Money Harvest — Personal Finance lessons
export interface LessonSection { heading: string; body: string[] }
export interface LessonExternalLink { label: string; url: string; source: string }
export interface LessonContent {
  intro: string
  sections: LessonSection[]
  example?: { title: string; body: string }
  keyTerms: { term: string; definition: string }[]
  takeaways: string[]
  externalLinks?: LessonExternalLink[]
}

export interface LessonSeed {
  slug: string
  category: string
  topic: string
  title: string
  summary: string
  level: 'Beginner' | 'Intermediate' | 'Advanced'
  readMinutes: number
  tags: string[]
  content: LessonContent
  related: string[]
}

export const personalFinanceLessons: LessonSeed[] = [
  {
    slug: 'budgeting-fundamentals',
    category: 'personal-finance',
    topic: 'Budgeting fundamentals',
    title: 'Budgeting Fundamentals: Give Every Rupee a Job',
    summary: 'Learn what a budget really is, why most budgets fail, and how to build one you will actually follow using the 50/30/20 rule.',
    level: 'Beginner',
    readMinutes: 7,
    tags: ['budget', '50/30/20', 'expenses', 'planning'],
    related: ['saving-money', 'managing-expenses', 'financial-goal-planning', 'emergency-fund'],
    content: {
      intro: 'A budget is not a punishment — it is a plan you write before your money disappears. It answers three questions: what comes in, what goes out, and what is left to build your future. People who track spending consistently report less financial stress within weeks, not because they earn more, but because they finally see where the money goes.',
      sections: [
        {
          heading: 'What a budget actually does',
          body: [
            'A budget converts vague anxiety ("where did my salary go?") into a concrete list you can control. It reveals silent leaks — subscriptions you forgot, frequent food delivery, impulse online orders — that individually feel small but collectively consume a surprising share of income.',
            'A good budget also acts as an early-warning system. When a category starts running hot in week two, you can adjust course before month-end, instead of discovering the overspend when your balance is already gone.',
          ],
        },
        {
          heading: 'The 50/30/20 starting frame',
          body: [
            'A practical beginner structure is 50% of take-home income for needs (rent, utilities, groceries, transport, insurance premiums), 30% for wants (dining out, entertainment, shopping), and 20% for savings and debt payoff beyond minimums.',
            'These percentages are a starting point, not a law. In expensive cities the needs share may reach 60–65%; compensate by trimming wants first and protecting savings last — never the reverse. The one number to defend fiercely is savings: if savings consistently shrink to zero, the plan needs restructuring, not more willpower.',
          ],
        },
        {
          heading: 'Why most budgets fail — and the fix',
          body: [
            'Most budgets die from two causes: they are too detailed (40 categories nobody updates) or too vague ("spend less"). The fix is a short list of 8–12 categories, reviewed for five minutes weekly, with realistic numbers taken from the last 2–3 months of actual spending rather than aspirational guesses.',
            'The second fix is automation: move the savings amount out on salary day, before you can spend it. Budgets that depend on end-of-month leftovers almost always fail, because human spending expands to fill available cash.',
          ],
        },
        {
          heading: 'Building your first budget in 30 minutes',
          body: [
            'Step 1: List your monthly take-home income. Step 2: Pull last month\u2019s bank statement and group spending into Needs / Wants / Savings-Debt. Step 3: Compare each group against the 50/30/20 targets and pick the single most surprising category as your first trim target. Step 4: Automate a standing transfer to savings on salary day.',
            'Step 5: Set a fixed 5-minute weekly review — every Sunday, check category balances. Small, boring, repeatable reviews beat heroic spreadsheets every time.',
          ],
        },
      ],
      example: {
        title: 'Priya\u2019s ₹40,000 take-home budget',
        body: 'Priya earns ₹40,000 after tax. Needs (rent ₹12,000, food ₹7,000, transport ₹2,500, phone/internet ₹1,000, insurance ₹2,000) = ₹24,500, slightly over the 50% mark. Wants budget = ₹8,000. Savings transfer of ₹7,500 goes out automatically on the 1st. When food spending spiked in week two, she shifted ₹1,500 from the entertainment envelope — the month closed with savings intact for the first time in a year.',
      },
      keyTerms: [
        { term: 'Fixed expense', definition: 'A cost that stays roughly the same every month, such as rent or an insurance premium.' },
        { term: 'Variable expense', definition: 'A cost that changes month to month, such as groceries, fuel or entertainment.' },
        { term: 'Pay yourself first', definition: 'Transferring savings out on income day before spending begins, rather than saving leftovers.' },
        { term: 'Zero-based budget', definition: 'A stricter method where every rupee is assigned a job so income minus allocations equals zero.' },
      ],
      takeaways: [
        'A budget is a spending plan made in advance, not a report of what already happened.',
        'Start with the 50/30/20 rule: 50% needs, 30% wants, 20% savings and extra debt payoff.',
        'Automate savings on salary day — leftover-based saving almost never works.',
        'Keep 8–12 categories and review for 5 minutes weekly; over-detailed budgets are abandoned.',
        'Base budget numbers on real statement data from the last 2–3 months, not guesses.',
      ],
      externalLinks: [
        { label: 'RBI — Financial Awareness Messages', url: 'https://www.rbi.org.in/FinancialAwareness/Pages/Home.aspx', source: 'Reserve Bank of India' },
      ],
    },
  },
  {
    slug: 'saving-money',
    category: 'personal-finance',
    topic: 'Saving money',
    title: 'Saving Money: Systems Beat Motivation',
    summary: 'Why saving feels hard, the saving-rate mindset, and practical techniques — automation, targets, and friction design — that make it stick.',
    level: 'Beginner',
    readMinutes: 6,
    tags: ['saving', 'automation', 'habits'],
    related: ['budgeting-fundamentals', 'emergency-fund', 'compound-interest', 'recurring-deposits'],
    content: {
      intro: 'Saving is less about discipline and more about design. The people who save consistently are not stricter humans; they have arranged their money so the default action is saving, and spending requires extra steps. Building that arrangement is a one-time project that pays you every single month.',
      sections: [
        {
          heading: 'Think in savings rate, not amounts',
          body: [
            'Asking "can I save ₹2,000?" is the wrong question. Ask "what percentage of my income am I keeping?" — your savings rate. Even a modest 10% rate, raised gradually to 20%, transforms finances over a few years because it compounds with every raise you ever get.',
            'A useful ladder: save 5% this month, then increase by 1–2 percentage points each quarter. Because the increase is gradual, your lifestyle barely notices, but your future self collects the difference.',
          ],
        },
        {
          heading: 'Automate first, spend second',
          body: [
            'The most reliable saving system is a standing instruction that moves money to a separate account on salary day. Money you never see is money you never miss; money sitting in your spending account will get spent — that is what spending accounts are for.',
            'Keep savings in a different bank or at least a different account without a debit card. The small friction of moving money back before spending filters out most impulse raids.',
          ],
        },
        {
          heading: 'Name every goal',
          body: [
            '"Saving" is abstract and loses to concrete desires. Naming accounts — "Goa trip", "laptop", "emergency buffer" — measurably improves persistence, because spending from a named goal feels like stealing from a person you care about: your future self.',
            'Pair each goal with a number and a date ("₹30,000 by December") and the monthly required saving becomes obvious arithmetic instead of a vague hope.',
          ],
        },
        {
          heading: 'Cut the big three, not the small joys',
          body: [
            'For most households, three categories dominate overspending: food delivery, subscription stacking, and impulse online shopping. One deliberate change in a big category — cooking three more meals a week, cancelling two unused subscriptions — usually beats agonising over tiny daily coffees.',
            'Keep the small pleasures you genuinely value. Budgets that ban all joy collapse; budgets that protect chosen joys survive.',
          ],
        },
      ],
      example: {
        title: 'The invisible ₹3,000',
        body: 'Aman moved ₹3,000 monthly to a separate online savings account on the 1st of each month, with no debit card attached. In one year he had ₹36,000 plus interest — the first meaningful balance he had ever held. His spending barely changed, because his spending money had never included that ₹3,000.',
      },
      keyTerms: [
        { term: 'Savings rate', definition: 'The percentage of take-home income you keep instead of spend.' },
        { term: 'Standing instruction', definition: 'An automatic recurring bank transfer that runs on a schedule without your involvement.' },
        { term: 'Sinking fund', definition: 'A separate saving pot built monthly for a known future expense, like insurance renewal or a wedding gift season.' },
        { term: 'Friction', definition: 'Small added steps (no saved card, separate login) that slow impulsive spending decisions.' },
      ],
      takeaways: [
        'Track your savings rate (% of income kept), and raise it gradually rather than in one painful jump.',
        'Automate transfers on salary day — pay yourself before anyone else.',
        'Keep savings in a separate account without a debit card to add helpful friction.',
        'Name every goal with an amount and a date; named goals survive, vague goals die.',
        'Attack the big three leaks (delivery, subscriptions, impulse buys) before micro-expenses.',
      ],
      externalLinks: [
        { label: 'RBI Financial Awareness — Savings', url: 'https://www.rbi.org.in/FinancialAwareness/Pages/Home.aspx', source: 'Reserve Bank of India' },
      ],
    },
  },
  {
    slug: 'emergency-fund',
    category: 'personal-finance',
    topic: 'Emergency funds',
    title: 'Emergency Funds: Your First Financial Wall',
    summary: 'How much buffer you need, where to keep it, what counts as an emergency — and why this fund must exist before any investing begins.',
    level: 'Beginner',
    readMinutes: 6,
    tags: ['emergency fund', 'safety net', 'liquidity'],
    related: ['saving-money', 'budgeting-fundamentals', 'fixed-deposits', 'loans-and-interest'],
    content: {
      intro: 'An emergency fund is a pool of cash reserved exclusively for genuine shocks: job loss, medical events, urgent repairs. It is the wall that keeps a bad month from becoming credit-card debt, and credit-card debt from becoming a three-year story. Every financial planner treats it as step zero — before SIPs, before stocks, before anything market-linked.',
      sections: [
        {
          heading: 'How much is enough',
          body: [
            'The standard benchmark is 3 to 6 months of essential expenses — your rent/EMI, food, utilities, transport, insurance — not your full lifestyle spend. Salaried people with stable jobs can aim at 3–4 months; freelancers, single-income families, and people with variable income should hold 6+ months.',
            'Calculate yours in one line: (monthly essential expenses) × (months of cover you want). A household spending ₹25,000 on essentials needs ₹75,000–₹1,50,000 depending on income stability.',
          ],
        },
        {
          heading: 'Where to park it',
          body: [
            'Emergency money must be safe and instantly reachable — growth is not its job. Suitable places: a savings account, a sweep-in fixed deposit, or a liquid mutual fund with instant redemption up to permitted limits.',
            'Avoid locking the fund in long-term FDs with break penalties, and never park it in equity or crypto — markets routinely fall exactly when emergencies strike. Keep it slightly annoying to access (a separate account) but reachable within 24 hours.',
          ],
        },
        {
          heading: 'What counts as an emergency',
          body: [
            'Genuine emergencies: sudden job loss, medical treatment for family, essential home/appliance repair, urgent family travel. Not emergencies: sale seasons, a friend\u2019s destination wedding, the new phone launch, or "the market looks cheap".',
            'Write your personal definition down. A written list turns the fund from a tempting pot into a contract with yourself — and every withdrawal that is not on the list becomes a repayment task, not a free spend.',
          ],
        },
        {
          heading: 'Building and rebuilding',
          body: [
            'Start with a mini-target: one month of essentials (₹15,000–₹30,000 for many people). That single month already absorbs most shocks. Then automate a fixed monthly transfer until you reach full cover.',
            'If you ever use the fund, stop investing and refill it first. The fund is not "wasted money" when used — it did exactly its job: it prevented a loan at 36% annual credit-card interest.',
          ],
        },
      ],
      example: {
        title: 'The ₹18,000 phone that cost ₹58,000',
        body: 'Ravi had no emergency fund when his phone died. He bought a ₹18,000 replacement on his credit card, missed two EMIs during a slow work month, and rolled the balance at ~42% annualised interest. The ₹18,000 purchase became a ₹58,000, fourteen-month burden. One month of essentials parked in a savings account would have ended the story in a day.',
      },
      keyTerms: [
        { term: 'Liquid asset', definition: 'An asset that can be converted to cash quickly without meaningful loss — savings accounts and liquid funds qualify; locked FDs and equity do not.' },
        { term: 'Essential expenses', definition: 'The minimum monthly costs required to run the household: shelter, food, utilities, transport, insurance.' },
        { term: 'Sweep-in FD', definition: 'A fixed deposit linked to your savings account that automatically breaks into usable cash when balance runs low.' },
        { term: 'Liquidity ladder', definition: 'Splitting reserves across instantly-available cash and near-instant instruments to balance access and yield.' },
      ],
      takeaways: [
        'Target 3–6 months of essential expenses; use 6+ if income is variable or single-source.',
        'Keep the fund in savings accounts, sweep-in FDs, or liquid funds — never in equity or crypto.',
        'Write your definition of a genuine emergency before you need it.',
        'Build a first mini-target of one month of essentials, then automate the rest.',
        'After any withdrawal, pause investing and refill the fund before resuming.',
      ],
      externalLinks: [
        { label: 'RBI Financial Awareness Messages', url: 'https://www.rbi.org.in/FinancialAwareness/Pages/Home.aspx', source: 'Reserve Bank of India' },
      ],
    },
  },
  {
    slug: 'managing-expenses',
    category: 'personal-finance',
    topic: 'Managing expenses',
    title: 'Managing Expenses Without Living Like a Monk',
    summary: 'A practical method to audit spending, categorise leaks, negotiate fixed bills, and cut costs you will not even miss.',
    level: 'Beginner',
    readMinutes: 6,
    tags: ['expenses', 'cutting costs', 'audit'],
    related: ['budgeting-fundamentals', 'saving-money', 'credit-cards', 'loans-and-interest'],
    content: {
      intro: 'Managing expenses is not about deprivation; it is about alignment — making sure spending matches what you actually value. Most people discover 10–20% of their money buys things they barely remember buying. Recovering that money requires one honest audit, not endless daily sacrifice.',
      sections: [
        {
          heading: 'Run a 30-day expense audit',
          body: [
            'Export one month of bank and card statements and tag every transaction with a letter: N (need), W (want), S (save/debt). Do not judge during tagging — just label. Patterns appear quickly: recurring charges you forgot, weekend spending clusters, and "convenience" purchases that cost a premium.',
            'The audit itself changes behaviour — this is a well-documented effect. Simply seeing "₹4,800 food delivery" written down triggers a correction no lecture can match.',
          ],
        },
        {
          heading: 'Attack fixed costs first',
          body: [
            'Fixed bills (internet, phone plans, insurance, subscriptions, rent) repeat monthly, so one negotiation improves every future month. Call your provider before renewal and ask for retention offers; compare and switch when the answer is no. A ₹300 monthly saving is ₹3,600 a year — from one phone call.',
            'Rent is the biggest fixed cost for most people. If housing consumes over 35% of take-home pay, no other optimisation will matter; consider sharing, relocating, or renegotiating at renewal.',
          ],
        },
        {
          heading: 'The 24-hour and 30-day rules',
          body: [
            'For non-essential purchases above a threshold you set (say ₹2,000), enforce a 24-hour wait before buying. Most impulse urges evaporate overnight. For big-ticket desires above ₹20,000, extend it to 30 days and add the item to a wishlist.',
            'These rules are not bans — the purchase still happens if it survives the wait. You are simply filtering urgency-driven decisions, which are the ones buyers most often regret.',
          ],
        },
        {
          heading: 'Subscription hygiene',
          body: [
            'Subscriptions are designed to be forgotten. Once a quarter, list every recurring charge, cancel anything unused in the last 30 days, and downgrade plans you barely maximise (do you actually watch on two screens?).',
            'Prefer annual payment only for subscriptions you are certain to keep — annualising monthly plans you rarely use is paying a premium for waste.',
          ],
        },
      ],
      example: {
        title: 'Meera\u2019s ₹5,200 discovery',
        body: 'Meera\u2019s one-month audit revealed ₹2,100 in forgotten subscriptions (three streaming apps, a gym trial that auto-converted, cloud storage on two providers), ₹1,800 in late fees on two bills she could autopay, and ₹1,300 in "convenience" deliveries for items available at the shop downstairs. Cancelling and automating recovered ₹5,200 monthly — without giving up anything she remembered enjoying.',
      },
      keyTerms: [
        { term: 'Expense audit', definition: 'A systematic review of past transactions, labelled by category, to reveal spending patterns.' },
        { term: 'Lifestyle creep', definition: 'The tendency of spending to expand silently as income rises, absorbing raises that were meant to be saved.' },
        { term: 'Autopay', definition: 'An automatic bill payment instruction that eliminates late fees and penalty interest.' },
        { term: 'Retention offer', definition: 'A discount or upgrade a provider extends when you announce cancellation at renewal.' },
      ],
      takeaways: [
        'Audit one month of statements and tag N/W/S — visibility alone cuts waste.',
        'Negotiate or switch fixed bills first; one change repeats every month.',
        'Use a 24-hour rule (small wants) and 30-day rule (big wants) to filter impulse buys.',
        'Review subscriptions quarterly; cancel anything unused in 30 days.',
        'If rent exceeds ~35% of take-home pay, fixing housing outweighs every other saving.',
      ],
      externalLinks: [
        { label: 'RBI Financial Awareness Messages', url: 'https://www.rbi.org.in/FinancialAwareness/Pages/Home.aspx', source: 'Reserve Bank of India' },
      ],
    },
  },
  {
    slug: 'understanding-inflation',
    category: 'personal-finance',
    topic: 'Understanding inflation',
    title: 'Understanding Inflation: The Silent Tax',
    summary: 'What inflation really is, how it erodes savings, the real return formula every saver must know, and how to defend purchasing power.',
    level: 'Beginner',
    readMinutes: 7,
    tags: ['inflation', 'real return', 'purchasing power'],
    related: ['compound-interest', 'fixed-deposits', 'long-term-investing', 'risk-and-return'],
    content: {
      intro: 'Inflation is the rate at which prices rise — and therefore the rate at which the rupee in your pocket quietly shrinks. It is invisible in any single month, devastating across a decade: at 6% annual inflation, ₹100,000 today buys what roughly ₹55,800 buys 10 years from now. Understanding this single mechanism is why "safe" savings accounts can be the riskiest long-term place for money.',
      sections: [
        {
          heading: 'How inflation is measured',
          body: [
            'India tracks inflation mainly through the Consumer Price Index (CPI), a basket of goods and services a typical household buys — food, fuel, housing, healthcare, education. When the basket\u2019s cost rises 6% in a year, CPI inflation is 6%.',
            'Your personal inflation may differ from the headline number: if education and healthcare dominate your spending, your effective inflation is likely higher than the national average, because those categories often rise faster.',
          ],
        },
        {
          heading: 'Real return — the only number that matters',
          body: [
            'Real return = nominal return − inflation. A savings account paying 3.5% during 6% inflation produces a real return of −2.5%: your balance grows, but each rupee buys less. You are losing purchasing power while watching the number rise.',
            'This is the core reason financial education insists long-term money must be deployed into assets that historically outpace inflation — equity, real estate, or at minimum inflation-beating deposits — rather than idle cash.',
          ],
        },
        {
          heading: 'Who wins and who loses',
          body: [
            'Borrowers with fixed-rate loans often gain: repaying a fixed EMI with future, inflated rupees is easier. Savers holding cash lose silently. People whose incomes rise with inflation hold steady; fixed-pension earners fall behind.',
            'For planning, this means (1) avoid holding large idle cash beyond your emergency fund, (2) negotiate periodic income reviews, and (3) prefer investments whose returns are priced to beat inflation over long horizons.',
          ],
        },
        {
          heading: 'Practical defences',
          body: [
            'Defence one: invest according to horizon — short-term money in deposits, long-term money in growth assets. Defence two: review your budget annually against actual price rises, not last year\u2019s numbers. Defence three: increase contributions every time income rises, at least by the inflation rate.',
            'Use the platform\u2019s Inflation Calculator to see what today\u2019s expenses will cost at retirement age — the output usually converts abstract theory into immediate motivation.',
          ],
        },
      ],
      example: {
        title: 'The ₹10 lakh inheritance decision',
        body: 'In 2015, Kabir kept a ₹10,00,000 inheritance in his savings account earning ~4%, feeling "safe". With average CPI inflation near 5–6%, by 2025 its purchasing power had fallen to roughly ₹6,20,000 in 2015 terms — a loss of about 38% while the balance on screen had grown to ₹14,80,000. The account statement said profit; the price of everything he buys said otherwise.',
      },
      keyTerms: [
        { term: 'CPI (Consumer Price Index)', definition: 'The weighted basket of goods/services whose price change measures consumer inflation.' },
        { term: 'Real return', definition: 'Nominal return minus inflation — the true change in purchasing power.' },
        { term: 'Purchasing power', definition: 'The quantity of goods and services a unit of money can actually buy.' },
        { term: 'Headline vs core inflation', definition: 'Headline includes volatile food/fuel; core excludes them to reveal the underlying trend.' },
      ],
      takeaways: [
        'At 6% inflation, prices roughly double every ~12 years; cash halves in purchasing power over the same span.',
        'Real return = nominal return − inflation; a 3.5% account during 6% inflation is a −2.5% real loss.',
        'Idle cash beyond an emergency fund is a slow leak, not safety.',
        'Match assets to horizons: deposits for short term, inflation-beating assets for long term.',
        'Raise your contributions at least in line with inflation every year.',
      ],
      externalLinks: [
        { label: 'RBI — Monetary policy and inflation reports', url: 'https://www.rbi.org.in', source: 'Reserve Bank of India' },
      ],
    },
  },
  {
    slug: 'compound-interest',
    category: 'personal-finance',
    topic: 'Compound interest',
    title: 'Compound Interest: The Eighth Wonder',
    summary: 'How earning interest on interest transforms modest, consistent investing into serious wealth — and how the same force works against you in debt.',
    level: 'Beginner',
    readMinutes: 7,
    tags: ['compound interest', 'wealth', 'time', 'debt'],
    related: ['sip', 'fixed-deposits', 'loans-and-interest', 'long-term-investing'],
    content: {
      intro: 'Simple interest pays only on your original amount. Compound interest pays on your original amount plus every rupee of interest already earned — money starts hiring money. The effect looks boring for a few years and then explosively large, which is why it is often called the eighth wonder: those who understand it, earn it; those who don\u2019t, pay it.',
      sections: [
        {
          heading: 'The mechanics',
          body: [
            'Compound amount = Principal × (1 + r/n)^(n×t), where r is the annual rate, n the compounding frequency per year, and t the years. Compounding monthly (n=12) slightly beats annual compounding at the same nominal rate because interest starts earning interest sooner.',
            'A quick mental tool — the Rule of 72: divide 72 by the annual return to estimate doubling time. At 9%, money doubles roughly every 8 years; at 12%, every 6 years.',
          ],
        },
        {
          heading: 'Time is the dominant variable',
          body: [
            'Consider ₹5,000 monthly at 10% annual return. Starting at age 25 builds about ₹1.0 crore by 50. Starting the identical plan at 35 builds about ₹33 lakh. The ten-year delay cost more than ₹67 lakh — far more than the ₹6 lakh of contributions saved — because the earliest rupees compound through the most doublings.',
            'This asymmetry is the strongest argument in personal finance: begin early, even small. The amount matters, but the start date matters more.',
          ],
        },
        {
          heading: 'Compounding cuts both ways',
          body: [
            'The same formula governs credit-card debt and high-interest loans — with you on the losing side. Revolving a credit-card balance at ~42% annualised effectively doubles what you owe in under two years by the Rule of 72.',
            'This is why financial order of operations exists: kill high-interest debt before investing, because no realistic investment reliably outearns 36–42% interest. Paying off a 42% card is a guaranteed 42% "return".',
          ],
        },
        {
          heading: 'Practical compounding habits',
          body: [
            'Automate monthly investing so compounding never skips a month. Reinvest every payout — interest, dividends, maturity proceeds — because withdrawals reset the snowball. Leave the plan alone: the biggest compounding killer is stopping during downturns.',
            'Use the platform\u2019s Compound Interest and SIP calculators with your real numbers; watching the growth curve bend upward in the final years makes the concept visceral.',
          ],
        },
      ],
      example: {
        title: 'Two friends, one decision',
        body: 'Sneha invests ₹5,000/month from age 25 to 35, then stops entirely (₹6 lakh total). Rohan starts ₹5,000/month at 35 and continues to 50 (₹9 lakh total). At 10% annualised, at age 50 Sneha holds roughly ₹50 lakh while Rohan holds about ₹33 lakh. She invested less, stopped earlier, and still won — because her money compounded longer.',
      },
      keyTerms: [
        { term: 'Principal', definition: 'The original sum of money invested or borrowed.' },
        { term: 'Compounding frequency', definition: 'How often interest is calculated and added (monthly, quarterly, annually) — more frequent is better for savers, worse for borrowers.' },
        { term: 'Rule of 72', definition: 'Divide 72 by annual return (%) to estimate the years required for money to double.' },
        { term: 'Snowball effect', definition: 'The accelerating growth pattern where accumulated returns themselves generate returns.' },
      ],
      takeaways: [
        'Compound growth = interest earning interest; the curve bends sharply upward in later years.',
        'Rule of 72: 72 ÷ annual return ≈ years to double your money.',
        'Starting ten years earlier can matter more than investing twice as much.',
        'The same force works in reverse on debt — kill 36%+ credit-card balances before investing.',
        'Automate, reinvest, and never interrupt compounding unnecessarily.',
      ],
      externalLinks: [
        { label: 'RBI Financial Awareness Messages', url: 'https://www.rbi.org.in/FinancialAwareness/Pages/Home.aspx', source: 'Reserve Bank of India' },
      ],
    },
  },
  {
    slug: 'financial-goal-planning',
    category: 'personal-finance',
    topic: 'Financial goal planning',
    title: 'Financial Goal Planning: From Wishes to Numbers',
    summary: 'Turn vague aspirations into SMART goals, split them by horizon, compute the required monthly saving, and build the review loop that keeps plans alive.',
    level: 'Beginner',
    readMinutes: 7,
    tags: ['goals', 'planning', 'SMART', 'horizon'],
    related: ['budgeting-fundamentals', 'compound-interest', 'sip', 'risk-and-return'],
    content: {
      intro: '"I want to be rich" is a wish. "₹25 lakh for a house down payment in 7 years" is a goal — something you can reverse-engineer into a monthly number and actually achieve. Goal planning is the bridge between earning money and money having a direction, and it takes one afternoon with a calculator and your real numbers.',
      sections: [
        {
          heading: 'Make goals SMART',
          body: [
            'Specific, Measurable, Achievable, Relevant, Time-bound. "Save for a car" fails the test; "accumulate ₹8,00,000 by March 2029 for a car down payment" passes — it names the amount, the date, and the purpose.',
            'SMART framing matters because it converts motivation into arithmetic: (Target − existing savings) ÷ months remaining = required monthly saving. Suddenly the goal is a line in your budget, not a hope.',
          ],
        },
        {
          heading: 'Sort goals by horizon',
          body: [
            'Short-term (0–3 years): emergency fund, vacation, insurance deductibles — keep in savings, RDs, or liquid funds; risk is unnecessary and inappropriate here. Medium-term (3–7 years): car, home down payment, education — blended debt-heavy allocations or recurring deposits.',
            'Long-term (7+ years): retirement, children\u2019s education — equity-heavy instruments (SIPs in index or diversified funds, retirement accounts) because time smooths volatility and equity has historically beaten inflation over long periods.',
          ],
        },
        {
          heading: 'Price tomorrow\u2019s goals today',
          body: [
            'A ₹25 lakh goal 15 years away is not ₹25 lakh of today\u2019s money. At 6% inflation it is closer to ₹60 lakh of future rupees. Planning in future-value terms prevents the most common failure: reaching the target date with the number achieved but the goal unaffordable.',
            'Use the platform\u2019s Inflation Calculator to convert goals into future cost, then the SIP Calculator to find the monthly investment that reaches that future number.',
          ],
        },
        {
          heading: 'The review loop',
          body: [
            'Review goals twice a year. Celebrate progress visibly (charts work), adjust contributions when income changes, and re-balance allocations as horizons shorten — money for a goal 3 years away should progressively move out of equity.',
            'Write goals where you will see them. Unreviewed goals decay into abandoned goals; a 15-minute quarterly review is the maintenance cost of an entire financial future.',
          ],
        },
      ],
      example: {
        title: 'The ₹25 lakh down payment, backward-planned',
        body: 'Anita wants ₹25 lakh in 7 years. Inflating at 6%, the future cost is ~₹37.6 lakh. Starting from zero at ~11% expected long-term equity-fund return, she needs about ₹27,000/month — too high. So she extends the plan to 9 years and adds existing ₹2 lakh savings as seed; the required SIP drops to ~₹21,000, which fits her budget after an expense audit. The goal moved from fantasy to instalment.',
      },
      keyTerms: [
        { term: 'SMART goal', definition: 'A goal that is Specific, Measurable, Achievable, Relevant and Time-bound.' },
        { term: 'Time horizon', definition: 'How long until you need the money — the primary driver of suitable investments.' },
        { term: 'Future value', definition: 'What a current goal costs after inflation by the time you must pay for it.' },
        { term: 'Goal-based investing', definition: 'Assigning each investment account to a named goal with its own horizon and target.' },
      ],
      takeaways: [
        'Convert every wish into amount + date; required monthly saving becomes simple arithmetic.',
        'Short-term money belongs in safe instruments; only 7+ year money belongs in equity.',
        'Always plan in future (inflated) rupees, not today\u2019s rupees.',
        'Adjust contribution, timeline, or target — not all three hopes at once.',
        'Review every 6 months; unreviewed plans quietly die.',
      ],
      externalLinks: [
        { label: 'SEBI Investor Education', url: 'https://investor.sebi.gov.in', source: 'SEBI' },
      ],
    },
  },
]
