// Money Harvest — Curated external learning resources (verified official/reputable sources)
export interface ResourceSeed {
  title: string
  description: string
  url: string
  category: string
  level: string
  source: string
}

export const resourceCategories = [
  { key: 'financial-literacy', title: 'Financial Literacy' },
  { key: 'investment', title: 'Investment Fundamentals' },
  { key: 'cybersecurity', title: 'Cybersecurity' },
  { key: 'scam-prevention', title: 'Online Scam Prevention' },
  { key: 'banking-digital-payments', title: 'Banking & Digital Payments' },
  { key: 'ai-technology', title: 'AI & Technology' },
]

export const resourceSeeds: ResourceSeed[] = [
  // Financial literacy
  { title: 'RBI Financial Awareness Messages', description: 'The Reserve Bank of India\u2019s official consumer-awareness series covering savings, deposits, digital payments and fraud caution. Authoritative and regularly updated.', url: 'https://www.rbi.org.in/FinancialAwareness/Pages/Home.aspx', category: 'financial-literacy', level: 'Beginner', source: 'Reserve Bank of India' },
  { title: 'SEBI Investor Education Portal', description: 'Official SEBI portal for investor protection: how to verify intermediaries, understand market risks, and file complaints. Essential reading before any investment.', url: 'https://investor.sebi.gov.in', category: 'financial-literacy', level: 'Beginner', source: 'SEBI' },
  { title: 'AMFI — Mutual Fund Education', description: 'The Association of Mutual Funds in India\u2019s learning material on how mutual funds, NAVs, SIPs and expense ratios actually work.', url: 'https://www.amfiindia.com', category: 'financial-literacy', level: 'Beginner', source: 'AMFI' },

  // Investment
  { title: 'NSE India — Market Data & Education', description: 'National Stock Exchange\u2019s official site: market data, listings, and investor education resources on how Indian equity markets operate.', url: 'https://www.nseindia.com', category: 'investment', level: 'Intermediate', source: 'NSE' },
  { title: 'BSE India — Investor Education', description: 'BSE\u2019s investor-awareness section covering trading basics, rights of investors, and the Sensex ecosystem.', url: 'https://www.bseindia.com', category: 'investment', level: 'Beginner', source: 'BSE' },
  { title: 'RBI Retail Direct', description: 'Open a free account directly with the RBI to invest in government securities and T-Bills — the cleanest official entry point to bond investing.', url: 'https://www.rbi.org.in', category: 'investment', level: 'Intermediate', source: 'Reserve Bank of India' },
  { title: 'Investor.gov — SEC (English)', description: 'The US SEC\u2019s investor-education site; its fundamentals sections (risk & return, diversification, compounding) are language-independent and excellent.', url: 'https://www.investor.gov', category: 'investment', level: 'Beginner', source: 'US SEC' },

  // Cybersecurity
  { title: 'National Cyber Crime Reporting Portal', description: 'The official Government of India portal to report cyber fraud — file complaints, track them, and learn from current threat advisories. Helpline: 1930.', url: 'https://cybercrime.gov.in', category: 'cybersecurity', level: 'Beginner', source: 'MHA, Government of India' },
  { title: 'Sanchar Saathi — Chakshu & TAFCOP', description: 'DoT\u2019s official portal: report fraudulent calls and SMS (Chakshu), check mobile connections registered in your name (TAFCOP), and block lost phones.', url: 'https://sancharsaathi.gov.in', category: 'cybersecurity', level: 'Beginner', source: 'DoT, Government of India' },
  { title: 'CERT-In — Indian Computer Emergency Response Team', description: 'India\u2019s national cybersecurity agency: official advisories, vulnerability notes and safety guidelines for citizens and organisations.', url: 'https://www.cert-in.org.in', category: 'cybersecurity', level: 'Intermediate', source: 'CERT-In, MeitY' },
  { title: 'Cyber Swachhta Kendra', description: 'Government initiative offering free bot-cleanup and security tools, plus practical device-security guidance.', url: 'https://www.cert-in.org.in', category: 'cybersecurity', level: 'Beginner', source: 'CERT-In, MeitY' },

  // Scam prevention
  { title: 'RBI — Beware of Fraudsters (Awareness)', description: 'RBI\u2019s consolidated warnings on digital frauds: OTP scams, fake KYC calls, UPI frauds and the "digital arrest" pattern. Read once; recognise forever.', url: 'https://www.rbi.org.in', category: 'scam-prevention', level: 'Beginner', source: 'Reserve Bank of India' },
  { title: 'SEBI — Cautionary Advisories', description: 'Official SEBI list of unregistered entities and fraudulent investment platforms. Cross-check any platform here before investing a rupee.', url: 'https://www.sebi.gov.in', category: 'scam-prevention', level: 'Intermediate', source: 'SEBI' },
  { title: 'NPCI — UPI Safe Payment Practices', description: 'The organisation that runs UPI explains its safety features and the official do\u2019s and don\u2019ts of instant payments.', url: 'https://www.npci.org.in', category: 'scam-prevention', level: 'Beginner', source: 'NPCI' },

  // Banking & digital payments
  { title: 'DICGC — Deposit Insurance', description: 'Learn exactly how the ₹5-lakh-per-bank deposit insurance works, which institutions are covered, and how claims process.', url: 'https://www.dicgc.org.in', category: 'banking-digital-payments', level: 'Beginner', source: 'DICGC' },
  { title: 'RBI — Integrated Ombudsman (CMS)', description: 'The official complaint-resolution portal for banking and payment grievances that your bank hasn\u2019t resolved — free, structured escalation.', url: 'https://cms.rbi.org.in', category: 'banking-digital-payments', level: 'Intermediate', source: 'Reserve Bank of India' },
  { title: 'TransUnion CIBIL — Credit Education', description: 'Official CIBIL resource for understanding credit scores and reports, plus the process for your free annual report and disputes.', url: 'https://www.cibil.com', category: 'banking-digital-payments', level: 'Beginner', source: 'TransUnion CIBIL' },
  { title: 'India Post Payments & Savings Schemes', description: 'Government-backed savings options: post-office RDs, NSCs and payment-bank services with different risk profiles from bank products.', url: 'https://www.indiapost.gov.in', category: 'banking-digital-payments', level: 'Beginner', source: 'India Post' },

  // AI & technology
  { title: 'NASSCOM — Emerging Technology Insights', description: 'India\u2019s tech-industry body publishes accessible explainers on AI adoption, security implications and digital-skilling for learners.', url: 'https://nasscom.in', category: 'ai-technology', level: 'Intermediate', source: 'NASSCOM' },
  { title: 'Digital India — Digital Literacy', description: 'The Government of India\u2019s digital-literacy initiatives, including safe internet practices for citizens across all ages.', url: 'https://www.digitalindia.gov.in', category: 'ai-technology', level: 'Beginner', source: 'Government of India' },
]
