// Money Harvest — Lesson library (source of truth, seeded to DB)
import { personalFinanceLessons, type LessonSeed } from './lessons-personal'
import { investmentLessons } from './lessons-investment'
import { bankingLessons } from './lessons-banking'
import { cybersecurityLessons } from './lessons-cyber'

export type { LessonSeed, LessonContent, LessonSection, LessonExternalLink } from './lessons-personal'

export const allLessons: LessonSeed[] = [
  ...personalFinanceLessons,
  ...investmentLessons,
  ...bankingLessons,
  ...cybersecurityLessons,
]

export const lessonCategories = [
  { key: 'personal-finance', title: 'Personal Finance', description: 'Budgeting, saving, inflation and goal planning — the foundations every rupee decision rests on.', icon: 'Wallet' },
  { key: 'investment', title: 'Investment Education', description: 'Stocks, mutual funds, SIPs, bonds and risk — how money grows when you put it to work.', icon: 'TrendingUp' },
  { key: 'banking', title: 'Banking Knowledge', description: 'Accounts, statements, UPI, cards, loans and credit scores — the mechanics of the system you use daily.', icon: 'Landmark' },
  { key: 'cybersecurity', title: 'Cybersecurity', description: 'Phishing, OTP scams, fake apps and identity theft — protecting the money you\u2019ve worked to build.', icon: 'ShieldCheck' },
] as const

export function lessonsByCategory(category: string): LessonSeed[] {
  return allLessons.filter((l) => l.category === category)
}
