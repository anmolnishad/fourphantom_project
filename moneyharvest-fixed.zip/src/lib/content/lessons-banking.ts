// Money Harvest — Banking Knowledge lessons
import type { LessonSeed } from './lessons-personal'

export const bankingLessons: LessonSeed[] = [
  {
    slug: 'savings-accounts',
    category: 'banking',
    topic: 'Savings accounts',
    title: 'Savings Accounts: Your Money\u2019s Home Base',
    summary: 'How savings account interest works, choosing the right bank, DICGC insurance, minimum-balance rules and the features that actually matter.',
    level: 'Beginner',
    readMinutes: 6,
    tags: ['savings account', 'DICGC', 'interest', 'banking'],
    related: ['fixed-deposits', 'emergency-fund', 'bank-statements', 'digital-banking-security'],
    content: {
      intro: 'A savings account is where money lives between jobs — safe, accessible, earning a little interest. It is not an investment; it is infrastructure. Choosing one well (and keeping it secure) quietly improves every other financial decision you make.',
      sections: [
        {
          heading: 'Interest and the real deal',
          body: [
            'Indian banks pay roughly 2.5–7% on savings balances, computed on daily balances and credited quarterly or monthly depending on the bank. Small finance banks often pay the top of the range; large public banks the lower end.',
            'Whatever the rate, remember the inflation lesson: idle balances above your emergency fund lose purchasing power. Keep 3–6 months of essentials here, sweep the surplus into FDs or investments.',
          ],
        },
        {
          heading: 'Choosing a bank that fits',
          body: [
            'Compare on: net-banking/app quality (you will live there), branch/ATM proximity if you need cash often, minimum-balance requirements and penalty rules, FD rates, and service reputation. Small finance banks are DICGC-insured up to the same ₹5 lakh per depositor per bank as giants.',
            'Keep two accounts: a spending account (salary credit, UPI, bills) and a savings account at another bank (emergency fund, goal pots, no debit card). Different banks add friction against impulse raids — and give you a backup if one bank\u2019s app goes down.',
          ],
        },
        {
          heading: 'Minimum balance, charges and hygiene',
          body: [
            'Falling below minimum balance triggers penalties; some accounts (Jan Dhan, basic, salary) waive it. Check debit-card annual fees, SMS charges, and IMPS/NEFT pricing — small charges compound into silent drains.',
            'Hygiene: update your mobile number and email immediately after any change (critical for OTPs and alerts), nominate a beneficiary, review statements monthly, and never let anyone else operate on your behalf via "remote desktop" or shared credentials — that pattern precedes most account-takeover fraud.',
          ],
        },
      ],
      example: {
        title: 'Two accounts, one calm year',
        body: 'Nisha split her finances: salary landed in Bank A (spending, UPI, autopays); a standing instruction moved 20% to Bank B (no card attached). Impulse purchases never touched savings; when Bank A\u2019s app had a weekend outage, Bank B\u2019s UPI still worked. Total cost of this system: one standing instruction and ten minutes of setup.',
      },
      keyTerms: [
        { term: 'Minimum average balance', definition: 'The average monthly/quarterly balance required to avoid penalties; varies by bank and account tier.' },
        { term: 'Nominee', definition: 'The person legally designated to receive the account balance after the holder\u2019s death — always fill this.' },
        { term: 'Daily balance interest', definition: 'Savings interest computed on each day\u2019s closing balance, rewarding even short spikes.' },
        { term: 'DICGC cover', definition: '₹5 lakh insurance per depositor per bank on savings, FD, RD and current balances combined.' },
      ],
      takeaways: [
        'Savings accounts are infrastructure, not investments — keep only emergency cover idle here.',
        'Prefer banks on app quality and service; DICGC insures small banks up to ₹5 lakh equally.',
        'Maintain a separate no-card savings account at a second bank for real savings.',
        'Update contact details immediately — OTPs and fraud alerts depend on them.',
        'Review monthly statements; small recurring charges are silent drains.',
      ],
      externalLinks: [
        { label: 'DICGC — Deposit insurance', url: 'https://www.dicgc.org.in', source: 'DICGC' },
        { label: 'RBI — Consumer information', url: 'https://www.rbi.org.in', source: 'Reserve Bank of India' },
      ],
    },
  },
  {
    slug: 'current-accounts',
    category: 'banking',
    topic: 'Current accounts',
    title: 'Current Accounts: Business Banking 101',
    summary: 'What current accounts offer over savings accounts, who needs one, overdraft facilities, and how business banking differs from personal.',
    level: 'Intermediate',
    readMinutes: 5,
    tags: ['current account', 'business', 'overdraft'],
    related: ['savings-accounts', 'bank-statements', 'loans-and-interest', 'digital-banking-security'],
    content: {
      intro: 'A current account is built for transactions, not savings: unlimited debits, high volumes, no interest paid, and tools for business operation. Freelancers, shops, and companies use them to separate business money from personal money — a separation that simplifies taxes, professionalism and audit trails.',
      sections: [
        {
          heading: 'Current vs savings at a glance',
          body: [
            'Current accounts: unlimited transactions, no interest, minimum balances typically higher, overdraft possible, designed for frequent collections and payments. Savings accounts: interest earned, transaction limits may apply, built for individuals.',
            'If you receive business payments regularly — even ₹20,000/month freelancing — a current account keeps revenue and personal spending cleanly separated, which GST and income-tax preparation make genuinely valuable.',
          ],
        },
        {
          heading: 'Overdrafts and facilities',
          body: [
            'Many current accounts include overdraft (OD) sanction — borrowing up to a limit when cash runs dry, with interest charged only on used amounts. ODs are working-capital tools, not free money; misused, they become expensive debt.',
            'Other facilities: bulk payments, collection gateways, cheque books with higher limits, and multi-user access with maker-checker controls for small teams.',
          ],
        },
        {
          heading: 'Opening and operating safely',
          body: [
            'KYC for current accounts needs business proof (GST registration, shop licence, professional certificates, or Udyam registration for micro businesses). Expect the bank to ask — it is a regulatory requirement, and legitimate banks never ask you to skip it.',
            'Separation discipline: pay yourself a fixed monthly transfer from the current to personal account instead of dipping ad hoc. That single habit makes business profitability visible within a quarter.',
          ],
        },
      ],
      example: {
        title: 'The freelancer\u2019s clean ledger',
        body: 'Arjun moved his ₹60,000/month freelance revenue into a current account, paid himself ₹45,000 monthly, and let GST set-aside (₹10,800) plus software subscriptions flow from the business side. Filing season, which once took a week of statement archaeology, became an afternoon — the account had already told the story.',
      },
      keyTerms: [
        { term: 'Overdraft (OD)', definition: 'A sanctioned borrowing limit on a current account; interest applies only to the used portion.' },
        { term: 'Maker-checker', definition: 'A dual-approval control where one user initiates payments and another authorises them.' },
        { term: 'KYC', definition: 'Know Your Customer — identity verification required by regulation before operating accounts.' },
        { term: 'Udyam registration', definition: 'Government registration for micro/small enterprises, accepted as business proof.' },
      ],
      takeaways: [
        'Current accounts serve transactions; savings accounts serve individuals\u2019 saving.',
        'Any regular business income justifies a current account for clean separation.',
        'Overdrafts are working-capital tools with real interest — not free money.',
        'Expect and welcome KYC; banks asking to bypass it are not banks.',
        'Pay yourself a fixed salary from the business account to see true profitability.',
      ],
      externalLinks: [
        { label: 'RBI — Customer service & information', url: 'https://www.rbi.org.in', source: 'Reserve Bank of India' },
      ],
    },
  },
  {
    slug: 'bank-statements',
    category: 'banking',
    topic: 'Bank statements',
    title: 'Reading Bank Statements Like an Auditor',
    summary: 'How to read every column of a statement, spot errors and fraud early, reconcile balances, and use statements for budgeting and loans.',
    level: 'Beginner',
    readMinutes: 6,
    tags: ['statement', 'reconciliation', 'fraud detection', 'audit'],
    related: ['savings-accounts', 'managing-expenses', 'budgeting-fundamentals', 'upi-fraud'],
    content: {
      intro: 'Your bank statement is a complete diary of your financial behaviour — and the single best early-warning device against both wasteful habits and active fraud. Most fraud is discovered weeks late because nobody reads statements. A five-minute monthly reading habit closes that gap.',
      sections: [
        {
          heading: 'The columns, decoded',
          body: [
            'Date (transaction date), narration (code describing the counterparty — learn your bank\u2019s prefixes: UPI/, NEFT/, IMPS/, ECS/ACH for auto-debits), reference number (useful for disputes), debit/credit amounts, and running balance.',
            'The running balance is the integrity check: after every transaction, balance + credit − debit should equal the new balance. If it ever doesn\u2019t, or you find a transaction you cannot place, contact the bank immediately — disputes have time limits.',
          ],
        },
        {
          heading: 'The five-minute monthly audit',
          body: [
            'Scan for: (1) unfamiliar debits — even ₹99 subscriptions are often trial conversions; (2) duplicate charges; (3) auto-debits you forgot (ECS/NACH); (4) small "test" debits of ₹1–₹10, which are fraudsters verifying a card before a larger hit; (5) salary credits matching expectation.',
            'Anything unfamiliar → note reference number → check with family (shared cards cause confusion) → report to bank in writing (email creates a timestamped record).',
          ],
        },
        {
          heading: 'Statements as financial tools',
          body: [
            'For budgeting: export 3 months to CSV and categorise — this feeds the 50/30/20 exercise in the budgeting lesson with real data instead of guesses.',
            'For loans: banks request 6–12 months of statements to assess income stability and existing EMIs. Clean, consistent statements with steady savings improve approval odds; bounced-EMI entries and gambling-style churn hurt. Statements are your financial résumé — keep them presentable.',
          ],
        },
      ],
      example: {
        title: 'The ₹1 probe',
        body: 'Tara\u2019s monthly audit found two ₹1 debits from a merchant she didn\u2019t recognise. Her card had been skimmed; the fraudster was testing validity before a ₹24,000 attempt. Because she caught the probe and blocked the card the same day, the large debit never happened. Statement reading is boring until the day it is heroic.',
      },
      keyTerms: [
        { term: 'Narration', definition: 'The bank\u2019s coded description of each transaction, identifying source/counterparty.' },
        { term: 'NACH/ECS debit', definition: 'An auto-debit mandate (EMIs, insurance, SIPs) that pulls money on schedule.' },
        { term: 'Reconciliation', definition: 'Matching your own records against the bank\u2019s to confirm both agree.' },
        { term: 'Chargeback', definition: 'A formal dispute process reversing an unauthorised or undelivered card transaction.' },
      ],
      takeaways: [
        'Read statements monthly — early discovery is the difference between annoyance and loss.',
        'Verify the running balance chain; investigate any break immediately.',
        'Watch specifically for ₹1–₹10 test debits and forgotten NACH mandates.',
        'Report disputes in writing with reference numbers; time limits apply.',
        'Statements double as budgeting data and your financial résumé for lenders.',
      ],
      externalLinks: [
        { label: 'RBI — Ombudsman & complaint escalation', url: 'https://www.rbi.org.in', source: 'Reserve Bank of India' },
      ],
    },
  },
  {
    slug: 'upi-safety',
    category: 'banking',
    topic: 'UPI safety',
    title: 'UPI Safety: Fast Payments, Calm Nerves',
    summary: 'How UPI actually moves money, the collect-request and QR scams that abuse it, and the safety habits that keep instant payments safe.',
    level: 'Beginner',
    readMinutes: 7,
    tags: ['UPI', 'payments', 'QR', 'collect request', 'NPCI'],
    related: ['upi-fraud', 'otp-scams', 'online-payment-safety', 'digital-banking-security'],
    content: {
      intro: 'UPI (Unified Payments Interface), built by NPCI, moves money between bank accounts instantly, 24×7, free for individuals. Its speed is also its danger: completed payments cannot be casually reversed, so every scam that once needed a bank visit now needs only a persuasive message. Understanding the mechanism is 80% of the defence.',
      sections: [
        {
          heading: 'The one rule that prevents most UPI fraud',
          body: [
            'To RECEIVE money, you never enter a PIN. Sending requires your UPI PIN; receiving requires nothing but your UPI ID or QR. Any "approve this to get your refund/cashback/sale proceeds" flow that asks for a PIN or a collect-request approval is theft in progress.',
            'Collect requests (a demand notification "SBI Maintenance: pay ₹2 to verify") are the workhorse of UPI scams. Legitimate parties cannot pull money without your explicit PIN authorisation — so decline every unexpected request, however official the sender name looks (names are freely typed by requesters).',
          ],
        },
        {
          heading: 'Screenshots, QR traps and fake apps',
          body: [
            'Seller-side scams use doctored payment screenshots or "payment pending, complete it here" QR codes that actually request money. Verify receipts in YOUR bank app — never trust the buyer\u2019s screenshot or SMS lookalikes.',
            'Install payment apps only from official app stores; lookalike APKs sent over WhatsApp steal PINs. Check the exact app publisher name; fake apps replace single letters (PayTm vs Paytm) and request accessibility permissions to read everything on screen.',
          ],
        },
        {
          heading: 'Habits of safe UPI users',
          body: [
            'Set a low per-transaction and daily UPI limit in your app; a ₹10,000 cap turns catastrophic fraud into survivable fraud. Enable app lock and transaction notifications. Use a dedicated UPI ID for selling publicly (OLX/marketplace) rather than your primary.',
            'If defrauded: report inside the payment app, call your bank, dial 1930 (cyber fraud helpline) within the golden hour — fast reporting can freeze funds mid-chain — and file at cybercrime.gov.in. Also report the number via Chakshu (sancharsaathi.gov.in).',
          ],
        },
      ],
      example: {
        title: 'The ₹2 "verification"',
        body: 'A seller on a marketplace received "SBI: verify account to receive ₹8,500 — approve the ₹2 request". The request looked official and tiny. One PIN later, ₹9,500 left his account — the ₹2 request had carried a hidden amount via a modified flow on a fake app. Had he known the rule — receiving needs no PIN — the entire class of scam would have bounced off him.',
      },
      keyTerms: [
        { term: 'UPI ID / VPA', definition: 'Your payment address (name@bank) that receives money without exposing account numbers.' },
        { term: 'Collect request', definition: 'A money DEMAND pushed to your app; approving it with your PIN sends money away.' },
        { term: 'NPCI', definition: 'National Payments Corporation of India — the umbrella body that operates UPI.' },
        { term: 'Golden hour', definition: 'The first 60 minutes after fraud, when rapid reporting most often freezes stolen funds.' },
      ],
      takeaways: [
        'Receiving money never requires a PIN — any flow that says otherwise is fraud.',
        'Decline unexpected collect requests; requester names are not verified.',
        'Verify payments only in your own bank app, never via screenshots or SMS.',
        'Set low UPI limits, enable app lock, use a secondary UPI ID for public selling.',
        'If hit: call 1930, alert the bank, file at cybercrime.gov.in — speed decides recovery.',
      ],
      externalLinks: [
        { label: 'NPCI — UPI information', url: 'https://www.npci.org.in', source: 'NPCI' },
        { label: 'Cyber Crime Reporting Portal', url: 'https://cybercrime.gov.in', source: 'MHA, Government of India' },
      ],
    },
  },
  {
    slug: 'credit-cards',
    category: 'banking',
    topic: 'Credit cards',
    title: 'Credit Cards: Powerful Tool, Loaded Weapon',
    summary: 'How credit card billing cycles and interest actually work, why "minimum due" is a trap, using grace periods, and building credit health.',
    level: 'Beginner',
    readMinutes: 7,
    tags: ['credit card', 'grace period', 'minimum due', 'credit score'],
    related: ['credit-scores', 'loans-and-interest', 'managing-expenses', 'saving-money'],
    content: {
      intro: 'A credit card is a 45-day interest-free loan — if you repay in full — and a 36–42% annual debt engine — if you don\u2019t. The difference between those two outcomes is a single habit: paying the TOTAL amount due, not the "minimum due". Everything else about credit cards is detail hanging off that one lever.',
      sections: [
        {
          heading: 'The billing cycle and grace period',
          body: [
            'Your statement closes on a date (say the 5th); purchases made after the close date fall in the next cycle. You then get ~15–20 days to pay. Combined, this "grace period" can stretch to 45+ days of free credit.',
            'Grace applies only if the previous bill was paid IN FULL. Carry even ₹100 forward and new purchases start attracting interest from their transaction dates — no grace — plus interest on the carried amount itself.',
          ],
        },
        {
          heading: 'The minimum-due trap',
          body: [
            'Paying the "minimum due" (typically 5% of the bill) avoids late fees and protects your credit score — but the remaining balance compounds at ~3.5% per month (≈42% annualised), and interest charges bill you the following month, where they too can compound.',
            'A ₹50,000 balance paid at minimums can take years to clear and cost over ₹20,000 extra. If you cannot pay in full this month: stop using the card, pay as much as possible, and consider converting the balance to a lower-rate EMI plan rather than revolving.',
          ],
        },
        {
          heading: 'Cash withdrawals and fees',
          body: [
            'ATM cash withdrawal on a credit card attracts interest from DAY ONE (no grace) plus a fee — treat it as forbidden except in true emergencies. Watch foreign-transaction marks (3.5%+), annual fees (negotiable against spend or waiveable on lifetime-free cards), and EMI "no-cost" offers that often bake interest into the price.',
          ],
        },
        {
          heading: 'Cards as credit-score builders',
          body: [
            'Used well — small utilisation, full timely repayment — cards build the credit history that later earns you cheaper home-loan rates. Keep utilisation under ~30% of limits, never miss due dates (set autopay for the full amount), and keep old cards open, since history length helps your score.',
            'Check your report annually at the CIBIL (or equivalent bureau) site; errors are correctable and worth fixing before any loan application.',
          ],
        },
      ],
      example: {
        title: 'Two payers, one ₹40,000 bill',
        body: 'Both received a ₹40,000 bill. Meera autopaid the full amount and paid ₹0 interest; her effective 45-day float even earned her savings-account interest. Vikram paid the ₹2,000 minimum. Eighteen months later his balance was still ₹28,000, he had paid ₹11,400 in interest, and his score had dipped from high utilisation. Same card, same month — opposite endings.',
      },
      keyTerms: [
        { term: 'Total amount due', definition: 'The full statement balance; paying this preserves the interest-free grace period.' },
        { term: 'Minimum due', definition: '~5% of the bill that avoids penalties but leaves the rest compounding at ~40%+ annualised.' },
        { term: 'Credit utilisation ratio', definition: 'Used credit ÷ total limit; keeping it below ~30% supports your score.' },
        { term: 'Reward devaluation', definition: 'Programs cutting point values over time; spend rewards on things you\u2019d buy anyway, never to "earn back" spending.' },
      ],
      takeaways: [
        'Always pay the TOTAL amount due — the single most important card habit.',
        'Minimum due = maximum trap: ~42% annualised interest and lost grace periods.',
        'Never withdraw cash on a credit card; interest starts instantly.',
        'Keep utilisation under 30%, autopay full statements, keep old cards open.',
        'Rewards are a discount on planned spending, never a reason for unplanned spending.',
      ],
      externalLinks: [
        { label: 'CIBIL — Credit information', url: 'https://www.cibil.com', source: 'TransUnion CIBIL' },
        { label: 'RBI — Card rules & customer rights', url: 'https://www.rbi.org.in', source: 'Reserve Bank of India' },
      ],
    },
  },
  {
    slug: 'loans-and-interest',
    category: 'banking',
    topic: 'Loans and interest',
    title: 'Loans and Interest: Borrowing Without Regret',
    summary: 'How EMIs amortise, why tenure costs more than rate suggests, flat vs reducing balance deception, prepayment strategy and safe borrowing rules.',
    level: 'Intermediate',
    readMinutes: 8,
    tags: ['loan', 'EMI', 'amortisation', 'prepayment'],
    related: ['credit-cards', 'compound-interest', 'credit-scores', 'financial-goal-planning'],
    content: {
      intro: 'A loan converts tomorrow\u2019s income into today\u2019s purchasing power, at a price. Borrowed well (home, education, a genuinely necessary asset), it is a ladder. Borrowed casually (gadgets, weddings, lifestyle), it is an anchor. The difference is understanding EMIs, tenures and the honest cost of interest.',
      sections: [
        {
          heading: 'How an EMI actually works',
          body: [
            'EMI = a fixed payment whose interest and principal split shifts over time: early EMIs are mostly interest (the outstanding is largest), later EMIs mostly principal. This is amortisation — use the platform\u2019s EMI Calculator to see the full year-by-year split.',
            'The total-interest shock: a ₹30 lakh, 20-year home loan at 9% costs about ₹31 lakh in interest on top of principal — nearly doubling the house. Tenure is the hidden price tag; a 15-year tenure at the same rate saves roughly ₹8–9 lakh versus 20.',
          ],
        },
        {
          heading: 'Flat vs reducing balance — the classic deception',
          body: [
            '"Flat rate" loans (common in vehicle finance and consumer durables) compute interest on the ORIGINAL principal throughout, even as you repay. A "10% flat" loan ≈ 17–18% reducing-balance equivalent — nearly double the quoted number.',
            'Banks and NBFCs quote reducing-balance rates for home/personal loans; consumer durables and some vehicle finance quote flat. Always ask: "Is this rate flat or reducing, and what is the annualised reducing equivalent?"',
          ],
        },
        {
          heading: 'Prepayment — the highest-return move available',
          body: [
            'Prepaying a 9% loan is a guaranteed, tax-free 9% return — no investment offers that certainty. Prepay early in the tenure, when EMIs are interest-heavy; even one extra EMI per year on a 20-year home loan can cut 3–4 years and lakhs in interest.',
            'RBI rules bar prepayment penalties on floating-rate loans to individuals; fixed-rate loans may carry small charges. Check the schedule after prepaying — banks sometimes reduce EMI instead of tenure, which helps cashflow but saves far less interest. Always choose tenure reduction for interest savings.',
          ],
        },
        {
          heading: 'Safe borrowing rules',
          body: [
            'Total EMIs should stay under ~40% of take-home income (under 30% is more comfortable). Borrow against appreciating or income-producing assets; avoid depreciation purchases on debt. Maintain 3–6 months of EMI in emergency cover so a job gap never becomes a default.',
            'Compare the ANNUAL PERCENTAGE-style total cost, not just rate: processing fees, insurance bundles, and documentation charges can add 1–2%. And never borrow to invest or to pay another loan\u2019s EMI — that is the debt spiral\u2019s first turn.',
          ],
        },
      ],
      example: {
        title: 'One extra EMI a year',
        body: 'Suresh\u2019s ₹40 lakh home loan at 9% for 20 years had an EMI of ~₹35,989. He paid one extra EMI every March (bonus month). Result: loan closed in ~16 years instead of 20, saving roughly ₹10 lakh of interest for a total extra outlay of ₹4.2 lakh. No market risk, no skill — just arithmetic applied consistently.',
      },
      keyTerms: [
        { term: 'Amortisation schedule', definition: 'The month-by-month split of every EMI between interest and principal.' },
        { term: 'Reducing vs flat balance', definition: 'Reducing charges interest on outstanding balance; flat charges on original principal — inflating true cost.' },
        { term: 'Prepayment', definition: 'Paying principal early to cut tenure and interest; penalty-free on floating-rate retail loans.' },
        { term: 'Debt-to-income ratio', definition: 'Total EMIs ÷ take-home income; keep under 40%, ideally under 30%.' },
      ],
      takeaways: [
        'Early EMIs are mostly interest — prepay early for maximum effect.',
        'Tenure hides cost: shorter tenure saves multiples of what you expect.',
        '"10% flat" ≈ 17–18% reducing — always ask which method a rate uses.',
        'Keep total EMIs under 40% of take-home; hold EMI-cover in your emergency fund.',
        'Prepaying a 9% loan is a guaranteed 9% return — choose tenure reduction when prepaying.',
      ],
      externalLinks: [
        { label: 'RBI — Key facts you should know about loans', url: 'https://www.rbi.org.in', source: 'Reserve Bank of India' },
      ],
    },
  },
  {
    slug: 'credit-scores',
    category: 'banking',
    topic: 'Credit scores',
    title: 'Credit Scores: Your Financial Reputation in a Number',
    summary: 'What builds and damages a 300–900 credit score, the five weighted factors, how to check your report free, and repairing a damaged score.',
    level: 'Beginner',
    readMinutes: 6,
    tags: ['CIBIL', 'credit score', 'credit report', 'utilization'],
    related: ['credit-cards', 'loans-and-interest', 'bank-statements', 'identity-theft'],
    content: {
      intro: 'Your credit score (300–900, from bureaus like TransUnion CIBIL, Experian, CRIF) is a compressed summary of how reliably you repay debt. Lenders price your future by it: above ~750 unlocks the best rates; below 650 means rejections or punishing pricing. It is one of the few numbers that quietly taxes or discounts decades of your life.',
      sections: [
        {
          heading: 'The five factors and their weights',
          body: [
            'Payment history (~35%): every on-time EMI and full card payment builds; one 90-day default lingers for years. Credit utilisation (~30%): using under ~30% of limits signals control; maxed cards signal distress even if fully repaid.',
            'Length of history (~15%): older accounts help — close the oldest card and your average age collapses. Credit mix (~10%): a blend of secured and unsecured credit is mildly positive. New credit (~10%): several recent applications read as desperation; each "hard enquiry" dents the score briefly.',
          ],
        },
        {
          heading: 'Checking and disputing',
          body: [
            'You are entitled to one free credit report annually from each bureau — request directly on their official sites (cibil.com etc.), never via third-party "free score" apps that harvest data. Check before any major loan application.',
            'Found errors — a loan you never took, a wrongly marked late payment? File a dispute with the bureau; they coordinate with the lender, and corrections typically reflect within ~30 days. Persist; documentation wins.',
          ],
        },
        {
          heading: 'Repairing a damaged score',
          body: [
            'Repair order: clear overdue amounts first (they bleed daily), then pay every due in full and on time for 6–12 months — history rebuilding is mostly time plus consistency. Bring utilisation under 30%, request limit increases without new cards, and avoid the "debt settlement" agencies that ask upfront fees (many are scams; negotiate directly with lenders instead).',
            'If you have no credit history, a secured card against a fixed deposit builds one safely within a year of disciplined use.',
          ],
        },
      ],
      example: {
        title: 'The ₹2,000 ghost',
        body: 'Deepa\u2019s home loan was priced 1% above market. Her report showed a 60-day default on a card she had cancelled — a ₹2,000 unpaid annual fee had silently aged into a default. She disputed it with proof of closure, the entry was corrected within five weeks, and refinancing a year later saved ₹62,000 over her remaining tenure. A five-minute annual report check would have caught it on day one.',
      },
      keyTerms: [
        { term: 'Credit bureau', definition: 'A licensed agency (CIBIL, Experian, CRIF, Equifax) that compiles repayment histories into scores.' },
        { term: 'Hard enquiry', definition: 'A lender\u2019s score pull during an application; multiple recent ones lower your score.' },
        { term: 'Settlement (flagged)', definition: 'A "paid for less than owed" status — better than default, but it marks the account for years.' },
        { term: 'Secured card', definition: 'A credit card backed by your own FD — the safest way to build or rebuild history.' },
      ],
      takeaways: [
        'Score = payment history first, utilisation second; protect both.',
        'Keep utilisation under ~30% and never close your oldest card.',
        'Pull your free annual report from bureaus directly; dispute errors in writing.',
        'Repair = clear overdues, pay on time, low utilisation, patience — not upfront-fee "fixers".',
        'Check your report before every major loan; a 1% rate gap is worth lakhs.',
      ],
      externalLinks: [
        { label: 'TransUnion CIBIL', url: 'https://www.cibil.com', source: 'TransUnion CIBIL' },
        { label: 'RBI — Ombudsman', url: 'https://www.rbi.org.in', source: 'Reserve Bank of India' },
      ],
    },
  },
  {
    slug: 'digital-banking-security',
    category: 'banking',
    topic: 'Digital banking security',
    title: 'Digital Banking Security: Locking Your Digital Vault',
    summary: 'Device hygiene, app safety, SIM-swap defence, secure payment habits, and what to do in the first hour after a banking compromise.',
    level: 'Beginner',
    readMinutes: 7,
    tags: ['security', 'SIM swap', 'app lock', 'banking safety'],
    related: ['upi-safety', 'password-security', 'phishing-attacks', 'identity-theft'],
    content: {
      intro: 'Your bank branch is now a rectangle of glass in your pocket — and like any vault, its security is only as strong as its weakest door. The good news: a handful of one-time settings and habits eliminates the vast majority of account-takeover risks.',
      sections: [
        {
          heading: 'The phone is the vault door',
          body: [
            'Use a 6+ digit screen lock or biometrics, and enable app locks (PIN/fingerprint) on banking, UPI and email apps. Never use face/unlock patterns visible in public; shoulder-surfing remains effective theft.',
            'Update the OS and apps promptly — patches close the holes malware walks through. Install apps only from official stores, check publisher names, and refuse app requests for accessibility permissions they don\u2019t need (a remote-control red flag).',
          ],
        },
        {
          heading: 'SIM-swap and number takeover',
          body: [
            'SIM-swap fraud: fraudsters port your number via forged requests, then receive your OTPs. Defence one: set a SIM-change PIN with your operator. Defence two: enable email alerts too, and use app-based authentication where available. Defence three: if your phone shows "No service" unexpectedly, treat it as an emergency — call the operator and bank immediately.',
            'Never share the 20-digit SIM details, CVV, or any OTP — no legitimate process needs them shared. Bank staff who "helpfully" guide you through a remote app install or OTP entry are the fraud themselves.',
          ],
        },
        {
          heading: 'Payment hygiene',
          body: [
            'Set low transaction limits (per-transaction and daily) in banking/UPI apps — caps convert disasters into inconveniences. Enable transaction alerts for every debit. Use virtual/one-time cards for unfamiliar online merchants, and avoid banking on public Wi-Fi; mobile data is safer.',
            'Review linked mandates (auto-debits) quarterly in your bank app and revoke what you no longer use — dormant mandates are recurring leak points.',
          ],
        },
        {
          heading: 'The first hour after compromise',
          body: [
            'If money leaves or credentials leak: (1) freeze/block cards and change passwords from a clean device; (2) call the bank\u2019s official fraud line (number from your card/statement, never from the suspicious message); (3) dial 1930 and file at cybercrime.gov.in within the golden hour — early reports freeze money in transit; (4) preserve screenshots and reference numbers.',
            'Speed is the recovery variable. Victims who report within the first hour recover funds at dramatically higher rates than those who wait a day.',
          ],
        },
      ],
      example: {
        title: 'The no-service emergency',
        body: 'Farhan\u2019s phone showed "No Service" on a Tuesday afternoon. Remembering the SIM-swap lesson, he borrowed a phone, called his operator (port request pending — he blocked it) and his bank (card frozen). A fraudster with a forged letterhead had nearly completed a takeover that would have harvested ₹2.4 lakh via OTPs. Total loss: zero. Cost: two phone calls in eleven minutes.',
      },
      keyTerms: [
        { term: 'SIM swap', definition: 'Fraudulent transfer of your number to a criminal\u2019s SIM to intercept OTPs.' },
        { term: 'App lock', definition: 'A second PIN/biometric gate on individual apps, independent of the phone lock.' },
        { term: 'Transaction limit', definition: 'Self-set caps on payments that cap fraud damage per day.' },
        { term: 'Golden hour', definition: 'The first 60 minutes post-fraud, when blocking and 1930 reporting most often recover funds.' },
      ],
      takeaways: [
        'App locks + OS updates + official stores only — the 80/20 of phone security.',
        'Set a SIM PIN; sudden "No Service" is a takeover alarm — act within minutes.',
        'Set low daily transaction limits and enable alerts for every debit.',
        'Bank on mobile data, not public Wi-Fi; audit auto-debit mandates quarterly.',
        'First hour protocol: freeze, official numbers only, 1930, cybercrime.gov.in, preserve evidence.',
      ],
      externalLinks: [
        { label: 'Cyber Crime Reporting Portal', url: 'https://cybercrime.gov.in', source: 'MHA, Government of India' },
        { label: 'Sanchar Saathi — Chakshu & SIM checks', url: 'https://sancharsaathi.gov.in', source: 'DoT, Government of India' },
      ],
    },
  },
]
