// Money Harvest — Investment Education lessons
import type { LessonSeed } from './lessons-personal'

export const investmentLessons: LessonSeed[] = [
  {
    slug: 'stock-market-basics',
    category: 'investment',
    topic: 'Stock market basics',
    title: 'Stock Market Basics: Owning a Piece of Business',
    summary: 'What a share actually is, how markets set prices, what exchanges and indices do, and the mindset a beginner should carry into equities.',
    level: 'Beginner',
    readMinutes: 8,
    tags: ['stocks', 'equity', 'NSE', 'BSE', 'indices'],
    related: ['mutual-funds', 'risk-and-return', 'long-term-investing', 'index-funds'],
    content: {
      intro: 'A share of stock is not a lottery ticket or a chart pattern — it is fractional ownership of a real business, with a claim on its profits and assets. When you buy one share of a listed company, you own a (tiny) slice of its factories, brands and future earnings. Everything else — price charts, news noise, market moods — is commentary around that one fact.',
      sections: [
        {
          heading: 'Where stocks live: exchanges and indices',
          body: [
            'In India, shares trade on the National Stock Exchange (NSE) and BSE, regulated by SEBI. Brokers route your orders to the exchange; demat accounts hold your shares electronically. Opening both is now fully online through SEBI-registered brokers.',
            'Indices summarise the market: Nifty 50 tracks the 50 largest NSE companies, Sensex 30 of the largest BSE companies. When people say "the market fell 2%", they mean the index — your individual stocks may differ.',
          ],
        },
        {
          heading: 'Why prices move',
          body: [
            'Prices move on expectations. A company\u2019s price reflects what millions of participants collectively believe about its future profits, discounted to today — revised second-by-second on news, results, interest rates and sentiment.',
            'Short-term price movement is mostly noise; long-term price movement tends to follow earnings growth. This single asymmetry is why day-trading outcomes are poor for most beginners while long-term business ownership has historically rewarded patience.',
          ],
        },
        {
          heading: 'How beginners should (and shouldn\u2019t) start',
          body: [
            'Should: build an emergency fund first; then consider starting through diversified mutual funds or index funds via SIP, learning market behaviour with small stakes. Study any company\u2019s business model before buying its shares.',
            'Shouldn\u2019t: borrow to invest, follow Telegram "tips", trade on margin, or put money needed within 3 years into equity. If an unknown person promises you sure-shot stock calls, revisit the Scam Detector — that pattern is a documented fraud.',
          ],
        },
        {
          heading: 'The three honest rules',
          body: [
            'Rule 1: A share is a business — ask "would I buy this whole company?" not "what did the chart do?". Rule 2: Time in the market has historically beaten timing the market; missed best days wreck returns. Rule 3: Diversify — any single company can fail regardless of how good its story sounds.',
            'Verify everything on official sources: company filings on the exchanges, SEBI\u2019s investor education portal, and registered intermediaries lists. SEBI\u2019s investor.sebi.gov.in is the definitive place to check who is regulated and who is not.',
          ],
        },
      ],
      example: {
        title: 'Reading a price move correctly',
        body: 'A listed IT company reports results and drops 8% in a day. Nothing about its decade-long business changed that day — what changed was expectations. An investor who understood the business held; a trader who bought on a WhatsApp tip two weeks earlier panicked and sold at a loss. Same stock, same day, opposite outcomes — the difference was ownership understanding versus speculation.',
      },
      keyTerms: [
        { term: 'Demat account', definition: 'An electronic vault that holds your shares; required to trade in India.' },
        { term: 'Index', definition: 'A basket of representative stocks (Nifty 50, Sensex) used to measure overall market movement.' },
        { term: 'Market capitalisation', definition: 'Share price × total number of shares — the market\u2019s valuation of the whole company.' },
        { term: 'Bull / bear market', definition: 'Extended periods of generally rising prices (bull) or falling prices (bear).' },
      ],
      takeaways: [
        'A share is ownership of a business, not a ticker that flickers.',
        'NSE/BSE are the exchanges; SEBI regulates; demat accounts hold shares.',
        'Short-term prices are noise; long-term prices follow earnings.',
        'Beginners should generally start with diversified/index funds before individual stocks.',
        'Never borrow to invest, follow tip groups, or invest short-term money in equity.',
      ],
      externalLinks: [
        { label: 'SEBI Investor Education', url: 'https://investor.sebi.gov.in', source: 'SEBI' },
        { label: 'NSE India', url: 'https://www.nseindia.com', source: 'National Stock Exchange' },
      ],
    },
  },
  {
    slug: 'mutual-funds',
    category: 'investment',
    topic: 'Mutual funds',
    title: 'Mutual Funds: Professional Diversification in One Unit',
    summary: 'How pooled investing works, fund types (equity, debt, hybrid), the true cost of expense ratios, and how to pick funds soberly.',
    level: 'Beginner',
    readMinutes: 8,
    tags: ['mutual funds', 'NAV', 'expense ratio', 'AMFI'],
    related: ['sip', 'index-funds', 'diversification', 'risk-and-return'],
    content: {
      intro: 'A mutual fund pools money from thousands of investors and a professional manager invests it across many securities. One ₹500 purchase can give you a slice of 50–100 companies or bonds — diversification that would be impossible to build alone. Funds are regulated by SEBI, and the industry body AMFI publishes fund data openly.',
      sections: [
        {
          heading: 'How a fund works',
          body: [
            'When you invest, you buy units priced by NAV — net asset value, the fund\u2019s total holdings minus liabilities, divided by units outstanding. Your units rise with the underlying portfolio and fall with it; the manager\u2019s job is selection and rebalancing within the fund\u2019s stated mandate.',
            'The mandate matters more than the name: an "equity" fund must hold equities, a "liquid" fund holds short-term debt. Match the mandate to your goal and horizon instead of chasing last year\u2019s best performer.',
          ],
        },
        {
          heading: 'The main fund families',
          body: [
            'Equity funds (large-cap, mid-cap, small-cap, flexi-cap, ELSS tax-savers) carry market risk with historically higher long-term returns. Debt funds (liquid, short-duration, gilt) lend money for interest, carrying credit and interest-rate risk with lower expected returns.',
            'Hybrid funds mix both. Index funds simply replicate an index at minimal cost. For most beginners, the shortlist is: index funds for core equity, liquid funds for parking, and — only after learning — actively managed or sector funds.',
          ],
        },
        {
          heading: 'Costs quietly decide outcomes',
          body: [
            'Every fund charges an annual expense ratio (TER). The difference between 2.1% (typical active) and 0.2% (index) sounds tiny, but over 20 years on ₹10 lakh at 12% gross, it can cost lakhs of rupees in foregone corpus — the fee compounds against you annually.',
            'Direct plans (you invest without a distributor) carry lower expense ratios than regular plans. The platform\u2019s calculators let you see long-term fee effects directly.',
          ],
        },
        {
          heading: 'Choosing soberly',
          body: [
            'Check: (1) does the mandate match my goal/horizon; (2) expense ratio vs category; (3) 5+ year track record of the fund and manager, not 6-month fireworks; (4) fund house size and consistency. Avoid funds-of-recently-hot-themes bought at peak hype.',
            'Read the scheme information document (SID) before investing. And treat any "guaranteed returns" mutual fund claim as fraud — no genuine fund guarantees returns; only scam promoters do.',
          ],
        },
      ],
      example: {
        title: '₹10 lakh, 20 years, and a 1.9% fee gap',
        body: 'Fund A (index) charges 0.2% annually; Fund B (active, same gross performance of 12%) charges 2.1%. After 20 years, ₹10 lakh grows to ~₹92.2 lakh in A versus ~₹64.9 lakh in B. The active fund\u2019s manager must outperform gross by ~1.9% every single year just to break even with the index — which is exactly why most actively managed large-cap funds have historically trailed their index over long periods.',
      },
      keyTerms: [
        { term: 'NAV', definition: 'Net asset value — the per-unit price of a fund, updated each business day.' },
        { term: 'Expense ratio (TER)', definition: 'Annual percentage fee the fund deducts from assets; compounds against returns.' },
        { term: 'AUM', definition: 'Assets under management — total money the fund manages; very small AUM adds closure risk.' },
        { term: 'Direct vs regular plan', definition: 'Direct plans skip distributor commissions and therefore have lower expense ratios.' },
      ],
      takeaways: [
        'One fund unit = instant diversification across dozens of holdings.',
        'Match the fund\u2019s mandate to your goal; ignore last year\u2019s winners.',
        'Expense ratios compound against you — prefer low-cost direct/index plans for the core.',
        'Judge funds on 5+ year consistency and mandate fit, not recent streaks.',
        'No mutual fund can guarantee returns — anyone who does is scamming you.',
      ],
      externalLinks: [
        { label: 'AMFI — Association of Mutual Funds in India', url: 'https://www.amfiindia.com', source: 'AMFI' },
        { label: 'SEBI Investor Education', url: 'https://investor.sebi.gov.in', source: 'SEBI' },
      ],
    },
  },
  {
    slug: 'sip',
    category: 'investment',
    topic: 'SIP',
    title: 'SIP: Small, Boring, Ruthlessly Effective',
    summary: 'How systematic investment plans automate investing, why rupee-cost averaging smooths volatility, and what SIPs will not do for you.',
    level: 'Beginner',
    readMinutes: 7,
    tags: ['SIP', 'rupee cost averaging', 'automation'],
    related: ['mutual-funds', 'compound-interest', 'long-term-investing', 'financial-goal-planning'],
    content: {
      intro: 'A Systematic Investment Plan (SIP) is an instruction to invest a fixed amount into a fund on a fixed date — typically monthly. It converts investing from a decision you must repeatedly get right into a habit that runs itself. Its power is not magic; it is automation plus rupee-cost averaging plus compounding, applied for years.',
      sections: [
        {
          heading: 'Rupee-cost averaging, in plain language',
          body: [
            'A fixed ₹5,000 buys more units when markets are cheap and fewer when expensive. You automatically buy more at lows — averaging your purchase cost across the cycle — without predicting anything. This removes the worst beginner behaviour: waiting for "the right time" and never starting.',
            'Averaging does not guarantee profit or protect from losses; it simply disciplines entry prices and neutralises timing anxiety. Over long horizons in growth assets, that discipline has historically rewarded consistency.',
          ],
        },
        {
          heading: 'What SIPs actually do — and don\u2019t',
          body: [
            'Do: automate good behaviour, smooth entry prices, harness compounding, scale with your income (step-up SIPs raise the amount annually). Don\u2019t: guarantee returns, prevent losses in falling markets, or work over short horizons — a 1-year SIP in equity can absolutely end negative.',
            'A SIP in the wrong fund is an automated mistake. First choose the right fund for the goal; then let the SIP do the boring repetition.',
          ],
        },
        {
          heading: 'Designing your SIP stack',
          body: [
            'Start with one core: a broad index fund or flexi-cap for long-term wealth. Add a step-up of 5–10% annually so contributions grow with salary. Increase allocation to debt/liquid as goals approach — the last 2 years of a goal should not ride equity.',
            'Continue through downturns. SIPs bought through 2020\u2019s crash in quality funds did disproportionately well, because the scariest months purchased the cheapest units.',
          ],
        },
        {
          heading: 'The numbers',
          body: [
            '₹5,000/month for 20 years at 11% annualised ≈ ₹41 lakh invested vs ~₹1.9 crore final value... more precisely: ₹12 lakh contributed growing to roughly ₹37–42 lakh corpus depending on timing of returns. Use the platform\u2019s SIP Calculator to model your own amounts, horizons, and step-ups — and note its honest caveat: returns are hypothetical, markets vary.',
          ],
        },
      ],
      example: {
        title: 'March 2020 — the SIP\u2019s finest hour',
        body: 'When markets crashed ~35% in March 2020, lump-sum investors who panicked sold at the bottom. SIP investors, by contrast, kept buying every month through the crash and recovery — their average purchase cost was far below the levels euphoric buyers had paid in January. Nobody needed courage; the standing instruction supplied it.',
      },
      keyTerms: [
        { term: 'SIP', definition: 'Systematic Investment Plan — an automated fixed-amount, fixed-date investment into a fund.' },
        { term: 'Rupee-cost averaging', definition: 'Buying fixed rupee amounts regardless of price, so more units are bought at lower prices.' },
        { term: 'Step-up SIP', definition: 'A SIP whose contribution automatically increases annually, typically with salary growth.' },
        { term: 'Lump sum', definition: 'Investing an entire amount at once — better mathematically in rising markets, harder psychologically.' },
      ],
      takeaways: [
        'A SIP automates investing and removes timing decisions from your hands.',
        'Rupee-cost averaging buys more units at lows — discipline, not a guarantee.',
        'SIPs only work paired with the right fund and a horizon of 5+ years for equity.',
        'Step up contributions annually; continue through crashes.',
        'Model everything with the SIP Calculator, but remember: actual returns vary.',
      ],
      externalLinks: [
        { label: 'AMFI — SIP awareness', url: 'https://www.amfiindia.com', source: 'AMFI' },
      ],
    },
  },
  {
    slug: 'index-funds',
    category: 'investment',
    topic: 'Index funds',
    title: 'Index Funds: Winning by Not Trying to Beat the Market',
    summary: 'What index funds are, why their low cost compounds in your favour, tracking error, and when active funds still make sense.',
    level: 'Beginner',
    readMinutes: 6,
    tags: ['index fund', 'Nifty 50', 'passive investing', 'cost'],
    related: ['mutual-funds', 'sip', 'stock-market-basics', 'diversification'],
    content: {
      intro: 'An index fund does one humble thing: it holds every stock in an index (like Nifty 50) in the same proportion, at the lowest feasible cost. It will never beat the index — by definition, minus a sliver of fees. That apparent weakness is its strength: most actively managed large-cap funds have historically failed to beat the index after fees, over long periods.',
      sections: [
        {
          heading: 'Why "average" is extraordinary',
          body: [
            'The market\u2019s return is the average of all participants\u2019 returns, before costs. Once fees, churn and taxes apply, the average investor underperforms the average fund, and the average fund underperforms the index. Simply holding the index at near-zero cost places you above most participants — for doing nothing.',
            'Index funds also eliminate manager risk: no star manager leaving, no style drift, no theme-chasing. You always own exactly what the index owns.',
          ],
        },
        {
          heading: 'Costs and tracking error',
          body: [
            'Indian Nifty 50 index funds charge expense ratios around 0.1–0.3% versus 1.5–2.2% for many active funds. Compounded over decades, that gap often exceeds the entire value of your initial investment.',
            'Tracking error measures how faithfully a fund follows its index — look for low tracking difference and large, established fund houses. Two index funds on the same index are near-identical products; choose mainly on cost and tracking.',
          ],
        },
        {
          heading: 'When active funds still make sense',
          body: [
            'In less efficiently covered segments — small caps, some mid-caps, certain debt categories — skilled managers have historically had more room to add value. A sober portfolio often combines a low-cost index core with selective active satellites.',
            'The default recommendation for beginners remains: core equity = broad index fund via SIP; satellites only after you understand what you are paying for and why.',
          ],
        },
      ],
      example: {
        title: 'The ten-year scoreboard',
        body: 'Over the decade to the early 2020s, a majority of actively managed Indian large-cap funds trailed the Nifty 100 — a pattern SEBI\u2019s own mandated benchmarking made visible to every investor. The index fund investor, ignoring news all decade, quietly finished ahead of most professionals who had been paid to beat her.',
      },
      keyTerms: [
        { term: 'Passive investing', definition: 'Owning the index rather than selecting stocks, aiming to capture market returns at minimal cost.' },
        { term: 'Tracking error', definition: 'How closely a fund replicates its index\u2019s return; lower is better.' },
        { term: 'AUM-weighted fee', definition: 'Index fund costs fall as assets grow, benefiting all unitholders.' },
        { term: 'Market-cap weighting', definition: 'Index allocation by company size — the biggest companies hold the biggest weights automatically.' },
      ],
      takeaways: [
        'Index funds capture market returns at the lowest cost — historically beating most active large-cap funds.',
        'Low expense ratio and low tracking error are the only selection criteria you need.',
        'No manager risk, no style drift — you always own the index.',
        'Active funds can complement in small/mid-cap segments, as satellites, not the core.',
        'For beginners: broad index fund via SIP is the simplest defensible equity core.',
      ],
      externalLinks: [
        { label: 'NSE Indices', url: 'https://www.nseindia.com', source: 'NSE' },
        { label: 'AMFI', url: 'https://www.amfiindia.com', source: 'AMFI' },
      ],
    },
  },
  {
    slug: 'bonds',
    category: 'investment',
    topic: 'Bonds',
    title: 'Bonds: Lending Money for Predictable Interest',
    summary: 'What bonds and debentures are, how prices react to interest rates, credit ratings, and where retail investors can access them safely.',
    level: 'Intermediate',
    readMinutes: 7,
    tags: ['bonds', 'gilt', 'credit rating', 'fixed income'],
    related: ['fixed-deposits', 'risk-and-return', 'diversification', 'mutual-funds'],
    content: {
      intro: 'A bond is a loan you make — to a government or a company — that pays stated interest (the coupon) and returns principal at maturity. Stocks make you an owner; bonds make you a lender. Lenders get paid before owners if trouble hits, which is why bonds are the stabilising half of diversified portfolios.',
      sections: [
        {
          heading: 'The vocabulary',
          body: [
            'Face value (usually ₹1,000), coupon (annual interest, e.g. 7.5%), maturity (when principal returns), and yield (effective return given the price you paid). Buy at par and hold to maturity, and yield equals coupon.',
            'Government securities (G-Secs) carry sovereign credit risk — effectively the safest rupee instruments. Corporate bonds add credit risk: the company might struggle; ratings (AAA to D by CRISIL, ICRA, CARE) grade that risk.',
          ],
        },
        {
          heading: 'The see-saw rule: rates vs prices',
          body: [
            'When market interest rates rise, existing bonds paying older, lower coupons fall in price; when rates fall, they rise. Hold to maturity and the price swings don\u2019t matter — you receive face value. Sell early and the see-saw decides your gain or loss.',
            'Longer-maturity bonds swing harder on the same rate change (higher duration). This is why rising-rate years hurt long-duration debt funds, and why "safe" bonds can still produce negative years.',
          ],
        },
        {
          heading: 'How retail investors access bonds',
          body: [
            'Options: government securities via RBI Retail Direct (free, official), gilt and corporate-bond mutual funds, listed NCDs via brokers, and sovereign gold bonds for gold exposure. RBI Retail Direct is the cleanest starting point for G-Secs and T-Bills.',
            'Avoid unregulated "fixed income" schemes promising 15–20% "assured" returns — they recur as Ponzi structures. If a yield looks wildly above comparable-rated instruments, the rating agencies\u2019 view or the scam detector explains why.',
          ],
        },
        {
          heading: 'Where bonds fit',
          body: [
            'Bonds anchor goals within 1–5 years, reduce portfolio volatility, and provide the "dry powder" that lets you rebalance into crashed equity. A common frame: bond allocation ≈ your age or your near-term goal weight, tuned by risk appetite.',
          ],
        },
      ],
      example: {
        title: 'Rising rates, falling NAV',
        body: 'In a year when the RBI raised policy rates sharply, long-duration gilt funds fell 5–8% — alarming investors who thought "government = no losses". The instruments never defaulted; prices simply adjusted to newer, higher coupons. Investors who held to maturity received every rupee promised; those who fled at the bottom turned paper loss into real loss.',
      },
      keyTerms: [
        { term: 'Coupon', definition: 'The fixed interest a bond pays, as a percentage of face value.' },
        { term: 'Yield to maturity', definition: 'Total expected return if held to maturity at the current price.' },
        { term: 'Duration', definition: 'Sensitivity of a bond\u2019s price to interest-rate changes; longer duration = bigger swings.' },
        { term: 'Credit rating', definition: 'An agency\u2019s grade (AAA…D) of the issuer\u2019s ability to repay; lower grade = higher offered yield = higher risk.' },
      ],
      takeaways: [
        'Bonds = lending; you receive stated interest and principal back at maturity.',
        'Bond prices fall when rates rise — the see-saw rule; hold to maturity to ignore it.',
        'G-Secs are the safest; corporate bond risk is graded by ratings — read them.',
        'RBI Retail Direct is the official, free route to government bonds for individuals.',
        'Any "assured" return far above comparable rated bonds is a scam signal.',
      ],
      externalLinks: [
        { label: 'RBI Retail Direct', url: 'https://www.rbi.org.in', source: 'Reserve Bank of India' },
        { label: 'SEBI Investor Education', url: 'https://investor.sebi.gov.in', source: 'SEBI' },
      ],
    },
  },
  {
    slug: 'fixed-deposits',
    category: 'investment',
    topic: 'Fixed deposits',
    title: 'Fixed Deposits: The Reliable Workhorse',
    summary: 'How FD interest and compounding work, cumulive vs payout options, tax treatment, laddering strategy, and where FDs belong in a modern plan.',
    level: 'Beginner',
    readMinutes: 6,
    tags: ['FD', 'fixed deposit', 'compounding', 'laddering'],
    related: ['recurring-deposits', 'compound-interest', 'emergency-fund', 'bonds'],
    content: {
      intro: 'A fixed deposit locks a lump sum with a bank or NBFC for a chosen tenure at a stated interest rate. It is the backbone of Indian household saving: predictable, insured up to ₹5 lakh per bank per depositor by DICGC, and utterly unaffected by market moods. Its weakness is equally clear — post-tax returns often barely beat inflation.',
      sections: [
        {
          heading: 'How interest is computed',
          body: [
            'FDs compound at the stated frequency (quarterly is common in Indian banks). A 7% annual rate compounded quarterly effectively yields ~7.19% annually. Cumulative FDs add interest to the principal; non-cumulative FDs pay interest out monthly/quarterly for income.',
            'Premature withdrawal is allowed with a small rate penalty (typically 0.5–1%). Many banks offer sweep-in FDs that break automatically when your account needs cash — ideal for emergency funds.',
          ],
        },
        {
          heading: 'Tax and inflation reality',
          body: [
            'FD interest is taxed at your slab rate — for someone in the 30% bracket, a 7% FD nets ~4.9%, which during 5–6% inflation is a thin or negative real return. TDS applies above thresholds unless you submit forms (15G/15H if eligible).',
            'Conclusion: FDs are for capital preservation and short horizons, not long-term wealth. Long-term money in pure FD quietly loses the inflation race.',
          ],
        },
        {
          heading: 'Laddering — the pro move',
          body: [
            'Instead of one ₹3 lakh FD for 3 years, split into three ₹1 lakh FDs of 1, 2 and 3 years. As each matures, renew at the longest tenure. You get liquidity every year, average rates across the curve, and rate-rise protection.',
            'Laddering also matches money to goals: each rung can align with a known future expense (insurance renewal, fees, travel).',
          ],
        },
        {
          heading: 'Where FDs belong today',
          body: [
            'Emergency funds (sweep-in), goals within 0–3 years, income needs (non-cumulative), and the conservative portion of retiree portfolios. Compare rates across banks and small finance banks (same DICGC ₹5-lakh insurance applies), and always verify the institution is a regulated bank/NBFC — not an unregulated "deposit scheme" promising 15%.',
          ],
        },
      ],
      example: {
        title: 'The ladder in action',
        body: 'Kiran splits ₹6 lakh into 1/2/3-year FDs of ₹2 lakh each. When her father\u2019s medical event needed ₹1.8 lakh in year two, the maturing 2-year rung covered it without penalty. A single 3-year FD would have cost her a 1% break penalty and rushed decisions; the ladder turned a crisis into a calendar item.',
      },
      keyTerms: [
        { term: 'DICGC insurance', definition: 'Deposit Insurance and Credit Guarantee Corporation covers up to ₹5 lakh per depositor per bank, including principal and interest.' },
        { term: 'Cumulative FD', definition: 'Interest compounds into the principal and is paid at maturity.' },
        { term: 'Sweep-in FD', definition: 'An FD linked to your savings account that auto-breaks to fund withdrawals when needed.' },
        { term: 'FD laddering', definition: 'Splitting a sum into multiple staggered-maturity FDs for liquidity and rate averaging.' },
      ],
      takeaways: [
        'FDs offer predictability and DICGC-insured safety up to ₹5 lakh per bank.',
        'Post-tax FD returns often barely beat inflation — not for long-term wealth.',
        'Quarterly compounding at 7% ≈ 7.19% effective; cumulative vs payout changes your cashflow.',
        'Ladder FDs for annual liquidity and rate averaging.',
        'Only deposit with regulated banks/NBFCs; unregulated "deposit schemes" promising outsized rates are scams.',
      ],
      externalLinks: [
        { label: 'DICGC — Deposit insurance', url: 'https://www.dicgc.org.in', source: 'DICGC' },
        { label: 'RBI Financial Awareness', url: 'https://www.rbi.org.in', source: 'Reserve Bank of India' },
      ],
    },
  },
  {
    slug: 'recurring-deposits',
    category: 'investment',
    topic: 'Recurring deposits',
    title: 'Recurring Deposits: Discipline on Autopilot',
    summary: 'How RDs build saving habits with fixed monthly deposits, how their interest math differs from SIPs, and when an RD beats a mutual fund SIP.',
    level: 'Beginner',
    readMinutes: 5,
    tags: ['RD', 'recurring deposit', 'discipline', 'short term'],
    related: ['fixed-deposits', 'sip', 'saving-money', 'emergency-fund'],
    content: {
      intro: 'A recurring deposit is the FD\u2019s disciplined sibling: you deposit a fixed amount monthly for a fixed tenure at a fixed rate, and receive principal plus interest at maturity. Because the rate is locked at the start, RDs are the only instrument where next year\u2019s outcome is printed on today\u2019s receipt — certainty SIPs cannot offer.',
      sections: [
        {
          heading: 'How RD interest works',
          body: [
            'Each monthly instalment earns interest only from its own deposit date. The first deposit compounds the longest, the last barely at all — so the effective yield on your total contributions is lower than the headline rate suggests. Banks compute each instalment\u2019s future value and sum them.',
            'Example: ₹5,000/month for 24 months at 7% (quarterly compounding) matures around ₹1,28,800 on ₹1,20,000 deposited — roughly ₹8,800 interest, not ₹16,800, because the average money was invested for only ~12 months.',
          ],
        },
        {
          heading: 'RD vs SIP — an honest comparison',
          body: [
            'An RD guarantees its rate; a mutual-fund SIP offers uncertain but historically higher long-term returns with volatility. For goals under 3 years, RD wins on appropriateness: no time to recover from an equity drawdown. For 5+ year goals, SIPs in equity have historically compounded far ahead.',
            'RDs also build the saving muscle: the auto-debit trains the habit that later funds bigger SIPs. Many investors start with a ₹2,000 RD, then graduate.',
          ],
        },
        {
          heading: 'Practical uses',
          body: [
            'RDs shine for sinking funds — insurance premiums, festival budgets, exam fees, a wedding gift calendar — where the amount and date are known. Ladder multiple RDs to match each known expense.',
            'Premature closure is allowed with a small penalty; missing instalments may trigger penalties or closure depending on the bank. Post-office RDs offer a government-backed alternative with slightly different rules.',
          ],
        },
      ],
      example: {
        title: 'The insurance premium machine',
        body: 'Dev\u2019s family pays a ₹36,000 annual health premium every March. He opened a 12-month ₹3,000 RD each April — the March maturity exactly covers the premium, earning ~₹1,300 interest per cycle versus idle savings. The premium stopped being an emergency and became a scheduled transfer.',
      },
      keyTerms: [
        { term: 'Instalment', definition: 'The fixed monthly deposit in an RD.' },
        { term: 'Tenure', definition: 'The RD\u2019s duration, typically 6 months to 10 years.' },
        { term: 'Sinking fund', definition: 'Savings accumulated monthly for a known future expense — an RD is the classic vehicle.' },
        { term: 'Auto-debit', definition: 'Automatic monthly debit from your account into the RD.' },
      ],
      takeaways: [
        'RDs lock a fixed rate — certainty for short-horizon goals, unlike market SIPs.',
        'Each instalment earns from its own date, so effective yield is below the headline rate.',
        'Ideal for sinking funds and goals within 0–3 years.',
        'Use RDs to train the saving habit, then graduate long-term money to SIPs.',
        'Post-office RDs provide a government-backed variant.',
      ],
      externalLinks: [
        { label: 'India Post — Savings schemes', url: 'https://www.indiapost.gov.in', source: 'India Post' },
        { label: 'RBI Financial Awareness', url: 'https://www.rbi.org.in', source: 'Reserve Bank of India' },
      ],
    },
  },
  {
    slug: 'risk-and-return',
    category: 'investment',
    topic: 'Risk and return',
    title: 'Risk and Return: The Trade You Are Actually Making',
    summary: 'Why risk and return are inseparable, how to measure your real risk tolerance, volatility vs loss, and building a portfolio you can actually hold.',
    level: 'Intermediate',
    readMinutes: 7,
    tags: ['risk', 'volatility', 'risk profile', 'drawdown'],
    related: ['diversification', 'long-term-investing', 'mutual-funds', 'asset-allocation'],
    content: {
      intro: 'Every return you hope for is payment for risk you accept. There is no fifth way: safe assets pay little, growth assets swing painfully. The craft of investing is not finding "high return, no risk" — that phrase is the scam definition — but matching the risks you can personally tolerate to the returns you mathematically need.',
      sections: [
        {
          heading: 'Types of risk worth naming',
          body: [
            'Market risk (prices fall), inflation risk (purchasing power erodes — the "safe" FD\u2019s hidden risk), liquidity risk (can\u2019t exit when needed), credit risk (issuer defaults), and concentration risk (too much in one bet). Notice: avoiding one risk means embracing another. Cash avoids market risk and embraces inflation risk fully.',
            'The scam filter: anyone offering to waive a risk while keeping its return is defrauding you. "Fixed 3% monthly, fully secure" fails basic financial physics.',
          ],
        },
        {
          heading: 'Volatility is not loss — but behaviour converts it',
          body: [
            'Equity\u2019s -35% years feel like loss but are only loss if realised by selling. Historically, Indian broad equity indices have recovered drawdowns given multi-year horizons; panic-selling at bottoms is what converts volatility into permanent loss.',
            'The honest test of risk tolerance is behavioural: what did you actually do in 2020\u2019s crash — buy, hold, or sell? Plan allocations for your demonstrated stomach, not your imagined one.',
          ],
        },
        {
          heading: 'Sizing risk to the goal',
          body: [
            'Risk budgeting by horizon: money needed within 0–3 years takes near-zero market risk; 3–7 years moderate; 7+ years can accept equity volatility for growth. Within each bucket, diversify — the one free lunch in finance.',
            'Write a simple investment policy for yourself: target allocation, monthly contribution, and a pre-committed rule for crashes ("I will continue SIPs and rebalance once a year"). Written rules survive panics; intentions do not.',
          ],
        },
      ],
      example: {
        title: 'Two portfolios, one crash',
        body: 'Same couple, same ₹10 lakh. Portfolio A: 80% mid-cap "hot" funds. Portfolio B: 60% index, 30% debt, 10% gold. In the 2020 crash A fell ~45% and was sold at the bottom in terror; B fell ~22%, was held per its written policy, and recovered within a year. B\u2019s lower return on paper was irrelevant — it was the only portfolio its owners could actually keep.',
      },
      keyTerms: [
        { term: 'Risk-return tradeoff', definition: 'Higher expected returns require accepting higher uncertainty of outcomes.' },
        { term: 'Drawdown', definition: 'Peak-to-trough decline; the psychological unit of investment pain.' },
        { term: 'Risk capacity vs tolerance', definition: 'How much risk you objectively can take (money/horizon) vs subjectively will take (behaviour).' },
        { term: 'Investment policy statement', definition: 'A written personal rulebook of allocation and crisis behaviour.' },
      ],
      takeaways: [
        'There is no high-return-no-risk asset; anyone selling one is a fraud.',
        'Avoiding one risk always means embracing another — cash embraces inflation risk.',
        'Volatility only becomes loss when you sell at the bottom; plan to prevent that.',
        'Size risk by goal horizon: 0–3y safe, 3–7y blended, 7y+ growth.',
        'Write your crisis rules in advance — your future panicked self will obey paper, not resolve.',
      ],
      externalLinks: [
        { label: 'SEBI Investor Education', url: 'https://investor.sebi.gov.in', source: 'SEBI' },
      ],
    },
  },
  {
    slug: 'diversification',
    category: 'investment',
    topic: 'Diversification',
    title: 'Diversification: The Only Free Lunch in Finance',
    summary: 'Why spreading money across assets, sectors and geographies reduces risk without reducing expected return — and how to do it with three funds.',
    level: 'Beginner',
    readMinutes: 6,
    tags: ['diversification', 'allocation', 'correlation', 'rebalancing'],
    related: ['risk-and-return', 'mutual-funds', 'index-funds', 'long-term-investing'],
    content: {
      intro: 'Diversification means never betting the plan on a single outcome. Because different assets stumble at different times, a spread portfolio falls less than its worst component while earning near the average of its parts. It is the only mechanism in finance that reduces risk without demanding you sacrifice expected return — which is why professionals call it the only free lunch.',
      sections: [
        {
          heading: 'The mathematics of not-all-at-once',
          body: [
            'Ten stocks in one sector can still die together; ten across unrelated sectors rarely do. Formalising it: holdings with low correlation smooth the ride — when IT falls, FMCG may not; when equity falls 30%, gold and quality bonds often don\u2019t.',
            'Diversification within one asset class (20 stocks) reduces company-specific risk but not market risk. Only spreading across asset classes — equity, debt, gold, cash — addresses the market-level storms.',
          ],
        },
        {
          heading: 'The three-fund starter portfolio',
          body: [
            'A complete, defensible long-term portfolio for a beginner: (1) a broad Indian equity index fund for growth, (2) a debt/gilt or corporate-bond fund for stability, (3) optionally a gold fund for crisis diversification. Adjust the ratio to your horizon and temperament; rebalance annually.',
            'That is genuinely all. Complexity beyond this usually adds fees and behaviour risk faster than it adds return.',
          ],
        },
        {
          heading: 'Rebalancing — selling high, buying low, automatically',
          body: [
            'Rebalancing restores target weights yearly: whatever ran up gets trimmed, whatever lagged gets bought. It is a mechanical discipline that forces "sell high, buy low" without opinions.',
            'Rebalance on a calendar (annually) or threshold (when an allocation drifts 5%+), not on news. Its quiet superpower is behavioural: during crashes, the rule tells you to buy — exactly when instincts scream sell.',
          ],
        },
      ],
      example: {
        title: 'What a diversified decade looked like',
        body: 'Across a turbulent decade, a 60/30/10 (equity index/debt/gold) portfolio never lost more than ~15% in any year and compounded in the low-double digits — while its equity sleeve twice fell 30%+. The investor who held it needed no courage in crashes; the other sleeves did the absorbing, and rebalancing harvested the spread.',
      },
      keyTerms: [
        { term: 'Correlation', definition: 'How similarly two assets move; low/negative correlation is what makes diversification work.' },
        { term: 'Asset allocation', definition: 'The split of a portfolio across equity, debt, gold, cash — the largest single driver of outcomes.' },
        { term: 'Rebalancing', definition: 'Periodically restoring target weights by trimming winners and adding to laggards.' },
        { term: 'Concentration risk', definition: 'The danger of outcomes hinging on one holding, sector, or geography.' },
      ],
      takeaways: [
        'Diversification reduces risk without reducing expected return — the only free lunch.',
        'Spread across asset classes, not just many stocks in one sector.',
        'A three-fund portfolio (index equity + debt + optional gold) is a complete beginner core.',
        'Rebalance annually or on 5% drift — mechanical, not emotional.',
        'Diversification cannot prevent losses; it prevents ruin and panic decisions.',
      ],
      externalLinks: [
        { label: 'SEBI Investor Education', url: 'https://investor.sebi.gov.in', source: 'SEBI' },
      ],
    },
  },
  {
    slug: 'long-term-investing',
    category: 'investment',
    topic: 'Long-term investing',
    title: 'Long-Term Investing: Boring Is a Superpower',
    summary: 'Why years (not days) decide investment outcomes, the cost of missing best days, behavioural traps, and the gentle art of doing almost nothing.',
    level: 'Beginner',
    readMinutes: 6,
    tags: ['long term', 'patience', 'behaviour', 'wealth'],
    related: ['compound-interest', 'sip', 'risk-and-return', 'diversification'],
    content: {
      intro: 'Almost everything difficult about investing is psychological, not analytical. Markets reward participants who hold diversified assets through decades of noise and punish those who react to every headline. Long-term investing is not a strategy among many — for most people it is the only one statistically likely to work.',
      sections: [
        {
          heading: 'Time converts volatility into growth',
          body: [
            'Over one year, Indian equity can fall 35% or rise 50% — close to a coin flip. Over 10+ year stretches, broad equity indices have historically delivered strongly positive annualised returns, because businesses compound earnings and economies grow. Time is the variable that converts randomness into trend.',
            'The cost of ducking the noise is brutal: studies repeatedly show that missing the handful of best market days per decade — which cluster suspiciously near the worst days — can halve long-term returns. You cannot be present for the best days while absent for the worst.',
          ],
        },
        {
          heading: 'The behavioural traps',
          body: [
            'Recency bias (extrapolating last year), loss aversion (losses hurt ~2× gains, triggering panic sales), herd behaviour (buying peaks, selling troughs), and overconfidence (trading more, earning less). Every trap pushes you to act; the evidence rewards restraint.',
            'The defence is structural, not willpower: automate SIPs, hold a written policy, diversify so no single event can wreck you, and check the portfolio rarely — quarterly at most.',
          ],
        },
        {
          heading: 'The checklist of the boring',
          body: [
            'Emergency fund first. Insurance in place. SIPs automated into low-cost, diversified funds. Annual review: rebalance, step up contributions, update goals. Then close the app and live your life. Your job is not outsmarting the market; it is staying in the market.',
            'As goals approach, de-risk gradually — shift the equity share into debt over the final 2–3 years so a crash cannot ambush a near-dated goal.',
          ],
        },
      ],
      example: {
        title: 'The investor who forgot',
        body: 'A legendary industry study followed an investor who bought a broad fund and ignored it for decades — never rebalancing, never reading news. He matched the market\u2019s full return with near-zero fees and zero stress, outperforming the vast majority of active traders. His advantage was not knowledge. It was the absence of interference.',
      },
      keyTerms: [
        { term: 'Compounding horizon', definition: 'The number of years money stays invested — the strongest controllable return factor.' },
        { term: 'Behaviour gap', definition: 'The difference between fund returns and investor returns, caused by timing mistakes.' },
        { term: 'Glide path', definition: 'Gradually shifting allocations safer as a goal approaches.' },
        { term: 'Buy-and-hold', definition: 'Owning diversified assets across full market cycles without market-timing exits.' },
      ],
      takeaways: [
        'Horizon, not timing, converts equity volatility into dependable long-term growth.',
        'Missing the best few days of a decade devastates returns — stay invested.',
        'Automate SIPs and write crisis rules in advance; behaviour decides most outcomes.',
        'Check quarterly, rebalance annually, contribute more when income grows.',
        'De-risk gradually as goals near so the final years can\u2019t be ambushed.',
      ],
      externalLinks: [
        { label: 'SEBI Investor Education', url: 'https://investor.sebi.gov.in', source: 'SEBI' },
      ],
    },
  },
]
