// Money Harvest — Financial calculator engines (shared client/server-safe math)

export interface SipResult {
  invested: number
  estimatedReturns: number
  finalValue: number
  yearly: { year: number; invested: number; value: number; returns: number }[]
}

export function calcSip(monthly: number, annualRatePct: number, years: number): SipResult {
  const r = annualRatePct / 100 / 12 // monthly rate derived from annual assumption
  const n = Math.round(years * 12)
  const invested = monthly * n
  let value: number
  if (Math.abs(r) < 1e-12) {
    value = invested // zero-return handled correctly
  } else {
    value = monthly * ((Math.pow(1 + r, n) - 1) / r) * (1 + r)
  }
  const yearly: SipResult['yearly'] = []
  for (let y = 1; y <= years; y++) {
    const m = y * 12
    let v: number
    if (Math.abs(r) < 1e-12) v = monthly * m
    else v = monthly * ((Math.pow(1 + r, m) - 1) / r) * (1 + r)
    yearly.push({ year: y, invested: monthly * m, value: v, returns: v - monthly * m })
  }
  return { invested, estimatedReturns: value - invested, finalValue: value, yearly }
}

export interface FdResult {
  invested: number
  interest: number
  maturityValue: number
  effectiveAnnualYield: number
  yearly: { year: number; value: number }[]
}

export function calcFd(principal: number, annualRatePct: number, years: number, compPerYear: number): FdResult {
  const r = annualRatePct / 100
  const n = Math.max(1, Math.floor(compPerYear))
  const maturity = principal * Math.pow(1 + r / n, n * years)
  const yearly: FdResult['yearly'] = []
  for (let y = 1; y <= Math.ceil(years); y++) {
    const t = Math.min(y, years)
    yearly.push({ year: t, value: principal * Math.pow(1 + r / n, n * t) })
  }
  const yearsTotal = Math.max(years, 1e-9)
  const eff = Math.pow(maturity / Math.max(principal, 1e-9), 1 / yearsTotal) - 1
  return { invested: principal, interest: maturity - principal, maturityValue: maturity, effectiveAnnualYield: eff * 100, yearly }
}

export interface RdResult {
  invested: number
  interest: number
  maturityValue: number
  yearly: { year: number; invested: number; value: number }[]
}

export function calcRd(monthly: number, annualRatePct: number, years: number): RdResult {
  // Each instalment compounds quarterly (Indian bank standard) from its own deposit month.
  const n = Math.round(years * 12)
  const q = annualRatePct / 100 / 4
  let maturity = 0
  const perInstalment: number[] = []
  for (let i = 0; i < n; i++) {
    const quarters = (n - i) / 3 // months remaining / 3
    const fv = monthly * Math.pow(1 + q, quarters)
    perInstalment.push(fv)
    maturity += fv
  }
  const invested = monthly * n
  const yearly: RdResult['yearly'] = []
  for (let y = 1; y <= Math.ceil(years); y++) {
    const m = Math.min(y * 12, n)
    let v = 0
    for (let i = 0; i < m; i++) {
      const quarters = (n - i) / 3
      v += monthly * Math.pow(1 + q, quarters)
    }
    yearly.push({ year: y, invested: monthly * m, value: v })
  }
  return { invested, interest: maturity - invested, maturityValue: maturity, yearly }
}

export interface CompoundResult {
  invested: number
  interest: number
  finalValue: number
  yearly: { year: number; invested: number; value: number }[]
}

export function calcCompound(initial: number, monthlyAdd: number, annualRatePct: number, years: number, compPerYear: number): CompoundResult {
  const r = annualRatePct / 100 / compPerYear
  const periodsPerYear = Math.max(1, Math.floor(compPerYear))
  // approximate monthly additions compounding within the same schedule
  let value = initial
  let invested = initial
  const yearly: CompoundResult['yearly'] = []
  const monthsPerPeriod = 12 / periodsPerYear
  for (let p = 1; p <= periodsPerYear * years; p++) {
    value *= 1 + r
    if (monthlyAdd > 0) {
      // additions spread evenly within each compounding period
      const adds = monthlyAdd * 12 / periodsPerYear
      value += adds * (1 + r * 0.5) // mid-period contribution approximation
      invested += adds
    }
    if (p % periodsPerYear === 0) {
      yearly.push({ year: p / periodsPerYear, invested, value })
    }
  }
  return { invested, interest: value - invested, finalValue: value, yearly }
}

export interface EmiResult {
  emi: number
  totalInterest: number
  totalPayment: number
  yearly: { year: number; principalPaid: number; interestPaid: number; balance: number }[]
}

export function calcEmi(principal: number, annualRatePct: number, years: number): EmiResult {
  const r = annualRatePct / 100 / 12
  const n = Math.round(years * 12)
  let emi: number
  if (Math.abs(r) < 1e-12) emi = principal / n
  else emi = (principal * r * Math.pow(1 + r, n)) / (Math.pow(1 + r, n) - 1)
  let balance = principal
  let totalInterest = 0
  const yearly: EmiResult['yearly'] = []
  let pAcc = 0
  let iAcc = 0
  for (let m = 1; m <= n; m++) {
    const interest = balance * r
    const principalPart = emi - interest
    balance -= principalPart
    totalInterest += interest
    pAcc += principalPart
    iAcc += interest
    if (m % 12 === 0 || m === n) {
      yearly.push({ year: Math.ceil(m / 12), principalPaid: pAcc, interestPaid: iAcc, balance: Math.max(balance, 0) })
      pAcc = 0
      iAcc = 0
    }
  }
  return { emi, totalInterest, totalPayment: principal + totalInterest, yearly }
}

export interface BudgetResult {
  income: number
  totalExpenses: number
  surplus: number
  savingsRate: number
  breakdown: { label: string; amount: number; percent: number; color: string }[]
  guidance: string[]
}

export function calcBudget(income: number, essentials: number, lifestyle: number, savings: number, debt: number): BudgetResult {
  const totalExpenses = essentials + lifestyle + debt
  const surplus = income - totalExpenses - savings
  const pct = (v: number) => (income > 0 ? (v / income) * 100 : 0)
  const breakdown = [
    { label: 'Essential expenses', amount: essentials, percent: pct(essentials), color: '#CCD5AE' },
    { label: 'Lifestyle expenses', amount: lifestyle, percent: pct(lifestyle), color: '#D4A373' },
    { label: 'Debt payments', amount: debt, percent: pct(debt), color: '#B08968' },
    { label: 'Savings', amount: savings, percent: pct(savings), color: '#8F9779' },
  ]
  const guidance: string[] = []
  const savePct = pct(savings)
  if (income > 0) {
    if (savePct >= 20) guidance.push(`Strong: you are saving ${savePct.toFixed(1)}% of income — the 20% benchmark is met.`)
    else guidance.push(`You are saving ${savePct.toFixed(1)}% of income. The 50/30/20 framework targets 20%; raising contributions gradually (1–2% per quarter) compounds significantly.`)
    if (pct(essentials) > 50) guidance.push(`Essential expenses are ${pct(essentials).toFixed(1)}% of income (target ≤ 50%). Housing and fixed costs are usually the largest lever here.`)
    if (pct(lifestyle) > 30) guidance.push(`Lifestyle spending is ${pct(lifestyle).toFixed(1)}% of income (target ≤ 30%). Consider trimming the biggest recurring leak first.`)
    if (pct(debt) > 40) guidance.push(`Debt payments are ${pct(debt).toFixed(1)}% of income — above the ~40% safety guideline. Prioritise high-interest payoff before new investing.`)
    if (surplus < 0) guidance.push(`Plan is over-committed by ${Math.abs(surplus).toLocaleString('en-IN', { maximumFractionDigits: 0 })}: either raise savings capacity or reduce an expense category.`)
  }
  return { income, totalExpenses, surplus, savingsRate: savePct, breakdown, guidance }
}

export interface InflationResult {
  futureCost: number
  purchasingPower: number
  yearly: { year: number; value: number }[]
}

export function calcInflation(amount: number, annualInflationPct: number, years: number): InflationResult {
  const yearly: InflationResult['yearly'] = []
  let v = amount
  for (let y = 1; y <= years; y++) {
    v *= 1 + annualInflationPct / 100
    yearly.push({ year: y, value: v })
  }
  return { futureCost: v, purchasingPower: amount / Math.pow(1 + annualInflationPct / 100, years), yearly }
}

export interface SavingsGoalResult {
  monthsRequired: number
  requiredMonthly: number
  totalContributions: number
  interestEarned: number
  shortfall: number
  reachable: boolean
}

export function calcSavingsGoal(target: number, existing: number, monthly: number, annualRatePct: number, months: number): SavingsGoalResult {
  const r = annualRatePct / 100 / 12
  // simulate month by month
  let value = existing
  let contributions = 0
  let m = 0
  const maxMonths = Math.max(months, 1)
  while (m < maxMonths && value < target) {
    value = value * (1 + r) + monthly
    contributions += monthly
    m++
  }
  const reachable = value >= target
  if (!reachable) {
    // solve required monthly to reach target in `months`
    const n = maxMonths
    let required: number
    if (Math.abs(r) < 1e-12) required = (target - existing * Math.pow(1 + 0, n)) / n
    else required = (target - existing * Math.pow(1 + r, n)) * (r / (Math.pow(1 + r, n) - 1))
    return { monthsRequired: maxMonths, requiredMonthly: Math.max(required, 0), totalContributions: required * n, interestEarned: target - existing - required * n, shortfall: target - value, reachable }
  }
  return { monthsRequired: m, requiredMonthly: monthly, totalContributions: contributions, interestEarned: value - existing - contributions, shortfall: 0, reachable: true }
}

export const calculatorRegistry = [
  { key: 'sip', title: 'SIP Calculator', description: 'Project systematic investment growth with monthly contributions and compounding.', icon: 'TrendingUp' },
  { key: 'fd', title: 'Fixed Deposit (FD)', description: 'Maturity value with configurable compounding frequency.', icon: 'Landmark' },
  { key: 'rd', title: 'Recurring Deposit (RD)', description: 'Monthly deposits with per-instalment quarterly compounding.', icon: 'CalendarClock' },
  { key: 'compound', title: 'Compound Interest', description: 'Initial amount plus optional contributions, any compounding frequency.', icon: 'Sigma' },
  { key: 'emi', title: 'Loan EMI', description: 'Equated monthly instalment with full interest breakdown.', icon: 'HandCoins' },
  { key: 'budget', title: 'Budget Planner', description: 'Analyse your income split and get 50/30/20 guidance.', icon: 'Wallet' },
  { key: 'inflation', title: 'Inflation Impact', description: 'See what today\u2019s money will cost — and be worth — in the future.', icon: 'Bird' },
  { key: 'goal', title: 'Savings Goal', description: 'Find the monthly saving required to reach your target.', icon: 'Target' },
] as const
