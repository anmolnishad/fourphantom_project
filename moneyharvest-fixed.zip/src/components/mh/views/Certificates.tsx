'use client'

import { useEffect, useState } from 'react'
import { navigate, apiGet, apiSend, fmtDate } from './../router'
import { useApp } from './../store'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Skeleton } from '@/components/ui/skeleton'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog'
import QRCode from 'qrcode'
import { jsPDF } from 'jspdf'
import {
  Award, BadgeCheck, ShieldCheck, Download, QrCode, ShieldAlert, CheckCircle2,
  XCircle, Copy, Lock, ScanSearch, GraduationCap, Ban,
} from 'lucide-react'

interface Cert {
  id: string; certId: string; courseKey: string; courseTitle: string; learnerName: string
  score: number; percent: number; issuedAt: string; revoked: boolean
}
interface Eligibility {
  courseKey: string; title: string; requiredPercent: number; quizCategory: string
  bestPercent: number; eligible: boolean; alreadyHeld: boolean
}

const COURSE_DESC: Record<string, string> = {
  'financial-literacy-fundamentals': 'Core money concepts: budgeting, saving, inflation, compounding and goal planning.',
  'personal-finance-essentials': 'Applied personal finance: expense management, emergency funds and goal planning.',
  'investment-awareness': 'Understanding markets, mutual funds, SIPs, risk and long-term investing behaviour.',
  'cybersecurity-awareness': 'Recognising phishing, protecting credentials and defending accounts.',
  'digital-banking-safety': 'Safe UPI practice, payment verification habits and dispute rights.',
  'scam-awareness-prevention': 'Detecting fraud patterns across messages, links and platforms.',
}

async function qrDataUrl(text: string): Promise<string> {
  return QRCode.toDataURL(text, { width: 512, margin: 1, color: { dark: '#3A4229', light: '#FFFDF2' } })
}

export function downloadCertificatePdf(cert: Cert) {
  const doc = new jsPDF({ orientation: 'landscape', unit: 'mm', format: 'a4' })
  const W = 297, H = 210

  // cream background
  doc.setFillColor(254, 250, 224)
  doc.rect(0, 0, W, H, 'F')
  // sage decorative double border
  doc.setDrawColor(204, 213, 174); doc.setLineWidth(4); doc.rect(9, 9, W - 18, H - 18)
  doc.setDrawColor(176, 137, 104); doc.setLineWidth(0.7); doc.rect(15.5, 15.5, W - 31, H - 31)
  // corner accents
  doc.setFillColor(212, 163, 115)
  const c = 7
  for (const [x, y] of [[9, 9], [W - 9 - c, 9], [9, H - 9 - c], [W - 9 - c, H - 9 - c]]) doc.rect(x, y, c, c, 'F')

  doc.setTextColor(47, 54, 37)
  doc.setFont('times', 'normal'); doc.setFontSize(10)
  doc.text('M O N E Y   H A R V E S T', W / 2, 30, { align: 'center' })
  doc.setFontSize(8); doc.setTextColor(143, 107, 68)
  doc.text('GROW YOUR FINANCIAL INTELLIGENCE', W / 2, 36, { align: 'center' })

  doc.setFont('times', 'bold'); doc.setFontSize(34); doc.setTextColor(47, 54, 37)
  doc.text('Certificate of Completion', W / 2, 58, { align: 'center' })

  doc.setFont('times', 'italic'); doc.setFontSize(12); doc.setTextColor(107, 112, 82)
  doc.text('This is to certify that', W / 2, 74, { align: 'center' })

  doc.setFont('times', 'bold'); doc.setFontSize(30); doc.setTextColor(143, 107, 68)
  doc.text(cert.learnerName, W / 2, 90, { align: 'center' })
  doc.setDrawColor(212, 163, 115); doc.setLineWidth(0.5)
  doc.line(W / 2 - 60, 94, W / 2 + 60, 94)

  doc.setFont('times', 'italic'); doc.setFontSize(11); doc.setTextColor(107, 112, 82)
  doc.text('has successfully completed the course', W / 2, 103, { align: 'center' })
  doc.setFont('times', 'bold'); doc.setFontSize(17); doc.setTextColor(47, 54, 37)
  doc.text(cert.courseTitle, W / 2, 112, { align: 'center' })
  doc.setFont('times', 'normal'); doc.setFontSize(10.5)
  doc.text(`with a passing score of ${cert.percent}%  ·  issued on ${fmtDate(cert.issuedAt)}`, W / 2, 121, { align: 'center' })

  // QR + verification line
  const verifyUrl = `${window.location.origin}/#/verify/${cert.certId}`
  qrDataUrl(verifyUrl).then((url) => {
    doc.addImage(url, 'PNG', W / 2 - 16, 130, 32, 32)
    doc.setFontSize(8.5); doc.setTextColor(107, 112, 82)
    doc.text(`Certificate ID: ${cert.certId}    ·    Verify: ${verifyUrl.replace(/^https?:\/\//, '')}`, W / 2, 169, { align: 'center' })

    // signature blocks
    doc.setFontSize(9); doc.setTextColor(47, 54, 37)
    doc.setDrawColor(176, 137, 104); doc.setLineWidth(0.4)
    doc.line(40, 172, 100, 172)
    doc.line(W - 100, 172, W - 40, 172)
    doc.setFontSize(9)
    doc.text('Authorised Issuer', 70, 177, { align: 'center' })
    doc.text('Date of Issue', W - 70, 177, { align: 'center' })
    doc.setFontSize(7); doc.setTextColor(139, 143, 110)
    doc.text('Money Harvest platform-issued educational completion certificate — not a government or', W / 2, 188, { align: 'center' })
    doc.text('university-accredited qualification. Verify authenticity via the QR code or certificate ID.', W / 2, 192, { align: 'center' })
    doc.save(`Money-Harvest-Certificate-${cert.certId}.pdf`)
  })
}

// =================== Certificate Center ===================

export function Certificates() {
  const { user, userLoaded } = useApp()
  const [certs, setCerts] = useState<Cert[] | null>(null)
  const [elig, setElig] = useState<Eligibility[] | null>(null)
  const [claiming, setClaiming] = useState('')
  const [preview, setPreview] = useState<Cert | null>(null)

  const load = () => {
    if (!user) { setCerts([]); setElig([]); return }
    apiGet<{ certificates: Cert[]; eligibility: Eligibility[] }>('/api/certificates')
      .then((d) => { setCerts(d.certificates); setElig(d.eligibility) })
      .catch(() => { setCerts([]); setElig([]) })
  }
  // eslint-disable-next-line react-hooks/set-state-in-effect -- load resets before fetch
  useEffect(load, [user])

  const claim = async (courseKey: string) => {
    setClaiming(courseKey)
    try {
      await apiSend('/api/certificates', 'POST', { courseKey })
      load()
    } catch { /* surfaced via state refresh */ }
    setClaiming('')
  }

  return (
    <div className="view-enter mx-auto max-w-6xl px-4 sm:px-6 py-10">
      <span className="badge-soft badge-bronze mb-3"><Award className="h-3.5 w-3.5" /> Certificate Center</span>
      <h1 className="font-display text-3xl sm:text-4xl font-semibold text-[#2F3625]">Certificates worth earning</h1>
      <p className="mt-2 text-[#55613F] max-w-2xl leading-relaxed">
        Each certificate is issued only after a verified passing score in the required quiz — the server re-checks eligibility before issuing. Every certificate carries a unique ID and a QR code linked to a public verification page. These are <strong>platform-issued educational completion certificates</strong>, not government- or university-accredited qualifications.
      </p>

      {userLoaded && !user && (
        <div className="card-lux p-6 mt-6 bg-[#E9EDC9] border-[#D8DCBB] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <p className="text-sm text-[#3A4229]"><Lock className="inline h-4 w-4 mr-1.5 -mt-0.5" /> Sign in to track progress toward certificates and claim the ones you have earned.</p>
          <div className="flex gap-2 shrink-0">
            <Button variant="outline" className="font-semibold border-[#B4C18B] bg-[#FFFDF2]" onClick={() => navigate('/signin')}>Sign In</Button>
            <Button className="btn-bronze font-semibold" onClick={() => navigate('/signup')}>Get Started</Button>
          </div>
        </div>
      )}

      {/* earned certificates */}
      {user && (
        <section className="mt-10">
          <h2 className="font-display text-2xl font-semibold text-[#2F3625] mb-4">My certificates</h2>
          {certs === null ? (
            <div className="grid sm:grid-cols-2 gap-4">{Array.from({ length: 2 }).map((_, i) => <Skeleton key={i} className="h-44 rounded-xl" />)}</div>
          ) : certs.length === 0 ? (
            <div className="card-lux p-8 text-center">
              <Award className="h-10 w-10 mx-auto text-[#D8D2B4] mb-3" />
              <p className="font-display text-lg text-[#2F3625]">No certificates yet</p>
              <p className="text-sm text-[#6B7052] mt-1">Pass a required quiz, then claim your certificate below.</p>
              <Button className="btn-bronze mt-4 font-semibold" onClick={() => navigate('/quiz')}>Take a Quiz</Button>
            </div>
          ) : (
            <div className="grid md:grid-cols-2 gap-5">
              {certs.map((c) => (
                <div key={c.id} className={`card-lux p-6 ${c.revoked ? 'opacity-70' : ''}`}>
                  <div className="flex items-start justify-between">
                    <div>
                      <p className="font-display text-xl font-semibold text-[#2F3625]">{c.courseTitle}</p>
                      <p className="text-xs text-[#6B7052] mt-1">Issued to <strong>{c.learnerName}</strong> on {fmtDate(c.issuedAt)}</p>
                    </div>
                    {c.revoked
                      ? <span className="badge-soft bg-[#F6DAD5] text-[#8C3B31] border-[#DCA093]"><Ban className="h-3 w-3" /> Revoked</span>
                      : <span className="badge-soft badge-sage"><BadgeCheck className="h-3.5 w-3.5" /> Valid</span>}
                  </div>
                  <div className="mt-3 flex items-center gap-2 text-sm">
                    <span className="font-mono text-xs bg-[#F4F0DB] rounded px-2 py-1 text-[#6E5133]">{c.certId}</span>
                    <span className="badge-bronze">{c.percent}% score</span>
                  </div>
                  <div className="mt-4 flex flex-wrap gap-2">
                    <Button size="sm" className="btn-bronze font-semibold" onClick={() => downloadCertificatePdf(c)} disabled={c.revoked}>
                      <Download className="h-3.5 w-3.5 mr-1" /> PDF
                    </Button>
                    <Button size="sm" variant="outline" className="font-semibold border-[#B4C18B]" onClick={() => setPreview(c)}>
                      <QrCode className="h-3.5 w-3.5 mr-1" /> View & Share
                    </Button>
                    <Button size="sm" variant="ghost" className="font-semibold text-[#55613F]" onClick={() => navigate(`/verify/${c.certId}`)}>
                      <ShieldCheck className="h-3.5 w-3.5 mr-1" /> Verify
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </section>
      )}

      {/* eligibility / tracks */}
      <section className="mt-10">
        <h2 className="font-display text-2xl font-semibold text-[#2F3625] mb-4">Certificate tracks & requirements</h2>
        {user && elig === null ? (
          <div className="grid sm:grid-cols-2 gap-4">{Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-32 rounded-xl" />)}</div>
        ) : (
          <div className="grid md:grid-cols-2 gap-5">
            {(elig || []).map((e) => (
              <div key={e.courseKey} className="card-lux p-5">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <p className="font-display font-semibold text-[#2F3625]">{e.title}</p>
                    <p className="text-xs text-[#6B7052] mt-1 leading-relaxed">{COURSE_DESC[e.courseKey]}</p>
                  </div>
                  <span className="badge-bronze shrink-0">{e.requiredPercent}% to pass</span>
                </div>
                <div className="mt-3">
                  <div className="flex justify-between text-xs text-[#6B7052] mb-1">
                    <span>Best score in {e.quizCategory.replace('-', ' ')} quiz</span>
                    <span className="font-bold">{e.bestPercent}%</span>
                  </div>
                  <div className="h-2 rounded-full bg-[#E3DEC4] overflow-hidden">
                    <div className="h-full rounded-full" style={{ width: `${Math.min(100, e.bestPercent)}%`, background: e.eligible || e.alreadyHeld ? '#8F9779' : '#D4A373' }} />
                  </div>
                </div>
                <div className="mt-4">
                  {e.alreadyHeld ? (
                    <span className="text-xs font-semibold text-[#4C5B2E] flex items-center gap-1.5"><CheckCircle2 className="h-4 w-4" /> Already earned</span>
                  ) : e.eligible ? (
                    <Button size="sm" className="btn-sage font-semibold" onClick={() => claim(e.courseKey)} disabled={claiming === e.courseKey}>
                      {claiming === e.courseKey ? 'Issuing…' : 'Claim your certificate'}
                    </Button>
                  ) : (
                    <Button size="sm" variant="outline" className="font-semibold border-[#B4C18B]" onClick={() => navigate(`/quiz?category=${e.quizCategory}`)}>
                      Take the {e.quizCategory.replace('-', ' ')} quiz <GraduationCap className="h-3.5 w-3.5 ml-1" />
                    </Button>
                  )}
                </div>
              </div>
            ))}
            {!user && ['financial-literacy-fundamentals', 'investment-awareness', 'cybersecurity-awareness', 'scam-awareness-prevention'].map((k) => (
              <div key={k} className="card-lux p-5">
                <p className="font-display font-semibold text-[#2F3625]">{k.split('-').map((w) => w[0].toUpperCase() + w.slice(1)).join(' ').replace('Fundamentals', 'Fundamentals')}</p>
                <p className="text-xs text-[#6B7052] mt-1">{COURSE_DESC[k]}</p>
                <p className="text-xs font-semibold text-[#8F6B44] mt-3 flex items-center gap-1.5"><Lock className="h-3.5 w-3.5" /> Sign in to track eligibility</p>
              </div>
            ))}
          </div>
        )}
      </section>

      {/* preview dialog */}
      <Dialog open={!!preview} onOpenChange={(o) => !o && setPreview(null)}>
        <DialogContent className="max-w-3xl">
          {preview && <CertPreview cert={preview} />}
        </DialogContent>
      </Dialog>
    </div>
  )
}

// =================== full preview with QR ===================

export function CertPreview({ cert }: { cert: Cert }) {
  const [qr, setQr] = useState('')
  const verifyUrl = typeof window !== 'undefined' ? `${window.location.origin}/#/verify/${cert.certId}` : ''
  useEffect(() => { qrDataUrl(verifyUrl).then(setQr) }, [verifyUrl])

  const copyLink = () => navigator.clipboard?.writeText(verifyUrl).catch(() => {})

  return (
    <div>
      <div className="cert-frame rounded-sm bg-[#FFFDF2] p-8 sm:p-10 text-center relative">
        <div className="absolute inset-2.5 border border-[#E3DEC4] rounded-sm pointer-events-none" aria-hidden />
        <p className="text-[0.6rem] tracking-[0.3em] uppercase text-[#8F6B44] font-semibold">Money Harvest</p>
        <p className="font-display text-3xl font-semibold mt-3 text-[#2F3625]">Certificate of Completion</p>
        <p className="text-sm text-[#6B7052] mt-3 italic">This is to certify that</p>
        <p className="font-display text-4xl mt-2 text-[#8F6B44]">{cert.learnerName}</p>
        <div className="w-40 h-px bg-[#D4A373] mx-auto mt-2" aria-hidden />
        <p className="text-sm text-[#6B7052] mt-3">has successfully completed the course</p>
        <p className="font-display text-2xl font-semibold text-[#2F3625] mt-1">{cert.courseTitle}</p>
        <p className="text-sm text-[#55613F] mt-1">with a passing score of {cert.percent}% · issued {fmtDate(cert.issuedAt)}</p>
        <div className="mt-6 flex items-end justify-center gap-10 text-[0.65rem] text-[#6B7052]">
          <div className="w-36 border-t border-[#B08968] pt-1.5 text-center">Authorised Issuer<br /><span className="text-[0.6rem] text-[#9B9F7E]">Money Harvest Education</span></div>
          <div className="text-center">
            {qr ? <img src={qr} alt={`QR code verifying certificate ${cert.certId}`} className="h-20 w-20 mx-auto border border-[#E3DEC4] rounded" /> : <div className="h-20 w-20 mx-auto bg-[#F4F0DB] rounded animate-pulse" />}
            <span className="mt-1 block font-mono">{cert.certId}</span>
          </div>
          <div className="w-36 border-t border-[#B08968] pt-1.5 text-center">Date of Issue</div>
        </div>
      </div>
      <div className="flex flex-wrap items-center justify-center gap-2 mt-5">
        <Button className="btn-bronze font-semibold" onClick={() => downloadCertificatePdf(cert)} disabled={cert.revoked}><Download className="h-4 w-4 mr-1.5" /> Download PDF</Button>
        <Button variant="outline" className="font-semibold border-[#B4C18B]" onClick={copyLink}><Copy className="h-4 w-4 mr-1.5" /> Copy verification link</Button>
        <Button variant="ghost" className="font-semibold text-[#55613F]" onClick={() => navigate(`/verify/${cert.certId}`)}><ShieldCheck className="h-4 w-4 mr-1.5" /> Open verification page</Button>
      </div>
      <p className="text-center text-[0.68rem] text-[#8B8F6E] mt-3">Platform-issued educational completion certificate — not a government or university-accredited qualification.</p>
    </div>
  )
}

// =================== Public verification page ===================

export function VerifyPage({ certId }: { certId: string }) {
  const [state, setState] = useState<'loading' | 'done'>('loading')
  const [data, setData] = useState<{ status: string; message: string; certificate?: Record<string, unknown>; issuer?: string } | null>(null)

  useEffect(() => {
    apiGet<{ status: string; message: string; certificate?: Record<string, unknown>; issuer?: string }>(`/api/certificates/verify?certId=${encodeURIComponent(certId)}`)
      .then((d) => { setData(d); setState('done') })
      .catch(() => { setData({ status: 'INVALID', message: 'Verification request failed.' }); setState('done') })
  }, [certId])

  const valid = data?.status === 'VALID'
  const revoked = data?.status === 'REVOKED'

  return (
    <div className="view-enter mx-auto max-w-2xl px-4 py-14">
      <div className="text-center mb-8">
        <span className="badge-soft badge-bronze mb-3"><ScanSearch className="h-3.5 w-3.5" /> Public Certificate Verification</span>
        <h1 className="font-display text-3xl font-semibold text-[#2F3625]">Verify a Money Harvest certificate</h1>
        <p className="font-mono text-sm text-[#6B7052] mt-2">{certId}</p>
      </div>

      {state === 'loading' ? (
        <Skeleton className="h-56 rounded-2xl" />
      ) : (
        <div className={`card-lux p-8 text-center ${valid ? 'border-[#C6CFA4] bg-[#F3F7E2]' : revoked ? 'border-[#DCA093] bg-[#FBEBE7]' : 'border-[#D8D2B4]'}`}>
          <span className={`h-20 w-20 rounded-full mx-auto flex items-center justify-center ${valid ? 'bg-[#CCD5AE]' : revoked ? 'bg-[#E8B8B0]' : 'bg-[#E3DEC4]'}`}>
            {valid ? <CheckCircle2 className="h-10 w-10 text-[#3A4229]" /> : revoked ? <XCircle className="h-10 w-10 text-[#8C3B31]" /> : <ShieldAlert className="h-10 w-10 text-[#6B7052]" />}
          </span>
          <p className="font-display text-3xl font-semibold mt-4" style={{ color: valid ? '#4C5B2E' : revoked ? '#8C3B31' : '#6B7052' }}>
            {data?.status === 'VALID' ? 'Valid' : data?.status === 'REVOKED' ? 'Revoked' : 'Not Found'}
          </p>
          <p className="text-sm text-[#55613F] mt-2 max-w-md mx-auto leading-relaxed">{data?.message}</p>

          {valid && data?.certificate && (
            <div className="mt-6 grid sm:grid-cols-2 gap-3 text-left max-w-md mx-auto">
              {[
                ['Learner', String(data.certificate.learnerName)],
                ['Course', String(data.certificate.courseTitle)],
                ['Score', `${data.certificate.percent}%`],
                ['Issued', fmtDate(String(data.certificate.issuedAt))],
              ].map(([k, v]) => (
                <div key={k} className="bg-[#FFFDF2] border border-[#E3DEC4] rounded-lg px-4 py-2.5">
                  <p className="text-[0.62rem] uppercase tracking-widest font-bold text-[#8B8F6E]">{k}</p>
                  <p className="text-sm font-semibold text-[#2F3625]">{v}</p>
                </div>
              ))}
            </div>
          )}

          <p className="text-[0.68rem] text-[#8B8F6E] mt-6 max-w-md mx-auto leading-relaxed">{data?.issuer || 'Money Harvest certificates are platform-issued educational completion records — not government- or university-accredited qualifications.'}</p>
          <Button variant="outline" className="mt-6 font-semibold border-[#B4C18B]" onClick={() => navigate('/certificates')}>Certificate Center</Button>
        </div>
      )}
    </div>
  )
}
