'use client'

import { useEffect, useState } from 'react'
import { navigate, apiGet, apiSend, useRoute } from './../router'
import { useApp } from './../store'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Logo } from './../Logo'
import { Leaf, Mail, Lock, UserRound, Eye, EyeOff, ArrowLeft, ShieldCheck, Info } from 'lucide-react'

function AuthShell({ children, title, sub }: { children: React.ReactNode; title: string; sub: string }) {
  return (
    <div className="view-enter flex min-h-[calc(100vh-4rem)] items-center justify-center px-4 py-12 section-cornsilk">
      <div className="w-full max-w-md">
        <div className="text-center mb-7">
          <button onClick={() => navigate('/')} className="inline-block"><Logo size={44} /></button>
        </div>
        <div className="card-lux p-7 sm:p-8">
          <h1 className="font-display text-2xl font-semibold text-[#2F3625] text-center">{title}</h1>
          <p className="text-sm text-[#6B7052] text-center mt-1.5 mb-6">{sub}</p>
          {children}
        </div>
        <p className="text-center text-xs text-[#8B8F6E] mt-5 flex items-center justify-center gap-1.5">
          <ShieldCheck className="h-3.5 w-3.5" /> Passwords are hashed with bcrypt — never stored in plain text.
        </p>
      </div>
    </div>
  )
}

export function SignIn() {
  const { refreshUser } = useApp()
  const route = useRoute()
  const next = route.query.get('next') || '/dashboard'
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [show, setShow] = useState(false)
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')

  const submit = async (e: React.FormEvent) => {
    e.preventDefault()
    setBusy(true); setError('')
    try {
      await apiSend('/api/auth/login', 'POST', { email, password })
      await refreshUser()
      navigate(next)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Sign-in failed.')
    } finally { setBusy(false) }
  }

  return (
    <AuthShell title="Welcome back" sub="Sign in to continue your learning journey.">
      <form onSubmit={submit} className="space-y-4">
        <div className="space-y-1.5">
          <Label htmlFor="si-email">Email</Label>
          <div className="relative">
            <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-[#8B8F6E]" />
            <Input id="si-email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required
              placeholder="you@example.com" className="pl-9 h-11 bg-[#FFFDF2]" autoComplete="email" />
          </div>
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="si-pass">Password</Label>
          <div className="relative">
            <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-[#8B8F6E]" />
            <Input id="si-pass" type={show ? 'text' : 'password'} value={password} onChange={(e) => setPassword(e.target.value)} required
              placeholder="Your password" className="pl-9 pr-10 h-11 bg-[#FFFDF2]" autoComplete="current-password" />
            <button type="button" onClick={() => setShow((s) => !s)} className="absolute right-3 top-1/2 -translate-y-1/2 text-[#8B8F6E]" aria-label="Toggle password visibility">
              {show ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
            </button>
          </div>
        </div>
        {error && <p className="text-sm text-[#A94438] bg-[#F7E2DE] rounded-lg px-3.5 py-2.5">{error}</p>}
        <Button type="submit" className="btn-bronze w-full h-11 font-semibold" disabled={busy}>{busy ? 'Signing in…' : 'Sign In'}</Button>
      </form>
      <div className="mt-5 flex items-center justify-between text-sm">
        <button onClick={() => navigate('/forgot')} className="link-quiet underline font-semibold">Forgot password?</button>
        <button onClick={() => navigate('/signup')} className="link-quiet underline font-semibold">Create account</button>
      </div>
    </AuthShell>
  )
}

export function SignUp() {
  const { refreshUser } = useApp()
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [confirm, setConfirm] = useState('')
  const [show, setShow] = useState(false)
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')

  const submit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')
    if (password !== confirm) { setError('Passwords do not match.'); return }
    setBusy(true)
    try {
      await apiSend('/api/auth/register', 'POST', { name, email, password })
      await refreshUser()
      navigate('/dashboard')
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Registration failed.')
    } finally { setBusy(false) }
  }

  return (
    <AuthShell title="Create your account" sub="Free forever. Track progress, earn certificates, join the community.">
      <form onSubmit={submit} className="space-y-4">
        <div className="space-y-1.5">
          <Label htmlFor="su-name">Full name</Label>
          <div className="relative">
            <UserRound className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-[#8B8F6E]" />
            <Input id="su-name" value={name} onChange={(e) => setName(e.target.value)} required minLength={2} maxLength={60}
              placeholder="Your name" className="pl-9 h-11 bg-[#FFFDF2]" autoComplete="name" />
          </div>
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="su-email">Email</Label>
          <div className="relative">
            <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-[#8B8F6E]" />
            <Input id="su-email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required
              placeholder="you@example.com" className="pl-9 h-11 bg-[#FFFDF2]" autoComplete="email" />
          </div>
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="su-pass">Password</Label>
          <div className="relative">
            <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-[#8B8F6E]" />
            <Input id="su-pass" type={show ? 'text' : 'password'} value={password} onChange={(e) => setPassword(e.target.value)} required
              placeholder="8+ chars with a letter and number" className="pl-9 pr-10 h-11 bg-[#FFFDF2]" autoComplete="new-password" />
            <button type="button" onClick={() => setShow((s) => !s)} className="absolute right-3 top-1/2 -translate-y-1/2 text-[#8B8F6E]" aria-label="Toggle password visibility">
              {show ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
            </button>
          </div>
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="su-confirm">Confirm password</Label>
          <Input id="su-confirm" type="password" value={confirm} onChange={(e) => setConfirm(e.target.value)} required
            placeholder="Repeat password" className="h-11 bg-[#FFFDF2]" autoComplete="new-password" />
        </div>
        {error && <p className="text-sm text-[#A94438] bg-[#F7E2DE] rounded-lg px-3.5 py-2.5">{error}</p>}
        <Button type="submit" className="btn-bronze w-full h-11 font-semibold" disabled={busy}>{busy ? 'Creating account…' : 'Get Started'}</Button>
        <p className="text-[0.7rem] text-[#8B8F6E] leading-relaxed">
          By creating an account you agree to use Money Harvest for education only. Platform certificates are educational completion records, not accredited qualifications.
        </p>
      </form>
      <p className="mt-5 text-sm text-center">
        Already have an account? <button onClick={() => navigate('/signin')} className="link-quiet underline font-semibold">Sign in</button>
      </p>
    </AuthShell>
  )
}

export function Forgot() {
  const [mode, setMode] = useState<'request' | 'confirm'>('request')
  const [email, setEmail] = useState('')
  const [token, setToken] = useState('')
  const [password, setPassword] = useState('')
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const [success, setSuccess] = useState('')

  const request = async (e: React.FormEvent) => {
    e.preventDefault()
    setBusy(true); setError(''); setSuccess('')
    try {
      const d = await apiSend<{ message: string; devResetToken?: string }>('/api/auth/reset', 'POST', { email })
      setSuccess(d.message)
      if (d.devResetToken) setToken(d.devResetToken)
      if (d.devResetToken) setMode('confirm')
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Request failed.')
    } finally { setBusy(false) }
  }

  const confirm = async (e: React.FormEvent) => {
    e.preventDefault()
    setBusy(true); setError(''); setSuccess('')
    try {
      const d = await apiSend<{ message: string }>('/api/auth/reset', 'PUT', { token, password })
      setSuccess(d.message)
      setTimeout(() => navigate('/signin'), 1800)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Reset failed.')
    } finally { setBusy(false) }
  }

  return (
    <AuthShell title="Reset your password" sub="We’ll help you get back into your account.">
      {mode === 'request' ? (
        <form onSubmit={request} className="space-y-4">
          <div className="space-y-1.5">
            <Label htmlFor="fp-email">Account email</Label>
            <Input id="fp-email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required placeholder="you@example.com" className="h-11 bg-[#FFFDF2]" />
          </div>
          {error && <p className="text-sm text-[#A94438] bg-[#F7E2DE] rounded-lg px-3.5 py-2.5">{error}</p>}
          {success && <p className="text-sm text-[#4C5B2E] bg-[#E7EDD3] rounded-lg px-3.5 py-2.5">{success}</p>}
          <Button type="submit" className="btn-bronze w-full h-11 font-semibold" disabled={busy}>{busy ? 'Requesting…' : 'Request reset link'}</Button>
        </form>
      ) : (
        <form onSubmit={confirm} className="space-y-4">
          <div className="space-y-1.5">
            <Label htmlFor="fp-token">Reset token</Label>
            <Input id="fp-token" value={token} onChange={(e) => setToken(e.target.value)} required className="h-11 bg-[#FFFDF2] font-mono text-xs" />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="fp-pass">New password</Label>
            <Input id="fp-pass" type="password" value={password} onChange={(e) => setPassword(e.target.value)} required placeholder="8+ chars with a letter and number" className="h-11 bg-[#FFFDF2]" autoComplete="new-password" />
          </div>
          {error && <p className="text-sm text-[#A94438] bg-[#F7E2DE] rounded-lg px-3.5 py-2.5">{error}</p>}
          {success && <p className="text-sm text-[#4C5B2E] bg-[#E7EDD3] rounded-lg px-3.5 py-2.5">{success}</p>}
          <Button type="submit" className="btn-bronze w-full h-11 font-semibold" disabled={busy}>{busy ? 'Updating…' : 'Set new password'}</Button>
        </form>
      )}
      <div className="mt-5 rounded-xl bg-[#F4F0DB] border border-[#E3DEC4] p-4 text-xs text-[#6B7052] leading-relaxed flex gap-2">
        <Info className="h-4 w-4 shrink-0 mt-0.5" />
        <span>
          This deployment has no email provider configured, so the reset link is shown here and clearly labelled — in production this is emailed instead. <button className="underline font-semibold" onClick={() => navigate('/signin')}>Back to sign in</button>
        </span>
      </div>
    </AuthShell>
  )
}
