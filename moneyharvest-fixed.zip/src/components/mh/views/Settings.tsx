'use client'

import { useState } from 'react'
import { navigate, apiSend } from './../router'
import { useApp } from './../store'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { UserRound, Mail, Palette, KeyRound, ShieldCheck, Eye, EyeOff } from 'lucide-react'

const AVATAR_COLORS = ['#D4A373', '#8F9779', '#B08968', '#CCD5AE', '#6B7052', '#A94438', '#8F6B44', '#55613F']

export function Settings() {
  const { user, userLoaded, refreshUser } = useApp()
  const [name, setName] = useState(user?.name || '')
  const [bio, setBio] = useState(user?.bio || '')
  const [color, setColor] = useState(user?.avatarColor || '#D4A373')
  const [savingProfile, setSavingProfile] = useState(false)
  const [profileMsg, setProfileMsg] = useState('')

  const [currentPw, setCurrentPw] = useState('')
  const [newPw, setNewPw] = useState('')
  const [confirmPw, setConfirmPw] = useState('')
  const [show, setShow] = useState(false)
  const [pwMsg, setPwMsg] = useState<{ ok: boolean; text: string } | null>(null)
  const [savingPw, setSavingPw] = useState(false)

  if (userLoaded && !user) { navigate('/signin?next=/settings'); return null }
  if (!user) return null

  const saveProfile = async () => {
    setSavingProfile(true); setProfileMsg('')
    try {
      await apiSend('/api/auth/password', 'PATCH', { name, bio, avatarColor: color })
      await refreshUser()
      setProfileMsg('Profile updated.')
    } catch (e) { setProfileMsg(e instanceof Error ? e.message : 'Update failed.') }
    setSavingProfile(false)
  }

  const changePw = async () => {
    setPwMsg(null)
    if (newPw !== confirmPw) { setPwMsg({ ok: false, text: 'New passwords do not match.' }); return }
    setSavingPw(true)
    try {
      await apiSend('/api/auth/password', 'PATCH', { currentPassword: currentPw, newPassword: newPw })
      setPwMsg({ ok: true, text: 'Password changed successfully.' })
      setCurrentPw(''); setNewPw(''); setConfirmPw('')
    } catch (e) { setPwMsg({ ok: false, text: e instanceof Error ? e.message : 'Change failed.' }) }
    setSavingPw(false)
  }

  return (
    <div className="view-enter mx-auto max-w-2xl px-4 sm:px-6 py-10 space-y-6">
      <h1 className="font-display text-3xl font-semibold text-[#2F3625]">Profile & Settings</h1>

      {/* profile */}
      <div className="card-lux p-6 space-y-4">
        <h2 className="font-display font-semibold text-[#2F3625] flex items-center gap-2"><UserRound className="h-4.5 w-4.5 h-[18px] w-[18px] text-[#B08968]" /> Public profile</h2>
        <div className="space-y-1.5">
          <Label htmlFor="st-name">Display name</Label>
          <Input id="st-name" value={name} onChange={(e) => setName(e.target.value)} className="bg-[#FFFDF2]" maxLength={60} />
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="st-bio">Bio (shown on community posts)</Label>
          <Textarea id="st-bio" value={bio} onChange={(e) => setBio(e.target.value)} className="bg-[#FFFDF2] min-h-16" maxLength={300} placeholder="A line about your learning journey…" />
        </div>
        <div className="space-y-1.5">
          <Label className="flex items-center gap-1.5"><Palette className="h-3.5 w-3.5" /> Avatar colour</Label>
          <div className="flex gap-2">
            {AVATAR_COLORS.map((c) => (
              <button key={c} onClick={() => setColor(c)} aria-label={`Choose colour ${c}`}
                className={`h-9 w-9 rounded-full border-2 transition-transform ${color === c ? 'border-[#2F3625] scale-110' : 'border-transparent'}`}
                style={{ background: c }} />
            ))}
          </div>
        </div>
        <div className="space-y-1.5">
          <Label className="flex items-center gap-1.5"><Mail className="h-3.5 w-3.5" /> Email</Label>
          <Input value={user.email} disabled className="bg-[#F4F0DB] text-[#6B7052]" />
          <p className="text-[0.68rem] text-[#8B8F6E]">{user.emailVerified ? 'Email verified.' : 'Email not yet verified — see the banner on your dashboard (development-mode verification).'}</p>
        </div>
        {profileMsg && <p className={`text-sm ${profileMsg.includes('updated') ? 'text-[#4C5B2E]' : 'text-[#A94438]'}`}>{profileMsg}</p>}
        <Button className="btn-bronze font-semibold" onClick={saveProfile} disabled={savingProfile}>{savingProfile ? 'Saving…' : 'Save profile'}</Button>
      </div>

      {/* password */}
      <div className="card-lux p-6 space-y-4">
        <h2 className="font-display font-semibold text-[#2F3625] flex items-center gap-2"><KeyRound className="h-[18px] w-[18px] text-[#B08968]" /> Change password</h2>
        <div className="space-y-1.5">
          <Label htmlFor="cp-cur">Current password</Label>
          <Input id="cp-cur" type="password" value={currentPw} onChange={(e) => setCurrentPw(e.target.value)} className="bg-[#FFFDF2]" autoComplete="current-password" />
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="cp-new">New password</Label>
          <div className="relative">
            <Input id="cp-new" type={show ? 'text' : 'password'} value={newPw} onChange={(e) => setNewPw(e.target.value)} className="bg-[#FFFDF2] pr-10" autoComplete="new-password" />
            <button type="button" onClick={() => setShow((s) => !s)} className="absolute right-3 top-1/2 -translate-y-1/2 text-[#8B8F6E]" aria-label="Toggle visibility">
              {show ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
            </button>
          </div>
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="cp-conf">Confirm new password</Label>
          <Input id="cp-conf" type="password" value={confirmPw} onChange={(e) => setConfirmPw(e.target.value)} className="bg-[#FFFDF2]" autoComplete="new-password" />
        </div>
        {pwMsg && <p className={`text-sm ${pwMsg.ok ? 'text-[#4C5B2E]' : 'text-[#A94438]'}`}>{pwMsg.text}</p>}
        <Button className="btn-bronze font-semibold" onClick={changePw} disabled={savingPw || !currentPw || !newPw}>
          {savingPw ? 'Updating…' : 'Update password'}
        </Button>
        <p className="text-[0.7rem] text-[#8B8F6E] flex items-center gap-1.5"><ShieldCheck className="h-3.5 w-3.5" /> Stored as a bcrypt hash — even we cannot read it.</p>
      </div>
    </div>
  )
}
