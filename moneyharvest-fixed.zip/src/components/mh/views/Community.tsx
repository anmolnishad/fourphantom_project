'use client'

import { useCallback, useEffect, useRef, useState } from 'react'
import { navigate, apiGet, apiSend, timeAgo, useDebounced } from './../router'
import { useApp } from './../store'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Skeleton } from '@/components/ui/skeleton'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog'
import {
  Heart, MessageCircle, Bookmark, BookmarkCheck, Send, Trash2, Pencil, Flag,
  ImagePlus, X, Users, Search, ArrowUpDown, ShieldCheck, CircleAlert,
} from 'lucide-react'

const CATEGORIES = [
  { key: 'saving-tips', label: 'Saving Tips', color: '#8F9779' },
  { key: 'investment-education', label: 'Investment Education', color: '#B08968' },
  { key: 'cybersecurity', label: 'Cybersecurity', color: '#6B7052' },
  { key: 'scam-alerts', label: 'Scam Alerts', color: '#A94438' },
  { key: 'learning-achievements', label: 'Learning Achievements', color: '#D4A373' },
  { key: 'general', label: 'General Discussion', color: '#8F6B44' },
]
const catLabel = (k: string) => CATEGORIES.find((c) => c.key === k)?.label || 'General'

interface Post {
  id: string; content: string; category: string; image: string | null
  likeCount: number; commentCount: number; edited: boolean
  createdAt: string; author: { id: string; name: string; avatarColor: string; role: string }
  liked: boolean; bookmarked: boolean; mine: boolean
}
interface CommentT {
  id: string; content: string; createdAt: string
  author: { id: string; name: string; avatarColor: string; role: string }
  replies: { id: string; content: string; createdAt: string; author: Post['author'] }[]
}

async function compressImage(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const img = new Image()
    const reader = new FileReader()
    reader.onload = () => { img.src = reader.result as string }
    reader.onerror = reject
    img.onload = () => {
      const max = 900
      const scale = Math.min(1, max / Math.max(img.width, img.height))
      const canvas = document.createElement('canvas')
      canvas.width = Math.round(img.width * scale)
      canvas.height = Math.round(img.height * scale)
      canvas.getContext('2d')?.drawImage(img, 0, 0, canvas.width, canvas.height)
      resolve(canvas.toDataURL('image/jpeg', 0.72))
    }
    img.onerror = reject
    reader.readAsDataURL(file)
  })
}

export function Community() {
  const { user } = useApp()
  const [posts, setPosts] = useState<Post[] | null>(null)
  const [cat, setCat] = useState('')
  const [sort, setSort] = useState<'new' | 'popular'>('new')
  const [q, setQ] = useState('')
  const dq = useDebounced(q, 350)
  const [page, setPage] = useState(1)
  const [pages, setPages] = useState(1)

  // composer
  const [composing, setComposing] = useState(false)
  const [newContent, setNewContent] = useState('')
  const [newCat, setNewCat] = useState('general')
  const [newImage, setNewImage] = useState<string | null>(null)
  const [posting, setPosting] = useState(false)
  const [composerError, setComposerError] = useState('')

  const load = useCallback(async (p = 1) => {
    setPosts(null)
    try {
      const params = new URLSearchParams({ sort, page: String(p) })
      if (cat) params.set('category', cat)
      if (dq) params.set('q', dq)
      const d = await apiGet<{ posts: Post[]; pages: number }>(`/api/posts?${params}`)
      setPosts(d.posts); setPages(d.pages); setPage(p)
    } catch { setPosts([]) }
  }, [cat, sort, dq])

  useEffect(() => { load(1) }, [load])

  const createPost = async () => {
    setComposerError('')
    if (newContent.trim().length < 5) { setComposerError('Posts need at least 5 characters.'); return }
    setPosting(true)
    try {
      await apiSend('/api/posts', 'POST', { content: newContent, category: newCat, image: newImage })
      setNewContent(''); setNewImage(null); setNewCat('general'); setComposing(false)
      load(1)
    } catch (e) {
      setComposerError(e instanceof Error ? e.message : 'Failed to post.')
    } finally { setPosting(false) }
  }

  const toggleLike = async (p: Post) => {
    if (!user) { navigate('/signin'); return }
    // optimistic
    setPosts((ps) => (ps || []).map((x) => x.id === p.id ? { ...x, liked: !x.liked, likeCount: x.likeCount + (x.liked ? -1 : 1) } : x))
    try {
      const d = await apiSend<{ liked: boolean; likeCount: number }>(`/api/posts/${p.id}/like`, 'POST')
      setPosts((ps) => (ps || []).map((x) => x.id === p.id ? { ...x, liked: d.liked, likeCount: d.likeCount } : x))
    } catch {
      setPosts((ps) => (ps || []).map((x) => x.id === p.id ? { ...x, liked: p.liked, likeCount: p.likeCount } : x))
    }
  }

  const toggleBookmark = async (p: Post) => {
    if (!user) { navigate('/signin'); return }
    setPosts((ps) => (ps || []).map((x) => x.id === p.id ? { ...x, bookmarked: !x.bookmarked } : x))
    try { await apiSend('/api/bookmarks', 'POST', { kind: 'post', refId: p.id, label: p.content.slice(0, 100) }) }
    catch { setPosts((ps) => (ps || []).map((x) => x.id === p.id ? { ...x, bookmarked: p.bookmarked } : x)) }
  }

  const deletePost = async (p: Post) => {
    if (!window.confirm('Delete this post permanently?')) return
    try { await apiSend(`/api/posts/${p.id}`, 'DELETE'); setPosts((ps) => (ps || []).filter((x) => x.id !== p.id)) } catch { /* silent */ }
  }

  return (
    <div className="view-enter mx-auto max-w-6xl px-4 sm:px-6 py-10 grid lg:grid-cols-[1fr_300px] gap-8">
      {/* main column */}
      <div>
        <span className="badge-soft badge-sage mb-3"><Users className="h-3.5 w-3.5" /> Community</span>
        <h1 className="font-display text-3xl sm:text-4xl font-semibold text-[#2F3625]">Learn out loud, together</h1>
        <p className="mt-2 text-[#55613F] max-w-2xl">
          Share saving tips, ask questions and post learning wins. Educational discussion only — community content is not verified financial advice.
        </p>

        {/* composer */}
        {user ? (
          <div className="card-lux p-4 mt-6">
            {!composing ? (
              <button onClick={() => setComposing(true)} className="w-full text-left px-4 py-3.5 rounded-xl border border-[#E3DEC4] bg-[#FAF6E2] text-sm text-[#6B7052] hover:border-[#B4C18B] transition-colors">
                Share a tip, ask a question, or celebrate a learning win…
              </button>
            ) : (
              <div className="space-y-3">
                <Textarea value={newContent} onChange={(e) => { setNewContent(e.target.value); setComposerError('') }}
                  placeholder="What did you learn or want to discuss? Be specific and kind. Never share OTPs, PINs or personal financial details."
                  className="min-h-28 bg-[#FFFDF2]" maxLength={4000} autoFocus />
                {newImage && (
                  <div className="relative inline-block">
                    <img src={newImage} alt="Attachment preview" className="h-28 rounded-lg border border-[#E3DEC4]" />
                    <button onClick={() => setNewImage(null)} className="absolute -top-2 -right-2 h-6 w-6 rounded-full bg-[#2F3625] text-white flex items-center justify-center" aria-label="Remove image"><X className="h-3.5 w-3.5" /></button>
                  </div>
                )}
                <div className="flex flex-wrap items-center gap-2">
                  <select value={newCat} onChange={(e) => setNewCat(e.target.value)} aria-label="Post category"
                    className="h-9 rounded-md border border-[#E3DEC4] bg-[#FFFDF2] text-sm px-2.5 text-[#3A4229]">
                    {CATEGORIES.map((c) => <option key={c.key} value={c.key}>{c.label}</option>)}
                  </select>
                  <label className="cursor-pointer inline-flex items-center gap-1.5 text-sm font-semibold text-[#55613F] px-3 py-2 rounded-lg hover:bg-[#F2EBD4]">
                    <ImagePlus className="h-4 w-4" /> Image
                    <input type="file" accept="image/png,image/jpeg,image/webp" className="hidden"
                      onChange={async (e) => {
                        const f = e.target.files?.[0]
                        if (!f) return
                        if (f.size > 4 * 1024 * 1024) { setComposerError('Image too large (max 4 MB).'); return }
                        try { setNewImage(await compressImage(f)) } catch { setComposerError('Could not read that image.') }
                      }} />
                  </label>
                  <div className="flex-1" />
                  <Button variant="ghost" onClick={() => { setComposing(false); setComposerError('') }} className="text-[#6B7052]">Cancel</Button>
                  <Button className="btn-bronze font-semibold" onClick={createPost} disabled={posting}>
                    {posting ? 'Posting…' : <><Send className="h-4 w-4 mr-1.5" /> Post</>}
                  </Button>
                </div>
                {composerError && <p className="text-sm text-[#A94438]">{composerError}</p>}
              </div>
            )}
          </div>
        ) : (
          <div className="card-lux p-4 mt-6 bg-[#E9EDC9] border-[#D8DCBB] flex flex-col sm:flex-row items-center justify-between gap-3">
            <p className="text-sm text-[#3A4229]">Sign in to post, like, comment and bookmark.</p>
            <Button className="btn-bronze font-semibold shrink-0" onClick={() => navigate('/signin')}>Sign In to Participate</Button>
          </div>
        )}

        {/* filters */}
        <div className="flex flex-col sm:flex-row gap-3 mt-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-[#8B8F6E]" />
            <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search community posts…" className="pl-9 bg-[#FFFDF2]" aria-label="Search posts" />
          </div>
          <button onClick={() => setSort((s) => (s === 'new' ? 'popular' : 'new'))}
            className="flex items-center gap-2 px-4 py-2 rounded-lg border border-[#E3DEC4] bg-[#FFFDF2] text-sm font-semibold text-[#3A4229] hover:bg-[#F2EBD4] shrink-0">
            <ArrowUpDown className="h-4 w-4" /> {sort === 'new' ? 'Newest first' : 'Most liked'}
          </button>
        </div>
        <div className="flex gap-2 mt-3 overflow-x-auto nice-scroll pb-1">
          <button onClick={() => setCat('')} className={`shrink-0 text-xs font-semibold px-3 py-1.5 rounded-full border ${!cat ? 'btn-bronze' : 'bg-[#FFFDF2] border-[#E3DEC4] text-[#55613F]'}`}>All</button>
          {CATEGORIES.map((c) => (
            <button key={c.key} onClick={() => setCat(cat === c.key ? '' : c.key)}
              className={`shrink-0 text-xs font-semibold px-3 py-1.5 rounded-full border ${cat === c.key ? 'btn-bronze' : 'bg-[#FFFDF2] border-[#E3DEC4] text-[#55613F]'}`}>
              {c.label}
            </button>
          ))}
        </div>

        {/* feed */}
        <div className="mt-6 space-y-5">
          {posts === null ? (
            Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-40 rounded-xl" />)
          ) : posts.length === 0 ? (
            <div className="card-lux p-10 text-center">
              <Users className="h-10 w-10 mx-auto text-[#D8D2B4] mb-3" />
              <p className="font-display text-lg text-[#2F3625]">No posts here yet</p>
              <p className="text-sm text-[#6B7052] mt-1">Be the first to start this conversation.</p>
            </div>
          ) : posts.map((p) => (
            <PostCard key={p.id} post={p} onChanged={load} onDelete={deletePost} onLike={toggleLike} onBookmark={toggleBookmark} canModerate={user?.role === 'ADMIN'} />
          ))}
        </div>

        {pages > 1 && (
          <div className="flex justify-center gap-2 mt-8">
            <Button variant="outline" size="sm" disabled={page <= 1} onClick={() => load(page - 1)} className="border-[#B4C18B]">Previous</Button>
            <span className="text-sm text-[#6B7052] px-3 py-1.5">Page {page} of {pages}</span>
            <Button variant="outline" size="sm" disabled={page >= pages} onClick={() => load(page + 1)} className="border-[#B4C18B]">Next</Button>
          </div>
        )}
      </div>

      {/* sidebar */}
      <aside className="space-y-5 lg:sticky lg:top-24 self-start hidden lg:block">
        <div className="card-lux p-5">
          <h3 className="font-display font-semibold text-[#2F3625] mb-3">House rules</h3>
          <ul className="space-y-2.5 text-xs text-[#55613F] leading-relaxed">
            <li className="flex gap-2"><ShieldCheck className="h-4 w-4 text-[#8F9779] shrink-0" /> Educational discussion only — posts are not verified financial advice.</li>
            <li className="flex gap-2"><CircleAlert className="h-4 w-4 text-[#B08968] shrink-0" /> No impersonation of banks, regulators or officials.</li>
            <li className="flex gap-2"><CircleAlert className="h-4 w-4 text-[#B08968] shrink-0" /> Never post referral links, "guaranteed return" schemes, or requests for OTPs/payments.</li>
            <li className="flex gap-2"><Flag className="h-4 w-4 text-[#8F9779] shrink-0" /> See something off? Report it — moderators review every report.</li>
          </ul>
        </div>
        <div className="card-lux p-5">
          <h3 className="font-display font-semibold text-[#2F3625] mb-3">Categories</h3>
          <div className="space-y-2">
            {CATEGORIES.map((c) => (
              <button key={c.key} onClick={() => setCat(cat === c.key ? '' : c.key)}
                className={`w-full text-left px-3 py-2 rounded-lg text-sm font-medium transition-colors ${cat === c.key ? 'bg-[#CCD5AE] text-[#33401F]' : 'text-[#55613F] hover:bg-[#F2EBD4]'}`}>
                <span className="inline-block h-2 w-2 rounded-full mr-2" style={{ background: c.color }} />{c.label}
              </button>
            ))}
          </div>
        </div>
      </aside>
    </div>
  )
}

// ------------------------------------------------------------------ post card

function PostCard({ post: p, onLike, onBookmark, onDelete, onChanged, canModerate }: {
  post: Post
  onLike: (p: Post) => void
  onBookmark: (p: Post) => void
  onDelete: (p: Post) => void
  onChanged: () => void
  canModerate: boolean
}) {
  const { user } = useApp()
  const [showComments, setShowComments] = useState(false)
  const [commentCount, setCommentCount] = useState(p.commentCount)
  const [comments, setComments] = useState<CommentT[] | null>(null)
  const [commentText, setCommentText] = useState('')
  const [replyTo, setReplyTo] = useState<CommentT | null>(null)
  const [postingComment, setPostingComment] = useState(false)
  const [editing, setEditing] = useState(false)
  const [editText, setEditText] = useState(p.content)
  const [reportOpen, setReportOpen] = useState(false)
  const [reportReason, setReportReason] = useState('spam')

  const loadComments = async () => {
    try {
      const d = await apiGet<{ comments: CommentT[] }>(`/api/posts/${p.id}/comments`)
      setComments(d.comments)
    } catch { setComments([]) }
  }

  useEffect(() => { if (showComments) loadComments() /* eslint-disable-line */ }, [showComments])

  const submitComment = async () => {
    if (!commentText.trim()) return
    setPostingComment(true)
    try {
      await apiSend(`/api/posts/${p.id}/comments`, 'POST', { content: commentText, parentId: replyTo?.id })
      setCommentText('')
      setReplyTo(null)
      setCommentCount((c) => c + 1)
      await loadComments()
    } catch { /* silent */ }
    setPostingComment(false)
  }

  const saveEdit = async () => {
    try {
      await apiSend(`/api/posts/${p.id}`, 'PATCH', { content: editText })
      setEditing(false)
      onChanged()
    } catch { /* silent */ }
  }

  const sendReport = async () => {
    try { await apiSend(`/api/posts/${p.id}/report`, 'POST', { reason: reportReason }) } catch { /* silent */ }
    setReportOpen(false)
  }

  return (
    <article className="card-lux p-5">
      {/* header */}
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-center gap-3 min-w-0">
          <Avatar className="h-10 w-10 border border-[#E3DEC4]">
            <AvatarFallback style={{ background: p.author.avatarColor || '#D4A373' }} className="text-white text-xs font-bold">
              {p.author.name.slice(0, 2).toUpperCase()}
            </AvatarFallback>
          </Avatar>
          <div className="min-w-0">
            <p className="text-sm font-semibold text-[#2F3625] flex items-center gap-1.5">
              {p.author.name}
              {p.author.role === 'ADMIN' && <span className="badge-soft badge-sage !text-[0.6rem] !py-0">Team</span>}
            </p>
            <p className="text-xs text-[#9B9F7E]">{timeAgo(p.createdAt)}{p.edited ? ' · edited' : ''}</p>
          </div>
        </div>
        <span className="badge-soft shrink-0" style={{ borderColor: '#E3DEC4' }}>{catLabel(p.category)}</span>
      </div>

      {/* body */}
      {editing ? (
        <div className="mt-3 space-y-2">
          <Textarea value={editText} onChange={(e) => setEditText(e.target.value)} className="bg-[#FFFDF2] min-h-24" maxLength={4000} />
          <div className="flex gap-2 justify-end">
            <Button size="sm" variant="ghost" onClick={() => { setEditing(false); setEditText(p.content) }}>Cancel</Button>
            <Button size="sm" className="btn-bronze font-semibold" onClick={saveEdit}>Save changes</Button>
          </div>
        </div>
      ) : (
        <p className="mt-3 text-[0.95rem] leading-relaxed text-[#3A4229] whitespace-pre-wrap break-words">{p.content}</p>
      )}

      {p.image && !editing && (
        <img src={p.image} alt="Post attachment" className="mt-3 rounded-xl border border-[#E3DEC4] max-h-96 w-auto" loading="lazy" />
      )}

      {/* actions */}
      <div className="mt-4 pt-3 border-t border-[#F0EBD5] flex items-center gap-1">
        <button onClick={() => onLike(p)} disabled={!user}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-semibold transition-colors ${p.liked ? 'text-[#A94438] bg-[#F7E2DE]' : 'text-[#6B7052] hover:bg-[#F2EBD4] disabled:opacity-50'}`}
          aria-pressed={p.liked} aria-label={`${p.likeCount} likes — like this post`}>
          <Heart className={`h-4 w-4 ${p.liked ? 'fill-current' : ''}`} /> {p.likeCount}
        </button>
        <button onClick={() => setShowComments((s) => !s)}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-semibold text-[#6B7052] hover:bg-[#F2EBD4]"
          aria-expanded={showComments} aria-label={`${commentCount} comments`}>
          <MessageCircle className="h-4 w-4" /> {commentCount}
        </button>
        <button onClick={() => onBookmark(p)} disabled={!user}
          className={`p-2 rounded-lg transition-colors ${p.bookmarked ? 'text-[#B08968]' : 'text-[#6B7052] hover:bg-[#F2EBD4] disabled:opacity-50'}`}
          aria-pressed={p.bookmarked} aria-label="Bookmark post">
          {p.bookmarked ? <BookmarkCheck className="h-4 w-4" /> : <Bookmark className="h-4 w-4" />}
        </button>
        <div className="flex-1" />
        {(p.mine || canModerate) && !editing && (
          <>
            {p.mine && <button onClick={() => setEditing(true)} className="p-2 rounded-lg text-[#6B7052] hover:bg-[#F2EBD4]" aria-label="Edit post"><Pencil className="h-4 w-4" /></button>}
            <button onClick={() => onDelete(p)} className="p-2 rounded-lg text-[#A94438] hover:bg-[#F7E2DE]" aria-label="Delete post"><Trash2 className="h-4 w-4" /></button>
          </>
        )}
        {!p.mine && user && (
          <button onClick={() => setReportOpen(true)} className="p-2 rounded-lg text-[#6B7052] hover:bg-[#F2EBD4]" aria-label="Report post"><Flag className="h-4 w-4" /></button>
        )}
      </div>

      {/* comments */}
      {showComments && (
        <div className="mt-4 pt-4 border-t border-[#F0EBD5] space-y-4">
          {comments === null ? (
            <Skeleton className="h-12 rounded-lg" />
          ) : comments.length === 0 ? (
            <p className="text-sm text-[#9B9F7E]">No comments yet. Start the discussion.</p>
          ) : comments.map((c) => (
            <div key={c.id} className="space-y-2.5">
              <CommentRow c={c} onReply={() => setReplyTo(c)} canDelete={user && (user.id === c.author.id || user.role === 'ADMIN')}
                onDelete={async () => { try { await apiSend(`/api/comments/${c.id}`, 'DELETE'); await loadComments(); setCommentCount((c) => Math.max(0, c - 1)) } catch { /* silent */ } }} />
              {c.replies.map((r) => (
                <div key={r.id} className="ml-8">
                  <CommentRow c={r} onReply={() => setReplyTo(c)} canDelete={user && (user.id === r.author.id || user.role === 'ADMIN')}
                    onDelete={async () => { try { await apiSend(`/api/comments/${r.id}`, 'DELETE'); await loadComments(); setCommentCount((c) => Math.max(0, c - 1)) } catch { /* silent */ } }} />
                </div>
              ))}
            </div>
          ))}

          {user ? (
            <div className="flex items-start gap-2.5">
              <Avatar className="h-8 w-8 shrink-0"><AvatarFallback style={{ background: user.avatarColor }} className="text-white text-[0.65rem] font-bold">{user.name.slice(0, 2).toUpperCase()}</AvatarFallback></Avatar>
              <div className="flex-1">
                {replyTo && (
                  <p className="text-xs text-[#8B8F6E] mb-1 flex items-center gap-2">
                    Replying to <strong>{replyTo.author.name}</strong>
                    <button onClick={() => setReplyTo(null)} className="underline">cancel</button>
                  </p>
                )}
                <div className="flex gap-2">
                  <Input value={commentText} onChange={(e) => setCommentText(e.target.value)}
                    onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); submitComment() } }}
                    placeholder="Write a comment…" className="bg-[#FFFDF2] h-10" maxLength={1000} />
                  <Button size="icon" className="btn-bronze h-10 w-10 rounded-full shrink-0" onClick={submitComment} disabled={postingComment || !commentText.trim()} aria-label="Send comment">
                    <Send className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </div>
          ) : (
            <button onClick={() => navigate('/signin')} className="text-sm link-quiet underline font-semibold">Sign in to join the discussion</button>
          )}
        </div>
      )}

      {/* report dialog */}
      <Dialog open={reportOpen} onOpenChange={setReportOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="font-display text-xl text-[#2F3625]">Report this post</DialogTitle>
            <DialogDescription>Moderators will review it. False reports are also removed — report in good faith.</DialogDescription>
          </DialogHeader>
          <div className="space-y-2.5 pt-1">
            {['spam', 'abuse', 'misinformation', 'impersonation', 'other'].map((r) => (
              <button key={r} onClick={() => setReportReason(r)}
                className={`w-full text-left px-4 py-2.5 rounded-lg border text-sm font-semibold capitalize transition-colors ${reportReason === r ? 'border-[#B08968] bg-[#F6E7D2] text-[#5F4527]' : 'border-[#E3DEC4] bg-[#FFFDF2] text-[#55613F] hover:bg-[#F2EBD4]'}`}>
                {r}
              </button>
            ))}
            <Button className="btn-bronze w-full font-semibold mt-2" onClick={sendReport}>Submit report</Button>
          </div>
        </DialogContent>
      </Dialog>
    </article>
  )
}

function CommentRow({ c, onReply, onDelete, canDelete }: {
  c: { id: string; content: string; createdAt: string; author: Post['author'] }
  onReply: () => void
  onDelete: () => void
  canDelete: boolean
}) {
  return (
    <div className="flex items-start gap-2.5">
      <Avatar className="h-8 w-8 shrink-0">
        <AvatarFallback style={{ background: c.author.avatarColor || '#CCD5AE' }} className="text-white text-[0.65rem] font-bold">{c.author.name.slice(0, 2).toUpperCase()}</AvatarFallback>
      </Avatar>
      <div className="flex-1 bg-[#FAF6E2] border border-[#EFEAD2] rounded-xl px-3.5 py-2.5">
        <div className="flex items-center justify-between gap-2">
          <p className="text-xs font-semibold text-[#2F3625]">{c.author.name}</p>
          <div className="flex items-center gap-1">
            <span className="text-[0.65rem] text-[#9B9F7E]">{timeAgo(c.createdAt)}</span>
            <button onClick={onReply} className="text-[0.65rem] font-semibold link-quiet underline ml-1">reply</button>
            {canDelete && <button onClick={onDelete} className="p-1 rounded hover:bg-[#F7E2DE] text-[#A94438]" aria-label="Delete comment"><Trash2 className="h-3 w-3" /></button>}
          </div>
        </div>
        <p className="text-sm text-[#3A4229] mt-1 whitespace-pre-wrap break-words">{c.content}</p>
      </div>
    </div>
  )
}
