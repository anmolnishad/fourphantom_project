'use client'

import { useEffect, useState } from 'react'
import { navigate, apiGet, apiSend, timeAgo, useDebounced } from './../router'
import { useApp } from './../store'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Skeleton } from '@/components/ui/skeleton'
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog'
import {
  ScanSearch, ShieldAlert, ShieldCheck, ShieldQuestion, Trash2, History, ExternalLink,
  AlertTriangle, ClipboardCopy, Clock, FileWarning, MessageSquareText, Globe2, CreditCard,
  Megaphone, FileText, ArrowRight, X,
} from 'lucide-react'

interface Finding { code: string; title: string; weight: number; evidence: string[]; explanation: string; whatToDo: string }
interface ScanResult {
  riskLabel: 'Low Indicated Risk' | 'Suspicious' | 'High Risk'
  riskScore: number
  findings: Finding[]
  recommendations: string[]
  reportingResources: { name: string; detail: string; url: string }[]
  limitations: string[]
  analysisKind: string
  scannedAt: string
  sanitizedContent: string
  urlsFound: string[]
}

const TYPES = [
  { key: 'message', label: 'Message / SMS', icon: MessageSquareText, ph: 'Paste the suspicious SMS, WhatsApp or email text here…' },
  { key: 'url', label: 'Website URL', icon: Globe2, ph: 'Paste the suspicious link (do not open it)…' },
  { key: 'payment', label: 'Payment request', icon: CreditCard, ph: 'Describe the payment request — amount, UPI handle, what they promised…' },
  { key: 'ad', label: 'Advertisement', icon: Megaphone, ph: 'Paste the ad or investment offer text…' },
  { key: 'description', label: 'My description', icon: FileText, ph: 'Describe what happened in your own words…' },
]

function scoreColor(label: string) {
  if (label === 'High Risk') return { bg: '#F6DAD5', border: '#DCA093', text: '#8C3B31', icon: ShieldAlert }
  if (label === 'Suspicious') return { bg: '#F7ECD4', border: '#DEC491', text: '#7A5A34', icon: ShieldQuestion }
  return { bg: '#E7EDD3', border: '#C3CE9E', text: '#4C5B2E', icon: ShieldCheck }
}

export function Scam() {
  const { user } = useApp()
  const [type, setType] = useState('message')
  const [content, setContent] = useState('')
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const [result, setResult] = useState<ScanResult | null>(null)
  const [showHistory, setShowHistory] = useState(false)
  const [history, setHistory] = useState<HistoryItem[] | null>(null)
  const [reportOpen, setReportOpen] = useState<ScanResult | null>(null)

  const typeObj = TYPES.find((t) => t.key === type)!

  const scan = async () => {
    if (content.trim().length < 5) { setError('Please paste at least a few words to analyse.'); return }
    setBusy(true); setError('')
    try {
      const d = await apiSend<{ result: ScanResult }>('/api/scam/scan', 'POST', { content, inputType: type })
      setResult(d.result)
      setReportOpen(d.result)
      setHistory(null) // invalidate
      setTimeout(() => document.getElementById('scan-result')?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 80)
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Scan failed.')
    } finally {
      setBusy(false)
    }
  }

  const loadHistory = async () => {
    setShowHistory(true)
    if (!user) return
    try {
      const d = await apiGet<{ scans: HistoryItem[] }>('/api/scam/history')
      setHistory(d.scans)
    } catch { setHistory([]) }
  }

  const deleteScan = async (id?: string) => {
    try {
      await apiSend(`/api/scam/history?${id ? `id=${id}` : 'all=1'}`, 'DELETE')
      setHistory((h) => (id ? (h || []).filter((s) => s.id !== id) : []))
    } catch { /* silent */ }
  }

  return (
    <div className="view-enter">
      {/* header */}
      <div className="section-papaya border-b border-[#E8DFC0]">
        <div className="mx-auto max-w-5xl px-4 sm:px-6 py-12 text-center">
          <span className="badge-soft badge-bronze mb-4"><ScanSearch className="h-3.5 w-3.5" /> Scam Detection Center</span>
          <h1 className="font-display text-3xl sm:text-5xl font-semibold text-[#2F3625]">Think Before You Trust.</h1>
          <p className="mt-3 text-[#55613F] max-w-2xl mx-auto leading-relaxed">
            Paste a suspicious message, offer, link or payment request. Our engine checks it against documented scam patterns and returns a transparent risk report — including its limitations.
          </p>
        </div>
      </div>

      <div className="mx-auto max-w-5xl px-4 sm:px-6 py-10 grid gap-8">
        {/* form */}
        <div className="card-lux p-6">
          <div className="flex flex-wrap gap-2 mb-4">
            {TYPES.map((t) => (
              <button key={t.key} onClick={() => setType(t.key)}
                className={`flex items-center gap-1.5 text-xs font-semibold px-3 py-2 rounded-lg border transition-colors ${type === t.key ? 'btn-bronze' : 'bg-[#FFFDF2] border-[#E3DEC4] text-[#55613F] hover:bg-[#F2EBD4]'}`}>
                <t.icon className="h-3.5 w-3.5" /> {t.label}
              </button>
            ))}
          </div>
          <Textarea
            value={content}
            onChange={(e) => { setContent(e.target.value); setError('') }}
            placeholder={typeObj.ph}
            className="min-h-36 bg-[#FFFDF2] text-sm leading-relaxed"
            maxLength={6000}
            aria-label="Content to scan"
          />
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mt-4">
            <p className="text-[0.7rem] text-[#8B8F6E] flex items-start gap-1.5 max-w-md">
              <ShieldCheck className="h-3.5 w-3.5 shrink-0 mt-0.5 text-[#8F9779]" />
              Privacy: never paste real OTPs, PINs, passwords or full card numbers — we mask and never store them, but the safest secret is one never shared.
            </p>
            <div className="flex items-center gap-2">
              {user && (
                <Button variant="outline" onClick={loadHistory} className="border-[#B4C18B] font-semibold">
                  <History className="h-4 w-4 mr-1.5" /> My Scan History
                </Button>
              )}
              <Button className="btn-bronze px-6 font-semibold" onClick={scan} disabled={busy}>
                {busy ? 'Analysing…' : 'Scan Now'}
              </Button>
            </div>
          </div>
          {error && <p className="mt-3 text-sm text-[#A94438] flex items-center gap-1.5"><AlertTriangle className="h-4 w-4" /> {error}</p>}
        </div>

        {/* inline result summary */}
        {result && (
          <div id="scan-result" className="card-lux overflow-hidden">
            <div className="grid sm:grid-cols-[auto_1fr_auto] items-center gap-4 p-6" style={{ background: scoreColor(result.riskLabel).bg }}>
              <span className="h-16 w-16 rounded-2xl border flex items-center justify-center" style={{ borderColor: scoreColor(result.riskLabel).border }}>
                {(() => { const I = scoreColor(result.riskLabel).icon; return <I className="h-8 w-8" style={{ color: scoreColor(result.riskLabel).text }} /> })()}
              </span>
              <div>
                <p className="text-xs font-semibold uppercase tracking-widest" style={{ color: scoreColor(result.riskLabel).text }}>Overall risk classification</p>
                <p className="font-display text-2xl font-semibold" style={{ color: scoreColor(result.riskLabel).text }}>{result.riskLabel}</p>
                <p className="text-xs text-[#6B7052] mt-1">{result.analysisKind}</p>
              </div>
              <div className="text-center">
                <p className="font-display text-3xl font-bold" style={{ color: scoreColor(result.riskLabel).text }}>{result.riskScore}</p>
                <p className="text-[0.65rem] uppercase tracking-wider text-[#6B7052]">risk score /100</p>
              </div>
            </div>
            <div className="p-6 grid sm:grid-cols-2 gap-4 border-t border-[#E3DEC4]">
              <div>
                <p className="text-sm font-semibold text-[#2F3625] mb-2">{result.findings.length} warning sign{result.findings.length === 1 ? '' : 's'} detected</p>
                <ul className="space-y-1.5">
                  {result.findings.slice(0, 4).map((f) => (
                    <li key={f.code} className="text-xs text-[#55613F] flex gap-2"><FileWarning className="h-3.5 w-3.5 mt-0.5 shrink-0 text-[#B08968]" /> {f.title}</li>
                  ))}
                  {result.findings.length === 0 && <li className="text-xs text-[#6B7052]">No documented red-flag patterns matched. Read the limitations — this is not proof of safety.</li>}
                </ul>
                <Button size="sm" className="btn-bronze mt-4 font-semibold" onClick={() => setReportOpen(result)}>View full report <ArrowRight className="h-3.5 w-3.5 ml-1" /></Button>
              </div>
              <div>
                <p className="text-sm font-semibold text-[#2F3625] mb-2">First safety steps</p>
                <ul className="space-y-1.5">
                  {result.recommendations.slice(0, 3).map((r, i) => (
                    <li key={i} className="text-xs text-[#55613F] leading-relaxed">{r}</li>
                  ))}
                </ul>
              </div>
            </div>
            <p className="px-6 py-3 bg-[#F4F0DB] text-[0.68rem] text-[#6B7052] flex items-center gap-2 border-t border-[#E3DEC4]">
              <Clock className="h-3.5 w-3.5" /> Scanned at {new Date(result.scannedAt).toLocaleString('en-IN')} {user ? '· saved to your history' : '· sign in to keep a history'}
            </p>
          </div>
        )}

        {/* education strip */}
        <div className="grid sm:grid-cols-3 gap-4">
          {[
            { t: 'Guaranteed returns', d: 'No genuine investment guarantees high "secure" returns. This single phrase powers most Ponzi schemes.' },
            { t: 'OTP requests', d: 'No bank, wallet or platform ever asks for OTPs, PINs or passwords. Whoever asks is the fraud.' },
            { t: 'Pay-to-receive', d: 'Refunds, prizes and sale proceeds never require you to pay or "verify" first. UPI collect requests send money, not receive it.' },
          ].map((c) => (
            <div key={c.t} className="card-lux p-5">
              <p className="font-display font-semibold text-[#2F3625]">{c.t}</p>
              <p className="text-sm text-[#55613F] mt-1.5 leading-relaxed">{c.d}</p>
            </div>
          ))}
        </div>

        <p className="text-center text-sm text-[#55613F]">
          Want the deep knowledge? Read the <button className="link-quiet underline font-semibold" onClick={() => navigate('/education?cat=cybersecurity')}>Cybersecurity lessons</button> — phishing, OTP scams, fake apps and more.
        </p>
      </div>

      {/* ============ Full report dialog ============ */}
      <Dialog open={!!reportOpen} onOpenChange={(o) => !o && setReportOpen(null)}>
        <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto nice-scroll">
          {reportOpen && (
            <>
              <DialogHeader>
                <DialogTitle className="font-display text-2xl text-[#2F3625]">Scam Analysis Report</DialogTitle>
                <DialogDescription>{reportOpen.analysisKind} · {new Date(reportOpen.scannedAt).toLocaleString('en-IN')}</DialogDescription>
              </DialogHeader>

              <div className="rounded-xl p-4 mt-2" style={{ background: scoreColor(reportOpen.riskLabel).bg, border: `1px solid ${scoreColor(reportOpen.riskLabel).border}` }}>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-[0.65rem] uppercase tracking-widest font-bold" style={{ color: scoreColor(reportOpen.riskLabel).text }}>Risk classification</p>
                    <p className="font-display text-xl font-semibold" style={{ color: scoreColor(reportOpen.riskLabel).text }}>{reportOpen.riskLabel}</p>
                  </div>
                  <div className="text-right">
                    <p className="font-display text-2xl font-bold" style={{ color: scoreColor(reportOpen.riskLabel).text }}>{reportOpen.riskScore}<span className="text-sm font-medium">/100</span></p>
                    <p className="text-[0.6rem] uppercase tracking-wider text-[#6B7052]">documented scoring method v1</p>
                  </div>
                </div>
              </div>

              {/* findings */}
              <section className="mt-2">
                <h3 className="font-display font-semibold text-lg text-[#2F3625] mb-2">1–2 · Detected warning signs & explanations</h3>
                {reportOpen.findings.length === 0 ? (
                  <p className="text-sm text-[#55613F] bg-[#F4F0DB] rounded-lg p-3 leading-relaxed">
                    No documented scam patterns matched this text. <strong>Important:</strong> this is not a safety certificate — new scams constantly evolve, and absence of red flags is not proof of legitimacy.
                  </p>
                ) : (
                  <div className="space-y-3">
                    {reportOpen.findings.map((f) => (
                      <div key={f.code} className="border border-[#E3DEC4] rounded-xl p-4 bg-[#FFFDF2]">
                        <div className="flex items-center justify-between gap-2">
                          <p className="font-semibold text-sm text-[#2F3625]">{f.title}</p>
                          {f.weight > 0 && <span className="badge-bronze shrink-0">+{f.weight} pts</span>}
                        </div>
                        {f.evidence.length > 0 && (
                          <ul className="mt-2 space-y-1">
                            {f.evidence.map((ev, i) => (
                              <li key={i} className="text-xs text-[#6B7052] font-mono bg-[#F4F0DB] rounded px-2 py-1 break-all">matched: “{ev}”</li>
                            ))}
                          </ul>
                        )}
                        <p className="text-sm text-[#4A5236] mt-2 leading-relaxed">{f.explanation}</p>
                        <p className="text-sm text-[#3A4229] mt-2 leading-relaxed bg-[#E9EDC9] rounded-lg p-2.5"><strong>What to do:</strong> {f.whatToDo}</p>
                      </div>
                    ))}
                  </div>
                )}
              </section>

              {/* recommendations */}
              <section className="mt-4">
                <h3 className="font-display font-semibold text-lg text-[#2F3625] mb-2">3 · Recommended safety steps</h3>
                <ol className="space-y-1.5">
                  {reportOpen.recommendations.map((r, i) => (
                    <li key={i} className="text-sm text-[#4A5236] leading-relaxed flex gap-2"><span className="font-bold text-[#8F6B44]">{i + 1}.</span> {r.trim()}</li>
                  ))}
                </ol>
              </section>

              {/* reporting resources */}
              <section className="mt-4">
                <h3 className="font-display font-semibold text-lg text-[#2F3625] mb-2">4 · Official reporting resources</h3>
                <div className="grid sm:grid-cols-2 gap-2">
                  {reportOpen.reportingResources.map((r) => (
                    <a key={r.name} href={r.url} target="_blank" rel="noopener noreferrer" className="flex items-start justify-between gap-2 border border-[#E3DEC4] rounded-lg p-3 bg-[#FFFDF2] hover:bg-[#F6F1DC] transition-colors">
                      <div>
                        <p className="text-sm font-semibold text-[#2F3625]">{r.name}</p>
                        <p className="text-xs text-[#6B7052] leading-snug mt-0.5">{r.detail}</p>
                      </div>
                      <ExternalLink className="h-3.5 w-3.5 mt-1 shrink-0 text-[#B08968]" />
                    </a>
                  ))}
                </div>
              </section>

              {/* limitations */}
              <section className="mt-4">
                <h3 className="font-display font-semibold text-lg text-[#2F3625] mb-2">5 · Limitations of this analysis</h3>
                <ul className="space-y-1.5">
                  {reportOpen.limitations.map((l, i) => (
                    <li key={i} className="text-xs text-[#6B7052] leading-relaxed flex gap-2"><AlertTriangle className="h-3.5 w-3.5 mt-0.5 shrink-0 text-[#B08968]" /> {l}</li>
                  ))}
                </ul>
              </section>
            </>
          )}
        </DialogContent>
      </Dialog>

      {/* ============ History dialog ============ */}
      <Dialog open={showHistory} onOpenChange={setShowHistory}>
        <DialogContent className="max-w-xl max-h-[80vh] overflow-y-auto nice-scroll">
          <DialogHeader>
            <DialogTitle className="font-display text-xl text-[#2F3625] flex items-center gap-2"><History className="h-5 w-5 text-[#8F6B44]" /> My Scan History</DialogTitle>
            <DialogDescription>Only you can see your scans. Delete any record at any time.</DialogDescription>
          </DialogHeader>
          {!user ? (
            <p className="text-sm text-[#55613F]">Sign in to keep a private scan history.</p>
          ) : history === null ? (
            <div className="space-y-2">{Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-16 rounded-lg" />)}</div>
          ) : history.length === 0 ? (
            <p className="text-sm text-[#6B7052] py-6 text-center">No scans yet. Your analysed messages will appear here.</p>
          ) : (
            <div className="space-y-2.5">
              <div className="flex justify-end">
                <Button variant="outline" size="sm" onClick={() => deleteScan()} className="text-[#A94438] border-[#E0B4AE] hover:bg-[#F7E2DE]">
                  <Trash2 className="h-3.5 w-3.5 mr-1" /> Clear all
                </Button>
              </div>
              {history.map((s) => {
                const sc = scoreColor(s.riskLabel)
                return (
                  <div key={s.id} className="border border-[#E3DEC4] rounded-xl p-3.5 bg-[#FFFDF2]">
                    <div className="flex items-start justify-between gap-3">
                      <div className="min-w-0">
                        <div className="flex items-center gap-2">
                          <span className="text-[0.65rem] font-bold px-2 py-0.5 rounded-full" style={{ background: sc.bg, color: sc.text, border: `1px solid ${sc.border}` }}>
                            {s.riskLabel} · {s.riskScore}
                          </span>
                          <span className="text-[0.65rem] text-[#9B9F7E]">{timeAgo(s.createdAt)}</span>
                        </div>
                        <p className="text-xs text-[#55613F] mt-1.5 line-clamp-2 break-words">{s.content}</p>
                      </div>
                      <button onClick={() => deleteScan(s.id)} className="p-1.5 rounded-md hover:bg-[#F7E2DE] text-[#A94438] shrink-0" aria-label="Delete scan record">
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  </div>
                )
              })}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}

interface HistoryItem {
  id: string; inputType: string; content: string; riskLabel: string; riskScore: number
  findingsCount: number; createdAt: string
}
