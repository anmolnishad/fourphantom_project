'use client'

import { useEffect, useState } from 'react'
import { Link, navigate, apiGet } from './../router'
import { useApp } from './../store'
import { Button } from '@/components/ui/button'
import { motion } from 'framer-motion'
import {
  GraduationCap, ScanSearch, Calculator, TrendingUp, ShieldCheck, ArrowRight,
  Leaf, Award, Users, Sparkles, BookOpenCheck, Target, Lock,
} from 'lucide-react'

interface Stats {
  lessons: number; questions: number; resources: number; posts: number
  certificatesIssued: number; calculators: number
}

function GrowthViz() {
  const bars = [22, 30, 26, 38, 44, 40, 52, 60, 56, 68, 78, 88]
  return (
    <div className="relative card-lux p-6 bg-[#FFFDF2]" aria-hidden="true">
      <div className="flex items-center justify-between mb-4">
        <div>
          <p className="text-xs uppercase tracking-widest text-[#8F6B44] font-semibold">Savings growth</p>
          <p className="font-display text-2xl text-[#2F3625]">₹4,80,000</p>
          <p className="text-xs text-[#6B7052]">Illustrative 12-month journey of a ₹40,000/month saver</p>
        </div>
        <span className="badge-bronze"><TrendingUp className="h-3.5 w-3.5" /> +20%</span>
      </div>
      <div className="flex items-end gap-1.5 h-36">
        {bars.map((h, i) => (
          <motion.div
            key={i}
            initial={{ height: 4 }}
            animate={{ height: `${h}%` }}
            transition={{ delay: 0.4 + i * 0.08, duration: 0.7, ease: 'easeOut' }}
            className="flex-1 rounded-t-md"
            style={{ background: i === bars.length - 1 ? '#D4A373' : i % 2 ? '#CCD5AE' : '#B8C68D' }}
          />
        ))}
      </div>
      <svg viewBox="0 0 240 40" className="w-full h-10 mt-1" fill="none">
        <motion.path
          d="M2 36 L 22 32 L 42 33 L 62 28 L 82 24 L 102 26 L 122 20 L 142 15 L 162 17 L 182 11 L 202 6 L 232 2"
          stroke="#8F6B44" strokeWidth="2.5" strokeLinecap="round"
          initial={{ pathLength: 0 }} animate={{ pathLength: 1 }} transition={{ duration: 2.2, delay: 0.8 }}
        />
      </svg>
      <div className="absolute -top-3 -right-3 animate-float">
        <span className="h-12 w-12 rounded-full bg-[#CCD5AE] border border-[#B4C18B] flex items-center justify-center shadow-md">
          <Leaf className="h-6 w-6 text-[#4C5B2E]" />
        </span>
      </div>
    </div>
  )
}

export function Home() {
  const { user } = useApp()
  const [stats, setStats] = useState<Stats | null>(null)

  useEffect(() => {
    apiGet<Stats>('/api/stats').then(setStats).catch(() => setStats(null))
  }, [])

  const fadeIn = {
    initial: { opacity: 0, y: 24 },
    whileInView: { opacity: 1, y: 0 },
    viewport: { once: true, margin: '-60px' },
    transition: { duration: 0.55 },
  }

  return (
    <div className="view-enter">
      {/* ================= HERO ================= */}
      <section className="relative overflow-hidden section-cornsilk">
        <div className="absolute inset-0 pointer-events-none opacity-60" aria-hidden>
          <div className="absolute -top-24 -left-24 h-96 w-96 rounded-full bg-[#E9EDC9] blur-3xl" />
          <div className="absolute top-40 -right-32 h-96 w-96 rounded-full bg-[#FAEDCD] blur-3xl" />
        </div>
        <div className="relative mx-auto max-w-7xl px-4 sm:px-6 pt-14 pb-16 lg:pt-20 lg:pb-24 grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <span className="badge-soft badge-sage mb-5"><Sparkles className="h-3.5 w-3.5" /> Financial education · scam protection · smart tools</span>
            <h1 className="font-display text-4xl sm:text-5xl lg:text-[3.4rem] leading-[1.08] font-semibold text-[#2F3625]">
              Take Control of Your <span className="text-gradient-bronze">Financial Future.</span>
            </h1>
            <p className="mt-5 text-lg leading-relaxed text-[#55613F] max-w-xl">
              Learn smarter money management, identify scams, explore financial tools, and build the confidence to make informed financial decisions.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Button className="btn-bronze h-12 px-6 text-base font-semibold" onClick={() => navigate('/education')}>
                Start Learning <ArrowRight className="ml-1 h-4 w-4" />
              </Button>
              <Button variant="outline" className="h-12 px-6 text-base font-semibold border-[#B4C18B] text-[#3A4229] hover:bg-[#E9EDC9]" onClick={() => navigate('/calculators')}>
                Explore Financial Tools
              </Button>
            </div>
            <div className="mt-8 flex items-center gap-3 text-sm text-[#6B7052]">
              <ShieldCheck className="h-4 w-4 text-[#8F9779]" />
              Education-first · No investment advice · Honest, verified content
            </div>
          </div>

          <div className="lg:pl-6">
            <GrowthViz />
          </div>
        </div>
      </section>

      {/* ================= GENUINE STATS ================= */}
      <section className="section-papaya border-y border-[#E8DFC0]">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 py-10">
          {stats ? (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
              {[
                { n: stats.lessons, label: 'Structured lessons', icon: BookOpenCheck },
                { n: stats.questions, label: 'Quiz questions', icon: Target },
                { n: stats.calculators, label: 'Financial calculators', icon: Calculator },
                { n: stats.resources, label: 'Curated resources', icon: BookOpenCheck },
              ].map((s) => (
                <div key={s.label} className="flex flex-col items-center gap-1">
                  <s.icon className="h-5 w-5 text-[#8F6B44] mb-1" />
                  <p className="font-display text-3xl font-semibold text-[#2F3625]">{s.n > 0 ? `${s.n}+` : s.n}</p>
                  <p className="text-xs font-semibold uppercase tracking-wider text-[#6B7052]">{s.label}</p>
                </div>
              ))}
            </div>
          ) : (
            <div className="h-12" />
          )}
          <p className="mt-6 text-center text-[0.7rem] text-[#8B8F6E] flex items-center justify-center gap-1.5">
            <Lock className="h-3 w-3" /> Figures above are live counts of actual content records in our database. We never display fabricated user or success metrics.
          </p>
        </div>
      </section>

      {/* ================= THREE PILLARS ================= */}
      <section className="mx-auto max-w-7xl px-4 sm:px-6 py-16">
        <motion.div {...fadeIn} className="text-center max-w-2xl mx-auto mb-10">
          <h2 className="font-display text-3xl font-semibold text-[#2F3625]">One platform. Three ways to grow.</h2>
          <p className="mt-3 text-[#55613F]">Everything is designed around a simple loop: learn the concept, practise with tools, protect the result.</p>
        </motion.div>
        <div className="grid gap-6 md:grid-cols-3">
          {[
            {
              icon: GraduationCap, title: 'Financial Learning',
              body: '34 structured lessons across personal finance, investing, banking and cybersecurity — each with examples, key terms, takeaways and a practice quiz.',
              cta: 'Open the Education Center', to: '/education', tone: 'sage',
            },
            {
              icon: ScanSearch, title: 'Scam Protection',
              body: 'Paste any suspicious message, offer or link into our detector. It checks documented fraud patterns and returns a clear, honest risk report with official reporting channels.',
              cta: 'Try the Scam Detector', to: '/scam', tone: 'bronze',
            },
            {
              icon: Calculator, title: 'Smart Money Tools',
              body: 'Eight real calculators — SIP, FD, RD, EMI, compound interest, budget, inflation and savings goal — with charts, breakdowns and downloadable summaries.',
              cta: 'Explore Calculators', to: '/calculators', tone: 'sage',
            },
          ].map((c, i) => (
            <motion.div key={c.title} {...fadeIn} transition={{ ...fadeIn.transition, delay: i * 0.1 }} className="card-lux p-6 flex flex-col">
              <span className={`h-12 w-12 rounded-xl flex items-center justify-center mb-4 ${c.tone === 'sage' ? 'bg-[#CCD5AE] text-[#3A4229]' : 'bg-[#F6E7D2] text-[#7A5A34]'}`}>
                <c.icon className="h-6 w-6" />
              </span>
              <h3 className="font-display text-xl font-semibold text-[#2F3625]">{c.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-[#55613F] flex-1">{c.body}</p>
              <Link to={c.to} className="mt-4 inline-flex items-center gap-1.5 text-sm font-semibold link-quiet">
                {c.cta} <ArrowRight className="h-4 w-4" />
              </Link>
            </motion.div>
          ))}
        </div>
      </section>

      {/* ================= FEATURED PATHS ================= */}
      <section className="section-beige border-y border-[#DDE3C0]">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 py-16 grid md:grid-cols-2 gap-10 items-center">
          <motion.div {...fadeIn}>
            <span className="badge-soft badge-sage mb-4">Learning paths</span>
            <h2 className="font-display text-3xl font-semibold text-[#2F3625]">From first budget to fraud-proof habits</h2>
            <p className="mt-3 text-[#4A5236] leading-relaxed">
              Pick a path and follow it end-to-end. Each lesson ends with key takeaways and related topics, and every category pairs with a quiz that can unlock a certificate.
            </p>
            <ul className="mt-6 space-y-3">
              {[
                ['Personal Finance', 'Budgeting, saving, emergency funds, inflation, goals'],
                ['Investment Education', 'Stocks, mutual funds, SIPs, bonds, risk & diversification'],
                ['Banking Knowledge', 'Accounts, cards, loans, credit scores, statements'],
                ['Cybersecurity', 'Phishing, OTP scams, fake apps, identity protection'],
              ].map(([t, d]) => (
                <li key={t} className="flex gap-3">
                  <span className="mt-1 h-6 w-6 shrink-0 rounded-full bg-[#CCD5AE] flex items-center justify-center"><Leaf className="h-3.5 w-3.5 text-[#4C5B2E]" /></span>
                  <div>
                    <p className="font-semibold text-[#2F3625] text-sm">{t}</p>
                    <p className="text-sm text-[#55613F]">{d}</p>
                  </div>
                </li>
              ))}
            </ul>
            <Button className="btn-bronze mt-7 h-11 px-5 font-semibold" onClick={() => navigate('/education')}>
              Browse all lessons <ArrowRight className="ml-1 h-4 w-4" />
            </Button>
          </motion.div>

          <motion.div {...fadeIn} className="grid gap-4">
            <div className="card-lux p-5 bg-[#FFFDF2]">
              <div className="flex items-center justify-between mb-3">
                <p className="font-display font-semibold">Quiz Challenges</p>
                <span className="badge-bronze">6 categories · 3 levels</span>
              </div>
              <p className="text-sm text-[#55613F]">Timed challenges with instant explanations. Score above the pass mark to unlock verified certificates with QR verification.</p>
              <div className="mt-4 flex flex-wrap gap-2">
                {['Personal Finance', 'Investment', 'Banking', 'Cybersecurity', 'Scam Detection', 'Digital Payments'].map((t) => (
                  <span key={t} className="badge-soft">{t}</span>
                ))}
              </div>
              <Link to="/quiz" className="mt-4 inline-flex items-center gap-1.5 text-sm font-semibold link-quiet">Take a quiz <ArrowRight className="h-4 w-4" /></Link>
            </div>
            <div className="card-lux p-5 bg-[#FFFDF2]">
              <div className="flex items-center gap-2 mb-2">
                <Users className="h-4 w-4 text-[#8F6B44]" />
                <p className="font-display font-semibold">Community</p>
              </div>
              <p className="text-sm text-[#55613F]">Share saving tips, ask questions, post learning wins. Moderated, spam-protected, and strictly education-focused.</p>
              <Link to="/community" className="mt-3 inline-flex items-center gap-1.5 text-sm font-semibold link-quiet">Visit the community <ArrowRight className="h-4 w-4" /></Link>
            </div>
          </motion.div>
        </div>
      </section>

      {/* ================= CERTIFICATE PREVIEW ================= */}
      <section className="mx-auto max-w-7xl px-4 sm:px-6 py-16">
        <motion.div {...fadeIn} className="grid lg:grid-cols-2 gap-10 items-center">
          <div>
            <span className="badge-soft badge-bronze mb-4"><Award className="h-3.5 w-3.5" /> Certification</span>
            <h2 className="font-display text-3xl font-semibold text-[#2F3625]">Earn certificates that mean something</h2>
            <p className="mt-3 text-[#55613F] leading-relaxed">
              Certificates are issued only after you pass the required quiz at the required score — they cannot be downloaded by merely opening a quiz. Each carries a unique ID and QR code linked to a public verification page.
            </p>
            <ul className="mt-5 space-y-2.5 text-sm text-[#4A5236]">
              <li className="flex gap-2"><Award className="h-4 w-4 mt-0.5 text-[#B08968] shrink-0" /> Six certificate tracks, from Financial Literacy Fundamentals to Scam Awareness & Prevention</li>
              <li className="flex gap-2"><ShieldCheck className="h-4 w-4 mt-0.5 text-[#8F9779] shrink-0" /> Downloadable PDF, shareable verification link, revocation supported</li>
              <li className="flex gap-2"><Lock className="h-4 w-4 mt-0.5 text-[#8F9779] shrink-0" /> Clearly labelled platform-issued educational completion certificates</li>
            </ul>
            <div className="mt-7 flex gap-3">
              <Button className="btn-bronze h-11 px-5 font-semibold" onClick={() => navigate('/certificates')}>Visit the Certificate Center</Button>
              {!user && <Button variant="outline" className="h-11 px-5 font-semibold border-[#B4C18B]" onClick={() => navigate('/signup')}>Create free account</Button>}
            </div>
          </div>

          {/* Sample certificate design — clearly marked preview */}
          <motion.div {...fadeIn} className="relative">
            <div className="cert-frame rounded-sm bg-[#FFFDF2] p-8 text-center relative overflow-hidden">
              <div className="absolute inset-3 border border-[#E3DEC4] rounded-sm pointer-events-none" aria-hidden />
              <p className="text-[0.65rem] tracking-[0.35em] uppercase text-[#8F6B44] font-semibold">SAMPLE PREVIEW</p>
              <p className="font-display text-2xl font-semibold mt-3 text-[#2F3625]">Certificate of Completion</p>
              <p className="text-xs text-[#6B7052] mt-1">This certifies that</p>
              <p className="font-display text-3xl mt-2 text-[#8F6B44]">Your Name Here</p>
              <p className="text-xs text-[#6B7052] mt-2">has successfully completed</p>
              <p className="font-display text-lg font-semibold text-[#2F3625]">Financial Literacy Fundamentals</p>
              <div className="mt-5 flex items-center justify-center gap-6 text-[0.6rem] text-[#6B7052]">
                <div className="w-24 border-t border-[#B08968] pt-1">Authorised Issuer</div>
                <div className="text-center">
                  <div className="h-10 w-10 mx-auto bg-[#CCD5AE] rounded border border-[#B4C18B] flex items-center justify-center font-mono text-[0.5rem]">QR</div>
                  <span className="mt-1 block">MH-XXXX-XXXX</span>
                </div>
                <div className="w-24 border-t border-[#B08968] pt-1">Date</div>
              </div>
            </div>
            <p className="text-center text-[0.68rem] text-[#8B8F6E] mt-4">Sample design shown for preview. Real certificates are generated only after verified completion.</p>
          </motion.div>
        </motion.div>
      </section>

      {/* ================= CTA ================= */}
      <section className="section-papaya border-t border-[#E8DFC0]">
        <div className="mx-auto max-w-3xl px-4 py-16 text-center">
          <motion.div {...fadeIn}>
            <h2 className="font-display text-3xl font-semibold text-[#2F3625]">Ready to grow your financial intelligence?</h2>
            <p className="mt-3 text-[#55613F]">Create a free account to track progress, save bookmarks, earn certificates, and join the community.</p>
            <div className="mt-7 flex justify-center gap-3 flex-wrap">
              {user ? (
                <>
                  <Button className="btn-bronze h-12 px-7 font-semibold" onClick={() => navigate('/dashboard')}>Go to My Dashboard</Button>
                  <Button variant="outline" className="h-12 px-7 font-semibold border-[#B4C18B]" onClick={() => navigate('/education')}>Continue Learning</Button>
                </>
              ) : (
                <>
                  <Button className="btn-bronze h-12 px-7 font-semibold" onClick={() => navigate('/signup')}>Get Started — Free Forever</Button>
                  <Button variant="outline" className="h-12 px-7 font-semibold border-[#B4C18B]" onClick={() => navigate('/scam')}>Scan a Suspicious Message</Button>
                </>
              )}
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  )
}
