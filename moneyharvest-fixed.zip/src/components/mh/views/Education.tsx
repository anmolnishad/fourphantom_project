'use client'

import { useEffect, useMemo, useState } from 'react'
import { Link, navigate, apiGet, apiSend, useDebounced } from './../router'
import { useApp } from './../store'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Skeleton } from '@/components/ui/skeleton'
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs'
import {
  ArrowLeft, ArrowRight, Bookmark, BookmarkCheck, CheckCircle2, Circle, Clock,
  BookOpenCheck, ExternalLink, GraduationCap, Lightbulb, ListChecks, Search,
  Wallet, TrendingUp, Landmark, ShieldCheck, Target, Sparkles,
} from 'lucide-react'

const CATS = [
  { key: 'personal-finance', title: 'Personal Finance', icon: Wallet, desc: 'Budgeting, saving, inflation and goals.', color: '#8F9779' },
  { key: 'investment', title: 'Investment Education', icon: TrendingUp, desc: 'Stocks, funds, SIPs, bonds and risk.', color: '#B08968' },
  { key: 'banking', title: 'Banking Knowledge', icon: Landmark, desc: 'Accounts, cards, loans, credit scores.', color: '#8F6B44' },
  { key: 'cybersecurity', title: 'Cybersecurity', icon: ShieldCheck, desc: 'Phishing, OTP scams and protection.', color: '#6B7052' },
]

interface LessonItem {
  id: string; slug: string; category: string; topic: string; title: string
  summary: string; level: string; readMinutes: number; tags: string
}
interface ProgressMap { [slug: string]: { completed: boolean; bookmarked: boolean } }

const iconFor = (cat: string) => CATS.find((c) => c.key === cat)?.icon || BookOpenCheck

// Static icon renderer — avoids dynamic component selection inside render.
function CategoryIcon({ category, className }: { category: string; className?: string }) {
  switch (category) {
    case 'personal-finance': return <Wallet className={className} />
    case 'investment': return <TrendingUp className={className} />
    case 'banking': return <Landmark className={className} />
    case 'cybersecurity': return <ShieldCheck className={className} />
    default: return <BookOpenCheck className={className} />
  }
}

// ============================== HUB ==============================

export function EducationHub({ initialCat }: { initialCat?: string }) {
  const { user } = useApp()
  const [cat, setCat] = useState(initialCat || 'all')
  const [lessons, setLessons] = useState<LessonItem[] | null>(null)
  const [progress, setProgress] = useState<ProgressMap>({})
  const [q, setQ] = useState('')
  const dq = useDebounced(q, 350)

  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect -- reset to skeleton while loading new filter
    setLessons(null)
    apiGet<{ lessons: LessonItem[]; progress: ProgressMap }>(`/api/lessons?${new URLSearchParams({ ...(cat !== 'all' ? { category: cat } : {}), ...(dq ? { q: dq } : {}) }).toString()}`)
      .then((d) => { setLessons(d.lessons); setProgress(d.progress) })
      .catch(() => setLessons([]))
  }, [cat, dq])

  const completedCount = useMemo(() => Object.values(progress).filter((p) => p.completed).length, [progress])

  return (
    <div className="view-enter mx-auto max-w-7xl px-4 sm:px-6 py-10">
      <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-4 mb-8">
        <div>
          <span className="badge-soft badge-sage mb-3"><GraduationCap className="h-3.5 w-3.5" /> Financial Education Center</span>
          <h1 className="font-display text-3xl sm:text-4xl font-semibold text-[#2F3625]">Learn money, lesson by lesson</h1>
          <p className="mt-2 text-[#55613F] max-w-2xl">
            {user ? `You have completed ${completedCount} lesson${completedCount === 1 ? '' : 's'}. ` : ''}
            Every lesson includes real-life examples, key terms, takeaways, related topics, trusted external reading and a practice quiz.
          </p>
        </div>
        <div className="relative w-full lg:w-72">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-[#8B8F6E]" />
          <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search lessons…" className="pl-9 bg-[#FFFDF2]" aria-label="Search lessons" />
        </div>
      </div>

      {/* category cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        {CATS.map((c) => (
          <button key={c.key}
            onClick={() => setCat(cat === c.key ? 'all' : c.key)}
            className={`card-lux p-4 text-left transition-all ${cat === c.key ? 'ring-2 ring-[#B08968] ring-offset-2 ring-offset-[#FEFAE0]' : ''}`}
            aria-pressed={cat === c.key}>
            <span className="h-10 w-10 rounded-lg flex items-center justify-center mb-2" style={{ background: `${c.color}22`, color: c.color }}>
              <c.icon className="h-5 w-5" />
            </span>
            <p className="font-display font-semibold text-[#2F3625] text-sm leading-tight">{c.title}</p>
            <p className="text-xs text-[#6B7052] mt-1 leading-snug">{c.desc}</p>
          </button>
        ))}
      </div>

      {/* lesson grid */}
      {lessons === null ? (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {Array.from({ length: 6 }).map((_, i) => <Skeleton key={i} className="h-48 rounded-xl" />)}
        </div>
      ) : lessons.length === 0 ? (
        <div className="text-center py-16 card-lux">
          <Search className="h-10 w-10 mx-auto text-[#C9C4A4] mb-3" />
          <p className="font-display text-lg text-[#2F3625]">No lessons match your search</p>
          <p className="text-sm text-[#6B7052] mt-1">Try a different keyword or category.</p>
          <Button variant="outline" className="mt-4" onClick={() => { setQ(''); setCat('all') }}>Clear filters</Button>
        </div>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {lessons.map((l) => {
            const Icon = iconFor(l.category)
            const p = progress[l.slug] || { completed: false, bookmarked: false }
            return (
              <Link key={l.slug} to={`/lesson/${l.slug}`} className="card-lux p-5 flex flex-col group">
                <div className="flex items-center justify-between mb-3">
                  <span className="h-9 w-9 rounded-lg bg-[#E9EDC9] flex items-center justify-center text-[#55613F]">
                    <Icon className="h-[18px] w-[18px]" />
                  </span>
                  <div className="flex items-center gap-2">
                    {p.completed && <CheckCircle2 className="h-5 w-5 text-[#8F9779]" aria-label="Completed" />}
                    {p.bookmarked && <BookmarkCheck className="h-4 w-4 text-[#B08968]" aria-label="Bookmarked" />}
                  </div>
                </div>
                <p className="text-[0.68rem] uppercase tracking-widest font-semibold text-[#8F6B44]">{CATS.find((c) => c.key === l.category)?.title}</p>
                <h3 className="font-display font-semibold text-[#2F3625] leading-snug mt-1 group-hover:text-[#6E5133]">{l.title}</h3>
                <p className="text-sm text-[#55613F] mt-2 line-clamp-3 flex-1">{l.summary}</p>
                <div className="mt-4 flex items-center justify-between text-xs text-[#6B7052]">
                  <span className="badge-soft">{l.level}</span>
                  <span className="flex items-center gap-1"><Clock className="h-3.5 w-3.5" /> {l.readMinutes} min read</span>
                </div>
              </Link>
            )
          })}
        </div>
      )}

      {/* quiz cross-link */}
      <div className="mt-12 card-lux p-6 sm:p-8 bg-[#E9EDC9] border-[#D8DCBB] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-start gap-4">
          <span className="h-12 w-12 rounded-xl bg-[#CCD5AE] flex items-center justify-center shrink-0"><Target className="h-6 w-6 text-[#3A4229]" /></span>
          <div>
            <h3 className="font-display text-xl font-semibold text-[#2F3625]">Test what you learned</h3>
            <p className="text-sm text-[#4A5236] mt-1 max-w-xl">Each category pairs with a quiz challenge. Score above the pass mark to unlock a verifiable certificate.</p>
          </div>
        </div>
        <Button className="btn-bronze shrink-0 font-semibold" onClick={() => navigate('/quiz')}>Take a Quiz <ArrowRight className="ml-1 h-4 w-4" /></Button>
      </div>
    </div>
  )
}

// ============================== LESSON DETAIL ==============================

interface LessonContent {
  intro: string
  sections: { heading: string; body: string[] }[]
  example?: { title: string; body: string }
  keyTerms: { term: string; definition: string }[]
  takeaways: string[]
  externalLinks?: { label: string; url: string; source: string }[]
  related: string[]
}
interface LessonFull extends LessonItem { content: LessonContent; progress: { completed: boolean; bookmarked: boolean } }

export function LessonDetail({ slug }: { slug: string }) {
  const { user, refreshUser } = useApp()
  const [lesson, setLesson] = useState<LessonFull | null>(null)
  const [related, setRelated] = useState<{ slug: string; title: string }[]>([])
  const [error, setError] = useState('')
  const [saving, setSaving] = useState('')

  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect -- reset to skeleton while loading new lesson
    setLesson(null)
    apiGet<{ lesson: LessonFull }>(`/api/lessons/${slug}`)
      .then((d) => {
        setLesson(d.lesson)
        const rel: string[] = (d.lesson.content as unknown as { related?: string[] }).related || []
        if (rel.length) {
          apiGet<{ lessons: LessonItem[] }>(`/api/lessons`).then((all) => {
            setRelated(all.lessons.filter((l) => rel.includes(l.slug)).map((l) => ({ slug: l.slug, title: l.title })))
          }).catch(() => {})
        }
      })
      .catch(() => setError('This lesson could not be found.'))
  }, [slug])

  const toggle = async (kind: 'complete' | 'bookmark') => {
    if (!user) { navigate('/signin?next=' + encodeURIComponent(`/lesson/${slug}`)); return }
    setSaving(kind)
    try {
      if (kind === 'complete') {
        const d = await apiSend<{ completed: boolean }>('/api/progress', 'POST', { lessonSlug: slug })
        setLesson((l) => l && { ...l, progress: { ...l.progress, completed: d.completed } })
      } else {
        const d = await apiSend<{ bookmarked: boolean }>('/api/bookmarks', 'POST', { kind: 'lesson', refId: slug, label: lesson?.title })
        setLesson((l) => l && { ...l, progress: { ...l.progress, bookmarked: d.bookmarked } })
      }
    } catch { /* toast-less silent */ }
    setSaving('')
  }

  if (error) {
    return (
      <div className="mx-auto max-w-3xl px-4 py-24 text-center">
        <p className="font-display text-2xl text-[#2F3625]">{error}</p>
        <Button className="btn-bronze mt-6" onClick={() => navigate('/education')}>Back to Education Center</Button>
      </div>
    )
  }
  if (!lesson) {
    return (
      <div className="mx-auto max-w-4xl px-4 py-10 space-y-4">
        <Skeleton className="h-10 w-3/4" /><Skeleton className="h-4 w-full" /><Skeleton className="h-4 w-5/6" />
        <Skeleton className="h-40 w-full rounded-xl" /><Skeleton className="h-40 w-full rounded-xl" />
      </div>
    )
  }

  const Icon = iconFor(lesson.category)

  return (
    <div className="view-enter">
      <div className="section-beige border-b border-[#DDE3C0]">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 py-10">
          <Link to="/education" className="inline-flex items-center gap-1.5 text-sm font-semibold link-quiet mb-5">
            <ArrowLeft className="h-4 w-4" /> Education Center
          </Link>
          <div className="flex items-center gap-3 mb-3">
            <span className="h-11 w-11 rounded-xl bg-[#CCD5AE] flex items-center justify-center"><CategoryIcon category={lesson.category} className="h-[22px] w-[22px] text-[#3A4229]" /></span>
            <div>
              <p className="text-[0.68rem] uppercase tracking-widest font-semibold text-[#8F6B44]">{CATS.find((c) => c.key === lesson.category)?.title} · {lesson.topic}</p>
              <p className="text-xs text-[#6B7052] flex items-center gap-2">{lesson.level} · <Clock className="h-3 w-3" /> {lesson.readMinutes} min read</p>
            </div>
          </div>
          <h1 className="font-display text-3xl sm:text-4xl font-semibold text-[#2F3625] leading-tight">{lesson.title}</h1>
          <p className="mt-3 text-[#4A5236] leading-relaxed">{lesson.summary}</p>

          <div className="mt-6 flex flex-wrap gap-2.5">
            <Button
              onClick={() => toggle('complete')}
              disabled={saving === 'complete'}
              className={lesson.progress?.completed ? 'btn-sage font-semibold' : 'btn-bronze font-semibold'}
            >
              {lesson.progress?.completed ? <CheckCircle2 className="mr-1.5 h-4 w-4" /> : <Circle className="mr-1.5 h-4 w-4" />}
              {lesson.progress?.completed ? 'Completed' : 'Mark as Complete'}
            </Button>
            <Button variant="outline" onClick={() => toggle('bookmark')} disabled={saving === 'bookmark'} className="font-semibold border-[#B4C18B] bg-[#FFFDF2]">
              {lesson.progress?.bookmarked ? <BookmarkCheck className="mr-1.5 h-4 w-4 text-[#B08968]" /> : <Bookmark className="mr-1.5 h-4 w-4" />}
              {lesson.progress?.bookmarked ? 'Bookmarked' : 'Bookmark'}
            </Button>
            <Button variant="outline" onClick={() => navigate(`/quiz?category=${lesson.category === 'investment' ? 'investment-basics' : lesson.category === 'personal-finance' ? 'personal-finance' : lesson.category === 'banking' ? 'banking-awareness' : 'cybersecurity'}`)} className="font-semibold border-[#B4C18B] bg-[#FFFDF2]">
              <Target className="mr-1.5 h-4 w-4" /> Practice Quiz
            </Button>
            {!user && <p className="w-full text-xs text-[#8B8F6E]">Sign in to track completion and bookmarks.</p>}
          </div>
        </div>
      </div>

      <article className="mx-auto max-w-4xl px-4 sm:px-6 py-10">
        {/* intro */}
        <p className="text-lg leading-relaxed text-[#3A4229] border-l-4 border-[#CCD5AE] pl-5 py-1 mb-10">{lesson.content.intro}</p>

        {/* sections */}
        <div className="space-y-8 prose-lesson">
          {lesson.content.sections.map((s, i) => (
            <section key={i}>
              <h2 className="font-display text-2xl font-semibold text-[#2F3625] mb-3 flex items-center gap-2.5">
                <span className="h-7 w-7 rounded-md bg-[#E9EDC9] text-[#55613F] flex items-center justify-center text-sm font-bold font-sans">{i + 1}</span>
                {s.heading}
              </h2>
              {s.body.map((p, j) => <p key={j} className="text-[#4A5236] leading-relaxed">{p}</p>)}
            </section>
          ))}
        </div>

        {/* example */}
        {lesson.content.example && (
          <div className="card-lux p-6 mt-10 bg-[#FAEDCD] border-[#EAD8B6]">
            <p className="flex items-center gap-2 font-display font-semibold text-lg text-[#2F3625] mb-2"><Lightbulb className="h-5 w-5 text-[#B08968]" /> {lesson.content.example.title}</p>
            <p className="text-[#5A5030] leading-relaxed text-[0.95rem]">{lesson.content.example.body}</p>
          </div>
        )}

        {/* key terms */}
        <section className="mt-10">
          <h2 className="font-display text-2xl font-semibold text-[#2F3625] mb-4">Key terms</h2>
          <div className="grid sm:grid-cols-2 gap-3">
            {lesson.content.keyTerms.map((t) => (
              <div key={t.term} className="card-lux p-4">
                <p className="font-semibold text-sm text-[#6E5133]">{t.term}</p>
                <p className="text-sm text-[#55613F] mt-1 leading-relaxed">{t.definition}</p>
              </div>
            ))}
          </div>
        </section>

        {/* takeaways */}
        <section className="mt-10 card-lux p-6 bg-[#E9EDC9] border-[#D8DCBB]">
          <h2 className="font-display text-2xl font-semibold text-[#2F3625] mb-4 flex items-center gap-2"><ListChecks className="h-5 w-5 text-[#4C5B2E]" /> Key takeaways</h2>
          <ul className="space-y-2.5">
            {lesson.content.takeaways.map((t, i) => (
              <li key={i} className="flex gap-2.5 text-[#3A4229] leading-relaxed">
                <Sparkles className="h-4 w-4 mt-1 text-[#8F9779] shrink-0" /> {t}
              </li>
            ))}
          </ul>
        </section>

        {/* external links */}
        {lesson.content.externalLinks && lesson.content.externalLinks.length > 0 && (
          <section className="mt-10">
            <h2 className="font-display text-2xl font-semibold text-[#2F3625] mb-4">Learn further — official sources</h2>
            <div className="space-y-2.5">
              {lesson.content.externalLinks.map((l) => (
                <a key={l.url} href={l.url} target="_blank" rel="noopener noreferrer"
                  className="card-lux p-4 flex items-center justify-between group">
                  <div>
                    <p className="font-semibold text-sm text-[#2F3625] group-hover:text-[#6E5133]">{l.label}</p>
                    <p className="text-xs text-[#6B7052]">{l.source} · opens in a new tab</p>
                  </div>
                  <ExternalLink className="h-4 w-4 text-[#B08968] shrink-0" />
                </a>
              ))}
            </div>
          </section>
        )}

        {/* related */}
        {related.length > 0 && (
          <section className="mt-10">
            <h2 className="font-display text-2xl font-semibold text-[#2F3625] mb-4">Related topics</h2>
            <div className="grid sm:grid-cols-2 gap-3">
              {related.map((r) => (
                <Link key={r.slug} to={`/lesson/${r.slug}`} className="card-lux p-4 flex items-center justify-between group">
                  <p className="font-semibold text-sm text-[#2F3625] group-hover:text-[#6E5133]">{r.title}</p>
                  <ArrowRight className="h-4 w-4 text-[#B08968]" />
                </Link>
              ))}
            </div>
          </section>
        )}
      </article>
    </div>
  )
}
