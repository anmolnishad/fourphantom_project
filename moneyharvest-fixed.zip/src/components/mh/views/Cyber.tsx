'use client'

import { useMemo, useState } from 'react'
import { navigate, apiSend } from './../router'
import { useApp } from './../store'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Progress } from '@/components/ui/progress'
import { Link } from './../router'
import {
  ShieldCheck, KeyRound, Link2Off, Eye, EyeOff, AlertTriangle, CheckCircle2,
  XCircle, Lock, Unlock, Globe2, Info, ScanSearch, Fingerprint, MailWarning,
} from 'lucide-react'

// ---------------------------------------------------------------- password checker (100% local, never transmitted)

interface PwCheck { score: number; label: string; color: string; checks: { ok: boolean; text: string }[] }

function checkPasswordLocal(pw: string): PwCheck {
  const checks = [
    { ok: pw.length >= 12, text: 'At least 12 characters (length beats complexity)' },
    { ok: /[a-z]/.test(pw) && /[A-Z]/.test(pw), text: 'Mixes upper and lower case' },
    { ok: /[0-9]/.test(pw), text: 'Contains a number' },
    { ok: /[^A-Za-z0-9]/.test(pw), text: 'Contains a symbol' },
    { ok: !/(.)\1{2,}/.test(pw), text: 'No triple repeats (aaa, 111)' },
    { ok: !/^(?:password|passwort|qwerty|abc123|letmein|welcome|admin|iloveyou|123456|harvest)/i.test(pw), text: 'Not a common dictionary word or pattern' },
    { ok: !/(19|20)\d{2}|(0[1-9]|[12]\d|3[01])[\/\-](0[1-9]|[12]\d|3[01])/.test(pw), text: 'Avoids obvious years/dates' },
  ]
  const passed = checks.filter((c) => c.ok).length
  const score = Math.round((passed / checks.length) * 100)
  const label = score >= 85 ? 'Very strong' : score >= 60 ? 'Strong' : score >= 40 ? 'Moderate' : pw.length > 0 ? 'Weak' : 'Empty'
  const color = score >= 85 ? '#4C5B2E' : score >= 60 ? '#8F9779' : score >= 40 ? '#D4A373' : '#A94438'
  return { score, label, color, checks }
}

function PasswordChecker() {
  const [pw, setPw] = useState('')
  const [show, setShow] = useState(false)
  const result = useMemo(() => checkPasswordLocal(pw), [pw])
  return (
    <div className="card-lux p-6">
      <div className="flex items-center gap-2.5 mb-1">
        <span className="h-9 w-9 rounded-lg bg-[#E9EDC9] flex items-center justify-center text-[#55613F]"><KeyRound className="h-4.5 w-4.5 h-[18px] w-[18px]" /></span>
        <div>
          <h3 className="font-display font-semibold text-[#2F3625]">Password strength checker</h3>
          <p className="text-[0.68rem] text-[#8F9779] flex items-center gap-1"><Lock className="h-3 w-3" /> Runs 100% locally in your browser — nothing is transmitted or stored.</p>
        </div>
      </div>
      <div className="relative mt-4">
        <Input type={show ? 'text' : 'password'} value={pw} onChange={(e) => setPw(e.target.value)}
          placeholder="Type a test password (not your real one)…" className="pr-10 bg-[#FFFDF2]" aria-label="Password to test" />
        <button onClick={() => setShow((s) => !s)} className="absolute right-3 top-1/2 -translate-y-1/2 text-[#8B8F6E] hover:text-[#55613F]" aria-label={show ? 'Hide password' : 'Show password'}>
          {show ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
        </button>
      </div>
      {pw.length > 0 && (
        <div className="mt-4">
          <div className="flex items-center justify-between text-xs font-semibold mb-1.5">
            <span style={{ color: result.color }}>{result.label}</span>
            <span className="text-[#6B7052]">{result.score}%</span>
          </div>
          <Progress value={result.score} className="h-2 bg-[#E3DEC4] [&>div]:bg-current" style={{ color: result.color }} />
          <ul className="mt-3 space-y-1.5">
            {result.checks.map((c) => (
              <li key={c.text} className={`flex items-center gap-2 text-xs ${c.ok ? 'text-[#4C5B2E]' : 'text-[#8B8F6E]'}`}>
                {c.ok ? <CheckCircle2 className="h-3.5 w-3.5 shrink-0" /> : <XCircle className="h-3.5 w-3.5 shrink-0" />} {c.text}
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  )
}

// ---------------------------------------------------------------- suspicious link explainer (educational, local, never opens links)

function analyseLinkLocal(raw: string): { flags: string[]; verdict: string; tone: 'bad' | 'warn' | 'ok' } {
  const flags: string[] = []
  let candidate = raw.trim()
  if (!candidate) return { flags, verdict: 'Paste a link to inspect it — we analyse the text locally and never open it.', tone: 'ok' }
  try {
    if (!/^https?:\/\//i.test(candidate)) candidate = 'http://' + candidate
    const u = new URL(candidate)
    const host = u.hostname.toLowerCase()
    if (/^\d{1,3}(\.\d{1,3}){3}$/.test(host)) flags.push('Uses a raw IP address instead of a domain — classic phishing infrastructure.')
    if (host.includes('xn--')) flags.push('Punycode characters — can visually imitate real letters (look-alike domain).')
    if (/(bit\.ly|tinyurl|cutt\.ly|is\.gd|t\.co|rb\.gy|shorturl|tiny\.cc|rebrand\.ly|bit\.do)/.test(host)) flags.push('URL shortener — the real destination is hidden. Expand it first via the shortener\u2019s preview feature.')
    if (/\.(xyz|top|icu|club|online|site|website|space|click|link|live|rest|cfd|sbs)(:|\/|$)/.test(host + '/')) flags.push('Uses a TLD frequently abused in phishing campaigns.')
    if (/(sbi|hdfc|icici|axis|kotak|paytm|phonepe|amazon|flipkart|google|facebook|whatsapp|instagram|paypal|bank)/i.test(host) && !/\.(co\.in|org\.in|gov\.in|ac\.in)$/.test(host) && !/^(www\.)?(sbi\.co|onlinesbi\.sbi|hdfcbank\.com|icicibank\.com|axisbank\.com|kotak\.com|paytm\.com|phonepe\.com|amazon\.|flipkart\.|google\.|facebook\.|instagram\.|whatsapp\.|paypal\.)/.test(host)) {
      flags.push(`Contains a famous brand name ("${host}") but the domain doesn\u2019t match the official one — the strongest impersonation signal.`)
    }
    if (host.split('.').length >= 4) flags.push('Very deep subdomain chain — the real domain is the LAST part before the first single-label TLD. Read right-to-left.')
    if (/^(http)(?!s)/.test(candidate) && /(login|verify|account|bank|pay|secure|kyc)/i.test(candidate)) flags.push('Plain non-HTTPS link that asks for account action.')
    if (/(login|verify|update|kyc|secure|account)/i.test(u.pathname + u.search) && /(secure|login|verify|update|kyc)/i.test(host)) flags.push('Both the domain AND the path contain security words — a common scare-structure.')
    if ((host.match(/-/g)?.length || 0) >= 3) flags.push('Excessive hyphens in the domain — typical of throwaway phishing hosts.')
  } catch {
    flags.push('This is not a well-formed URL — treat any malformed link in a financial message as hostile.')
  }
  const tone = flags.length >= 2 ? 'bad' : flags.length === 1 ? 'warn' : 'ok'
  const verdict = flags.length >= 2
    ? 'Multiple warning signs — do NOT open this link. If it claims to be from your bank, open the official app instead.'
    : flags.length === 1
      ? 'One warning sign found — verify carefully before any use, and never enter credentials from a link you received in a message.'
      : 'No structural red flags found. This is NOT proof of safety — always navigate to banks and payment apps via their official app or a bookmarked address.'
  return { flags, verdict, tone }
}

function LinkExplorer() {
  const [raw, setRaw] = useState('')
  const [submitted, setSubmitted] = useState('')
  const res = useMemo(() => analyseLinkLocal(submitted), [submitted])
  return (
    <div className="card-lux p-6">
      <div className="flex items-center gap-2.5 mb-1">
        <span className="h-9 w-9 rounded-lg bg-[#E9EDC9] flex items-center justify-center text-[#55613F]"><Link2Off className="h-[18px] w-[18px]" /></span>
        <div>
          <h3 className="font-display font-semibold text-[#2F3625]">Suspicious link inspector</h3>
          <p className="text-[0.68rem] text-[#8F9779] flex items-center gap-1"><Globe2 className="h-3 w-3" /> Educational text analysis only — we never open, fetch or visit the link you paste.</p>
        </div>
      </div>
      <div className="flex gap-2 mt-4">
        <Input value={raw} onChange={(e) => setRaw(e.target.value)} placeholder="Paste the suspicious link to study its structure…" className="bg-[#FFFDF2]" aria-label="Link to inspect" />
        <Button className="btn-bronze shrink-0 font-semibold" onClick={() => setSubmitted(raw)}>Inspect</Button>
      </div>
      {submitted && (
        <div className={`mt-4 rounded-xl p-4 border ${res.tone === 'bad' ? 'bg-[#F6DAD5] border-[#DCA093]' : res.tone === 'warn' ? 'bg-[#F7ECD4] border-[#DEC491]' : 'bg-[#E7EDD3] border-[#C3CE9E]'}`}>
          <p className={`text-sm font-semibold ${res.tone === 'bad' ? 'text-[#8C3B31]' : res.tone === 'warn' ? 'text-[#7A5A34]' : 'text-[#4C5B2E]'}`}>{res.verdict}</p>
          <ul className="mt-2.5 space-y-1.5">
            {res.flags.map((f, i) => (
              <li key={i} className="text-xs text-[#5A5030] flex gap-2"><AlertTriangle className="h-3.5 w-3.5 mt-0.5 shrink-0 text-[#B08968]" /> {f}</li>
            ))}
          </ul>
          <p className="text-[0.68rem] text-[#8B8F6E] mt-3 flex items-start gap-1.5">
            <Info className="h-3 w-3 mt-0.5 shrink-0" />
            To report a fraudulent link, use Chakshu at sancharsaathi.gov.in — or run it through our <button className="underline font-semibold" onClick={() => navigate('/scam')}>Scam Detector</button> for a full report.
          </p>
        </div>
      )}
    </div>
  )
}

// ---------------------------------------------------------------- interactive scenarios

const SCENARIOS = [
  {
    q: 'Your phone shows "No Service" out of nowhere, and your bank app suddenly needs re-login.',
    options: ['Restart the phone and wait', 'Nothing unusual — networks drop sometimes', 'Possible SIM-swap: call your operator on another phone and freeze bank access'],
    correct: 2,
    why: 'Sudden loss of network plus re-login requests is the classic SIM-swap signature — the fraudster is receiving your OTPs. Speed matters: block the SIM port and freeze accounts.',
  },
  {
    q: 'A WhatsApp message: "RBI refund department: your ₹18,400 government refund is ready. Approve the request to receive it."',
    options: ['Approve — it\u2019s from a government body', 'Approve only the ₹2 verification', 'Delete — refunds never require approvals, and RBI never sends refunds via WhatsApp'],
    correct: 2,
    why: 'Approving a UPI collect request SENDS money. The RBI does not process refunds over WhatsApp, and no genuine refund requires you to approve or pay anything.',
  },
  {
    q: 'A "trading app" shows your ₹10,000 growing to ₹14,200 in 5 days and lets you withdraw ₹1,000 successfully.',
    options: ['It works — invest more before the opportunity closes', 'Test with a bigger deposit to be sure', 'This is the pig-butchering playbook: fake dashboard + bait withdrawal. Stop and verify on SEBI\u2019s registry'],
    correct: 2,
    why: 'The dashboard displays arbitrary numbers; the successful small withdrawal is marketing funded by the scam itself. Verification happens on sebi.gov.in, never inside the app.',
  },
  {
    q: 'An email from "your bank" has a perfect logo, your correct name, and asks you to "verify KYC" via a link before tonight.',
    options: ['The logo looks real — click and log in', 'Reply asking if it\u2019s genuine', 'Don\u2019t click. Open the official app yourself; check the sender\u2019s full address; report via Chakshu'],
    correct: 2,
    why: 'Logos and names are trivially copied from leaked data. The urgency deadline is the manipulation marker. Manual navigation to the official app defeats the entire attack.',
  },
  {
    q: 'A buyer on a marketplace sends a payment screenshot and asks you to dispatch the laptop immediately.',
    options: ['Dispatch — the screenshot looks authentic', 'Ask them to send it again', 'Verify the money in YOUR bank app\u2019s transaction history before dispatching anything'],
    correct: 2,
    why: 'Screenshots are trivially edited or show failed transactions styled as success. The only valid receipt is the credit listed in your own banking app.',
  },
]

function Scenarios() {
  const [picked, setPicked] = useState<Record<number, number>>({})
  const [score] = useState(SCENARIOS.length)
  const answered = Object.keys(picked).length
  const correctCount = SCENARIOS.filter((s, i) => picked[i] === s.correct).length
  return (
    <div className="card-lux p-6">
      <div className="flex items-center gap-2.5 mb-1">
        <span className="h-9 w-9 rounded-lg bg-[#E9EDC9] flex items-center justify-center text-[#55613F]"><Fingerprint className="h-[18px] w-[18px]" /></span>
        <div>
          <h3 className="font-display font-semibold text-[#2F3625]">Interactive scenarios — spot the scam</h3>
          <p className="text-[0.68rem] text-[#8F9779]">{answered}/{SCENARIOS.length} answered · {correctCount} correct (out of {score} scenarios)</p>
        </div>
      </div>
      <div className="mt-5 space-y-5">
        {SCENARIOS.map((s, i) => {
          const p = picked[i]
          return (
            <div key={i} className="border border-[#E3DEC4] rounded-xl p-4 bg-[#FFFDF2]">
              <p className="text-sm font-semibold text-[#2F3625] leading-relaxed">{i + 1}. {s.q}</p>
              <div className="mt-3 space-y-2">
                {s.options.map((o, oi) => {
                  const isPicked = p === oi
                  const isCorrect = oi === s.correct
                  const revealed = p !== undefined
                  return (
                    <button key={oi} disabled={revealed}
                      onClick={() => setPicked((pp) => ({ ...pp, [i]: oi }))}
                      className={`w-full text-left text-sm px-3.5 py-2.5 rounded-lg border transition-all ${
                        revealed && isCorrect ? 'border-[#8F9779] bg-[#E7EDD3] text-[#3A4229] font-semibold' :
                        revealed && isPicked && !isCorrect ? 'border-[#C96B5E] bg-[#F6DAD5] text-[#8C3B31]' :
                        revealed ? 'border-[#E3DEC4] bg-[#FAF6E2] text-[#6B7052]' :
                        isPicked ? 'border-[#B08968] bg-[#F6E7D2] font-semibold' :
                        'border-[#E3DEC4] bg-[#FAF6E2] hover:border-[#CCD5AE]'
                      }`}>
                      {revealed && isCorrect && <CheckCircle2 className="inline h-4 w-4 mr-1.5 -mt-0.5 text-[#4C5B2E]" />}
                      {revealed && isPicked && !isCorrect && <XCircle className="inline h-4 w-4 mr-1.5 -mt-0.5 text-[#8C3B31]" />}
                      {o}
                    </button>
                  )
                })}
              </div>
              {p !== undefined && (
                <p className="mt-3 text-xs text-[#4A5236] bg-[#F4F0DB] rounded-lg p-3 leading-relaxed"><strong>Why:</strong> {s.why}</p>
              )}
            </div>
          )
        })}
      </div>
      {answered === SCENARIOS.length && (
        <div className="mt-5 text-center">
          <p className="font-display text-lg font-semibold text-[#2F3625]">
            You spotted {correctCount} of {SCENARIOS.length} scams.
          </p>
          <p className="text-sm text-[#55613F] mt-1">
            {correctCount === SCENARIOS.length ? 'Excellent instincts. Keep them sharp with the full Cybersecurity quiz.' : 'Review the explanations above — then solidify it with the Cybersecurity quiz.'}
          </p>
          <Button className="btn-bronze mt-4 font-semibold" onClick={() => navigate('/quiz?category=cybersecurity')}>
            <ScanSearch className="h-4 w-4 mr-1.5" /> Take the Cybersecurity Quiz
          </Button>
        </div>
      )}
    </div>
  )
}

// ---------------------------------------------------------------- hub shell

const TOPICS = [
  { t: 'Phishing awareness', d: 'Spot manipulation in messages and emails.', slug: 'phishing-attacks' },
  { t: 'Safe password practices', d: 'Length, uniqueness and managers.', slug: 'password-security' },
  { t: 'Two-factor authentication', d: 'App-based MFA that survives SIM swaps.', slug: 'digital-banking-security' },
  { t: 'UPI safety', d: 'The receive-vs-send rule and QR hygiene.', slug: 'upi-safety' },
  { t: 'Browser security', d: 'Padlock fallacies and safe navigation.', slug: 'fake-websites' },
  { t: 'Social engineering', d: 'The six persuasion levers and your firewalls.', slug: 'social-engineering' },
  { t: 'Identity protection', d: 'How identities are assembled and detected.', slug: 'identity-theft' },
  { t: 'Financial data privacy', d: 'What to share, watermark and refuse.', slug: 'identity-theft' },
  { t: 'Secure online shopping', d: 'Merchant checks and virtual cards.', slug: 'online-payment-safety' },
  { t: 'Fake website identification', d: 'Read domains right-to-left.', slug: 'fake-websites' },
]

export function Cyber() {
  const { user } = useApp()
  return (
    <div className="view-enter">
      <div className="section-papaya border-b border-[#E8DFC0]">
        <div className="mx-auto max-w-6xl px-4 sm:px-6 py-12">
          <span className="badge-soft badge-bronze mb-4"><ShieldCheck className="h-3.5 w-3.5" /> Cybersecurity & Digital Safety Hub</span>
          <h1 className="font-display text-3xl sm:text-5xl font-semibold text-[#2F3625]">Protect the money you’ve worked to build</h1>
          <p className="mt-3 text-[#55613F] max-w-2xl leading-relaxed">
            Ten safety topics, an interactive scam-spotting drill, a fully-local password checker, and a link inspector that explains danger signs without ever visiting the link.
          </p>
          <div className="mt-6 flex flex-wrap gap-2">
            {TOPICS.map((t) => (
              <Link key={t.t} to={`/lesson/${t.slug}`} className="badge-soft badge-sage hover:opacity-80">
                {t.t}
              </Link>
            ))}
          </div>
        </div>
      </div>

      <div className="mx-auto max-w-6xl px-4 sm:px-6 py-10 space-y-8">
        <div className="grid lg:grid-cols-2 gap-8">
          <PasswordChecker />
          <LinkExplorer />
        </div>

        <Scenarios />

        <div className="grid sm:grid-cols-3 gap-4">
          {[
            { icon: KeyRound, t: 'Golden password rule', d: 'Unique password per account + app-based MFA, starting with your email. One leak must never be a master key.' },
            { icon: MailWarning, t: 'Golden OTP rule', d: 'No institution ever asks for OTPs, PINs, passwords or CVV — the person who asks is the fraud.' },
            { icon: AlertTriangle, t: 'Golden hour rule', d: 'If money moves without consent: bank first, then 1930, then cybercrime.gov.in — within 60 minutes.' },
          ].map((c) => (
            <div key={c.t} className="card-lux p-5">
              <c.icon className="h-5 w-5 text-[#B08968] mb-2" />
              <p className="font-display font-semibold text-[#2F3625]">{c.t}</p>
              <p className="text-sm text-[#55613F] mt-1.5 leading-relaxed">{c.d}</p>
            </div>
          ))}
        </div>

        <div className="card-lux p-6 bg-[#E9EDC9] border-[#D8DCBB] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div>
            <h3 className="font-display text-xl font-semibold text-[#2F3625]">Make it official</h3>
            <p className="text-sm text-[#4A5236] mt-1 max-w-xl">Test your knowledge with the Cybersecurity quiz — pass at 70% to unlock the Cybersecurity Awareness certificate{user ? '' : ' (sign in required)'}.</p>
          </div>
          <div className="flex gap-2 shrink-0">
            <Button variant="outline" className="font-semibold border-[#B4C18B] bg-[#FFFDF2]" onClick={() => navigate('/resources?cat=cybersecurity')}>Official resources</Button>
            <Button className="btn-bronze font-semibold" onClick={() => navigate('/quiz?category=cybersecurity')}>Take the quiz</Button>
          </div>
        </div>
      </div>
    </div>
  )
}
