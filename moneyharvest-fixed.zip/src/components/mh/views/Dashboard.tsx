'use client'

import { useEffect, useState } from 'react'
import { navigate, apiGet, apiSend, fmtDate, timeAgo } from './../router'
import { useApp } from './../store'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Skeleton } from '@/components/ui/skeleton'
import { Progress } from '@/components/ui/progress'
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs'
import { Wallet, TrendingUp, Landmark, ShieldCheck } from 'lucide-react'
import {
  LayoutDashboard, Award, Target, ScanSearch, Bookmark, CheckCircle2, Trash2,
  Plus, MessageSquare, BookOpenCheck, Settings, Mail, BadgeCheck,
} from 'lucide-react'

const CAT_LABEL: Record<string, string> = {
  'personal-finance': 'Personal Finance', 'investment': 'Investment Education',
  'banking': 'Banking Knowledge', 'cybersecurity': 'Cybersecurity',
  'investment-basics': 'Investment Basics', 'banking-awareness': 'Banking Awareness',
  'scam-detection': 'Scam Detection', 'digital-payments': 'Digital Payments',
}
const CAT_ICON: Record<string, React.ReactNode> = {
  'personal-finance': <Wallet className="h-4 w-4" />, 'investment': <TrendingUp className="h-4 w-4" />,
  'investment-basics': <TrendingUp className="h-4 w-4" />, 'banking': <Landmark className="h-4 w-4" />,
  'banking-awareness': <Landmark className="h-4 w-4" />, 'cybersecurity': <ShieldCheck className="h-4 w-4" />,
  'scam-detection': <ShieldCheck className="h-4 w-4" />, 'digital-payments': <MessageSquare className="h-4 w-4" />,
}

export function Dashboard() {
  const { user, userLoaded } = useApp()
  const [progress, setProgress] = useState<{ completed: number; bookmarked: number; total: number } | null>(null)
  const [attempts, setAttempts] = useState<AttemptT[] | null>(null)
  const [certs, setCerts] = useState<CertT[] | null>(null)
  const [scans, setScans] = useState<ScanT[] | null>(null)
  const [posts, setPosts] = useState<number | null>(null)
  const [bookmarks, setBookmarks] = useState<BookmarkT[] | null>(null)
  const [goals, setGoals] = useState<GoalT[] | null>(null)
  const [newGoal, setNewGoal] = useState('')
  const [savingGoal, setSavingGoal] = useState(false)

  useEffect(() => {
    if (!user) return
    apiGet<{ lessons: { slug: string; category: string }[]; progress: Record<string, { completed: boolean; bookmarked: boolean }> }>('/api/lessons')
      .then((d) => {
        const vals = Object.values(d.progress)
        setProgress({ completed: vals.filter((v) => v.completed).length, bookmarked: vals.filter((v) => v.bookmarked).length, total: d.lessons.length })
      })
      .catch(() => setProgress({ completed: 0, bookmarked: 0, total: 0 }))
    apiGet<{ attempts: AttemptT[] }>('/api/quiz/attempts').then((d) => setAttempts(d.attempts)).catch(() => setAttempts([]))
    apiGet<{ certificates: CertT[] }>('/api/certificates').then((d) => setCerts(d.certificates)).catch(() => setCerts([]))
    apiGet<{ scans: ScanT[] }>('/api/scam/history').then((d) => setScans(d.scans)).catch(() => setScans([]))
    apiGet<{ bookmarks: BookmarkT[] }>('/api/bookmarks').then((d) => setBookmarks(d.bookmarks)).catch(() => setBookmarks([]))
    apiGet<{ goals: GoalT[] }>('/api/goals').then((d) => setGoals(d.goals)).catch(() => setGoals([]))
    apiGet<{ posts: unknown[] }>('/api/posts?sort=new&page=1').then(() => setPosts(null)).catch(() => setPosts(0))
    // count own posts properly
    apiGet<{ posts: { author: { id: string } }[]; total: number }>('/api/posts?sort=new&page=1').then(() => { /* keep generic */ }).catch(() => {})
  }, [user])

  const addGoal = async () => {
    if (!newGoal.trim()) return
    setSavingGoal(true)
    try {
      await apiSend('/api/goals', 'POST', { title: newGoal })
      setNewGoal('')
      const d = await apiGet<{ goals: GoalT[] }>('/api/goals')
      setGoals(d.goals)
    } catch { /* silent */ }
    setSavingGoal(false)
  }
  const toggleGoal = async (g: GoalT) => {
    try {
      await apiSend('/api/goals', 'PATCH', { id: g.id })
      setGoals((gs) => (gs || []).map((x) => x.id === g.id ? { ...x, done: !x.done } : x))
    } catch { /* silent */ }
  }
  const removeGoal = async (g: GoalT) => {
    try {
      await apiSend(`/api/goals?id=${g.id}`, 'DELETE')
      setGoals((gs) => (gs || []).filter((x) => x.id !== g.id))
    } catch { /* silent */ }
  }

  if (userLoaded && !user) {
    return (
      <div className="mx-auto max-w-xl px-4 py-24 text-center">
        <LayoutDashboard className="h-12 w-12 mx-auto text-[#D8D2B4] mb-4" />
        <h1 className="font-display text-2xl font-semibold text-[#2F3625]">Your dashboard awaits</h1>
        <p className="text-sm text-[#6B7052] mt-2">Sign in to see learning progress, quiz scores, certificates, bookmarks and goals.</p>
        <div className="flex justify-center gap-3 mt-6">
          <Button className="btn-bronze font-semibold" onClick={() => navigate('/signin')}>Sign In</Button>
          <Button variant="outline" className="font-semibold border-[#B4C18B]" onClick={() => navigate('/signup')}>Create account</Button>
        </div>
      </div>
    )
  }
  if (!user) return null

  const bestByCat: Record<string, number> = {}
  for (const a of attempts || []) bestByCat[a.category] = Math.max(bestByCat[a.category] || 0, a.percent)

  return (
    <div className="view-enter mx-auto max-w-6xl px-4 sm:px-6 py-10">
      {/* header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="font-display text-3xl font-semibold text-[#2F3625]">Namaste, {user.name.split(' ')[0]} 🌱</h1>
          <p className="text-sm text-[#6B7052] mt-1 flex items-center gap-2">
            <Mail className="h-3.5 w-3.5" /> {user.email}
            {user.emailVerified ? <span className="badge-soft badge-sage !text-[0.6rem]"><BadgeCheck className="h-3 w-3" /> verified</span>
              : <VerifyButton />}
          </p>
        </div>
        <Button variant="outline" className="font-semibold border-[#B4C18B]" onClick={() => navigate('/settings')}>
          <Settings className="h-4 w-4 mr-1.5" /> Profile & Settings
        </Button>
      </div>

      <Tabs defaultValue="overview" className="w-full">
        <TabsList className="flex-wrap h-auto gap-1 bg-[#E9EDC9] p-1.5 rounded-xl mb-6 justify-start">
          <TabsTrigger value="overview" className="text-xs font-semibold rounded-lg">Overview</TabsTrigger>
          <TabsTrigger value="learning" className="text-xs font-semibold rounded-lg">Learning</TabsTrigger>
          <TabsTrigger value="certificates" className="text-xs font-semibold rounded-lg">Certificates</TabsTrigger>
          <TabsTrigger value="activity" className="text-xs font-semibold rounded-lg">Activity</TabsTrigger>
          <TabsTrigger value="goals" className="text-xs font-semibold rounded-lg">Goals</TabsTrigger>
        </TabsList>

        {/* ============ OVERVIEW ============ */}
        <TabsContent value="overview">
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <StatCard icon={BookOpenCheck} label="Lessons completed" value={progress ? `${progress.completed} / ${progress.total}` : '…'} onClick={() => navigate('/education')} />
            <StatCard icon={Target} label="Quiz attempts" value={attempts ? String(attempts.length) : '…'} onClick={() => navigate('/quiz')} />
            <StatCard icon={Award} label="Certificates" value={certs ? String(certs.filter((c) => !c.revoked).length) : '…'} onClick={() => navigate('/certificates')} />
            <StatCard icon={ScanSearch} label="Scam scans" value={scans ? String(scans.length) : '…'} onClick={() => navigate('/scam')} />
          </div>

          <div className="grid lg:grid-cols-2 gap-5 mt-6">
            {/* progress by category */}
            <div className="card-lux p-6">
              <h3 className="font-display font-semibold text-[#2F3625] mb-4">Learning progress</h3>
              {progress ? (
                <>
                  <div className="flex items-baseline justify-between mb-1.5">
                    <span className="text-sm text-[#55613F]">Overall completion</span>
                    <span className="font-display text-xl font-semibold text-[#2F3625]">{Math.round((progress.completed / Math.max(progress.total, 1)) * 100)}%</span>
                  </div>
                  <Progress value={(progress.completed / Math.max(progress.total, 1)) * 100} className="h-2.5 bg-[#E3DEC4] [&>div]:bg-[#8F9779]" />
                  <p className="text-xs text-[#8B8F6E] mt-2">{progress.completed} of {progress.total} lessons completed · {progress.bookmarked} bookmarked</p>
                  <div className="mt-4 grid grid-cols-2 gap-2">
                    {Object.entries(bestByCat).length === 0 ? (
                      <p className="col-span-2 text-xs text-[#9B9F7E]">No quiz attempts yet — take your first quiz to see category strengths here.</p>
                    ) : Object.entries(bestByCat).map(([c, pct]) => (
                      <div key={c} className="flex items-center gap-2 bg-[#F4F0DB] rounded-lg px-3 py-2">
                        <span className="text-[#55613F]">{CAT_ICON[c]}</span>
                        <div className="min-w-0">
                          <p className="text-[0.68rem] font-semibold text-[#2F3625] truncate">{CAT_LABEL[c] || c}</p>
                          <p className="text-[0.68rem] text-[#6B7052]">best {pct}%</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </>
              ) : <Skeleton className="h-32 rounded-lg" />}
            </div>

            {/* recent certificates */}
            <div className="card-lux p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-display font-semibold text-[#2F3625]">Recent certificates</h3>
                <button onClick={() => navigate('/certificates')} className="text-xs link-quiet underline font-semibold">View all</button>
              </div>
              {certs === null ? <Skeleton className="h-24 rounded-lg" /> : certs.length === 0 ? (
                <div className="text-center py-6">
                  <Award className="h-8 w-8 mx-auto text-[#D8D2B4] mb-2" />
                  <p className="text-sm text-[#6B7052]">No certificates yet. Pass a quiz to unlock your first.</p>
                  <Button size="sm" className="btn-bronze mt-3 font-semibold" onClick={() => navigate('/quiz')}>Take a quiz</Button>
                </div>
              ) : (
                <div className="space-y-2.5">
                  {certs.slice(0, 3).map((c) => (
                    <div key={c.id} className="flex items-center justify-between bg-[#F4F0DB] rounded-lg px-3.5 py-2.5">
                      <div className="flex items-center gap-2.5 min-w-0">
                        <Award className="h-4 w-4 text-[#B08968] shrink-0" />
                        <div className="min-w-0">
                          <p className="text-sm font-semibold text-[#2F3625] truncate">{c.courseTitle}</p>
                          <p className="text-[0.68rem] text-[#6B7052] font-mono">{c.certId} · {fmtDate(c.issuedAt)}</p>
                        </div>
                      </div>
                      <span className={`badge-soft shrink-0 !text-[0.62rem] ${c.revoked ? 'bg-[#F6DAD5] text-[#8C3B31] border-[#DCA093]' : 'badge-sage'}`}>{c.revoked ? 'Revoked' : 'Valid'}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </TabsContent>

        {/* ============ LEARNING ============ */}
        <TabsContent value="learning" className="grid lg:grid-cols-2 gap-5">
          <div className="card-lux p-6">
            <h3 className="font-display font-semibold text-[#2F3625] mb-4">Quiz history</h3>
            {attempts === null ? <Skeleton className="h-40 rounded-lg" /> : attempts.length === 0 ? (
              <p className="text-sm text-[#6B7052] py-6 text-center">No attempts yet.</p>
            ) : (
              <div className="space-y-2 max-h-96 overflow-y-auto nice-scroll">
                {attempts.map((a) => (
                  <div key={a.id} className="flex items-center justify-between bg-[#F4F0DB] rounded-lg px-3.5 py-2.5">
                    <div className="flex items-center gap-2.5">
                      <span className="text-[#55613F]">{CAT_ICON[a.category] || <Target className="h-4 w-4" />}</span>
                      <div>
                        <p className="text-sm font-semibold text-[#2F3625]">{CAT_LABEL[a.category] || a.category}</p>
                        <p className="text-[0.68rem] text-[#6B7052] capitalize">{a.difficulty} · {timeAgo(a.createdAt)}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-bold" style={{ color: a.passed ? '#4C5B2E' : '#A94438' }}>{a.score}/{a.total}</p>
                      <p className="text-[0.65rem] text-[#6B7052]">{a.percent}% {a.passed ? '· passed' : ''}</p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
          <div className="card-lux p-6">
            <h3 className="font-display font-semibold text-[#2F3625] mb-4 flex items-center gap-2"><Bookmark className="h-4 w-4 text-[#B08968]" /> Saved items</h3>
            {bookmarks === null ? <Skeleton className="h-40 rounded-lg" /> : bookmarks.length === 0 ? (
              <p className="text-sm text-[#6B7052] py-6 text-center">Nothing bookmarked yet. Bookmark lessons, resources and posts to find them here.</p>
            ) : (
              <div className="space-y-2 max-h-96 overflow-y-auto nice-scroll">
                {bookmarks.map((b) => (
                  <button key={b.id}
                    onClick={() => b.kind === 'lesson' ? navigate(`/lesson/${b.refId}`) : b.kind === 'post' ? navigate('/community') : navigate('/resources')}
                    className="w-full text-left flex items-center justify-between bg-[#F4F0DB] hover:bg-[#EDE7CC] rounded-lg px-3.5 py-2.5 transition-colors">
                    <div className="min-w-0">
                      <p className="text-sm font-semibold text-[#2F3625] truncate">{b.label || b.refId}</p>
                      <p className="text-[0.65rem] text-[#6B7052] capitalize">{b.kind} · saved {timeAgo(b.createdAt)}</p>
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>
        </TabsContent>

        {/* ============ CERTIFICATES ============ */}
        <TabsContent value="certificates">
          <div className="card-lux p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-display font-semibold text-[#2F3625]">My certificates</h3>
              <Button size="sm" className="btn-bronze font-semibold" onClick={() => navigate('/certificates')}>Certificate Center</Button>
            </div>
            {certs === null ? <Skeleton className="h-40 rounded-lg" /> : certs.length === 0 ? (
              <p className="text-sm text-[#6B7052] py-8 text-center">No certificates yet. Pass a required quiz with the threshold score, then claim your certificate in the Certificate Center.</p>
            ) : (
              <div className="grid sm:grid-cols-2 gap-3">
                {certs.map((c) => (
                  <div key={c.id} className="border border-[#E3DEC4] rounded-xl p-4 flex items-center justify-between gap-3">
                    <div className="min-w-0">
                      <p className="font-semibold text-sm text-[#2F3625] truncate">{c.courseTitle}</p>
                      <p className="text-xs font-mono text-[#6B7052]">{c.certId} · {c.percent}%</p>
                    </div>
                    <Button size="sm" variant="outline" className="shrink-0 border-[#B4C18B] font-semibold" onClick={() => navigate(`/verify/${c.certId}`)}>Verify</Button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </TabsContent>

        {/* ============ ACTIVITY ============ */}
        <TabsContent value="activity" className="grid lg:grid-cols-2 gap-5">
          <div className="card-lux p-6">
            <h3 className="font-display font-semibold text-[#2F3625] mb-4 flex items-center gap-2"><ScanSearch className="h-4 w-4 text-[#B08968]" /> Recent scam scans</h3>
            {scans === null ? <Skeleton className="h-40 rounded-lg" /> : scans.length === 0 ? (
              <p className="text-sm text-[#6B7052] py-6 text-center">No scans yet. Paste a suspicious message in the Scam Detector.</p>
            ) : (
              <div className="space-y-2 max-h-80 overflow-y-auto nice-scroll">
                {scans.slice(0, 10).map((s) => (
                  <div key={s.id} className="bg-[#F4F0DB] rounded-lg px-3.5 py-2.5">
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-[0.65rem] font-bold px-2 py-0.5 rounded-full"
                        style={{ background: s.riskLabel === 'High Risk' ? '#F6DAD5' : s.riskLabel === 'Suspicious' ? '#F7ECD4' : '#E7EDD3', color: s.riskLabel === 'High Risk' ? '#8C3B31' : s.riskLabel === 'Suspicious' ? '#7A5A34' : '#4C5B2E' }}>
                        {s.riskLabel} · {s.riskScore}
                      </span>
                      <span className="text-[0.65rem] text-[#9B9F7E]">{timeAgo(s.createdAt)}</span>
                    </div>
                    <p className="text-xs text-[#55613F] mt-1.5 line-clamp-2">{s.content}</p>
                  </div>
                ))}
              </div>
            )}
          </div>
          <div className="card-lux p-6 flex flex-col items-center justify-center text-center min-h-48">
            <MessageSquare className="h-8 w-8 text-[#D8D2B4] mb-3" />
            <h3 className="font-display font-semibold text-[#2F3625]">Community activity</h3>
            <p className="text-sm text-[#6B7052] mt-1.5 max-w-xs">Your posts, likes and comments live in the community feed.</p>
            <Button size="sm" className="btn-bronze mt-4 font-semibold" onClick={() => navigate('/community')}>Open Community</Button>
          </div>
        </TabsContent>

        {/* ============ GOALS ============ */}
        <TabsContent value="goals">
          <div className="card-lux p-6 max-w-2xl">
            <h3 className="font-display font-semibold text-[#2F3625] mb-1">Personal learning goals</h3>
            <p className="text-xs text-[#6B7052] mb-4">Small, named goals beat vague intentions. Example: “Finish all Investment lessons by Sunday”.</p>
            <div className="flex gap-2 mb-5">
              <Input value={newGoal} onChange={(e) => setNewGoal(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && addGoal()}
                placeholder="Add a learning goal…" className="bg-[#FFFDF2]" maxLength={120} />
              <Button className="btn-bronze font-semibold shrink-0" onClick={addGoal} disabled={savingGoal || !newGoal.trim()}>
                <Plus className="h-4 w-4 mr-1" /> Add
              </Button>
            </div>
            {goals === null ? <Skeleton className="h-24 rounded-lg" /> : goals.length === 0 ? (
              <p className="text-sm text-[#6B7052] py-6 text-center">No goals yet — add your first one above.</p>
            ) : (
              <div className="space-y-2">
                {goals.map((g) => (
                  <div key={g.id} className="flex items-center gap-3 bg-[#F4F0DB] rounded-lg px-3.5 py-2.5">
                    <button onClick={() => toggleGoal(g)} aria-label={g.done ? 'Mark incomplete' : 'Mark complete'}
                      className={`h-5 w-5 rounded-full border-2 flex items-center justify-center shrink-0 ${g.done ? 'border-[#8F9779] bg-[#CCD5AE]' : 'border-[#B4AC8B]'}`}>
                      {g.done && <CheckCircle2 className="h-3.5 w-3.5 text-[#3A4229]" />}
                    </button>
                    <p className={`flex-1 text-sm ${g.done ? 'line-through text-[#9B9F7E]' : 'text-[#2F3625] font-medium'}`}>{g.title}</p>
                    <button onClick={() => removeGoal(g)} className="p-1.5 rounded-md hover:bg-[#F7E2DE] text-[#A94438]" aria-label="Delete goal">
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}

function VerifyButton() {
  const [state, setState] = useState<'idle' | 'busy' | 'done'>('idle')
  const verify = async () => {
    setState('busy')
    try { await apiSend('/api/auth/verify', 'POST'); setState('done') } catch { setState('idle') }
  }
  if (state === 'done') return <span className="badge-soft badge-sage !text-[0.6rem]"><BadgeCheck className="h-3 w-3" /> verified</span>
  return (
    <button onClick={verify} className="text-[0.65rem] font-semibold link-quiet underline" disabled={state === 'busy'}>
      {state === 'busy' ? 'verifying…' : 'verify email (dev mode)'}
    </button>
  )
}

function StatCard({ icon: Icon, label, value, onClick }: { icon: React.ComponentType<{ className?: string }>; label: string; value: string; onClick: () => void }) {
  return (
    <button onClick={onClick} className="card-lux p-5 text-left hover:-translate-y-0.5 transition-transform">
      <Icon className="h-5 w-5 text-[#B08968] mb-2.5" />
      <p className="font-display text-2xl font-semibold text-[#2F3625]">{value}</p>
      <p className="text-xs font-semibold uppercase tracking-wider text-[#6B7052] mt-0.5">{label}</p>
    </button>
  )
}

interface AttemptT { id: string; category: string; difficulty: string; score: number; total: number; percent: number; passed: boolean; createdAt: string }
interface CertT { id: string; certId: string; courseTitle: string; percent: number; issuedAt: string; revoked: boolean }
interface ScanT { id: string; content: string; riskLabel: string; riskScore: number; createdAt: string }
interface BookmarkT { id: string; kind: string; refId: string; label: string; createdAt: string }
interface GoalT { id: string; title: string; done: boolean; createdAt: string }
