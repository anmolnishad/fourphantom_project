'use client'

import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { navigate, apiGet, apiSend, useRoute } from './../router'
import { useApp } from './../store'
import { Button } from '@/components/ui/button'
import { Progress } from '@/components/ui/progress'
import { Skeleton } from '@/components/ui/skeleton'
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs'
import {
  Target, Timer, ChevronLeft, ChevronRight, CheckCircle2, XCircle, RotateCcw,
  Flag, Award, ArrowRight, AlertCircle, Zap,
} from 'lucide-react'

const QUIZ_CATS = [
  { key: 'personal-finance', title: 'Personal Finance', icon: Target, desc: 'Budgeting, saving, inflation, goals.' },
  { key: 'investment-basics', title: 'Investment Basics', icon: Zap, desc: 'Stocks, funds, SIPs, risk.' },
  { key: 'banking-awareness', title: 'Banking Awareness', icon: Flag, desc: 'Cards, loans, scores, statements.' },
  { key: 'cybersecurity', title: 'Cybersecurity', icon: Shield, desc: 'Phishing, passwords, MFA.' },
  { key: 'scam-detection', title: 'Scam Detection', icon: Eye, desc: 'Fraud patterns & reporting.' },
  { key: 'digital-payments', title: 'Digital Payments', icon: Smart, desc: 'UPI, safety, disputes.' },
]

// small local icon shims to keep import list tidy
function Shield(props: React.SVGProps<SVGSVGElement>) { return <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" {...props}><path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z" /></svg> }
function Eye(props: React.SVGProps<SVGSVGElement>) { return <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" {...props}><path d="M2.062 12.348a1 1 0 0 1 0-.696 10.75 10.75 0 0 1 19.876 0 1 1 0 0 1 0 .696 10.75 10.75 0 0 1-19.876 0" /><circle cx="12" cy="12" r="3" /></svg> }
function Smart(props: React.SVGProps<SVGSVGElement>) { return <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" {...props}><rect width="14" height="20" x="5" y="2" rx="2" /><path d="M12 18h.01" /></svg> }

interface Q { id: string; index: number; category: string; difficulty: string; question: string; options: string[] }
interface Detail { questionId: string; question: string; options: string[]; chosen: number; correctIndex: number; correct: boolean; explanation: string }
interface QuizResult { score: number; total: number; percent: number; passed: boolean; details: Detail[]; saved: boolean; note?: string }

const DIFFS = [
  { key: 'beginner', label: 'Beginner' },
  { key: 'intermediate', label: 'Intermediate' },
  { key: 'advanced', label: 'Advanced' },
]

export function Quiz() {
  const route = useRoute()
  const { user } = useApp()
  const [stage, setStage] = useState<'setup' | 'run' | 'result'>(route.query.get('category') ? 'setup' : 'setup')
  const [cat, setCat] = useState(route.query.get('category') || 'personal-finance')
  const [diff, setDiff] = useState('beginner')
  const [timed, setTimed] = useState(true)
  const [questions, setQuestions] = useState<Q[] | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  const [answers, setAnswers] = useState<Record<string, number>>({})
  const [cur, setCur] = useState(0)
  const [secondsLeft, setSecondsLeft] = useState(0)
  const [elapsed, setElapsed] = useState(0)
  const [submitting, setSubmitting] = useState(false)
  const [result, setResult] = useState<QuizResult | null>(null)
  const [reviewOpen, setReviewOpen] = useState(false)
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null)

  const start = async () => {
    setLoading(true); setError(''); setResult(null); setAnswers({}); setCur(0)
    try {
      const d = await apiGet<{ questions: Q[] }>(`/api/quiz/questions?category=${cat}&difficulty=${diff}&count=10`)
      if (!d.questions.length) throw new Error('No questions available for this selection. Try another category or level.')
      setQuestions(d.questions)
      setSecondsLeft(d.questions.length * 60)
      setElapsed(0)
      setStage('run')
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Could not load quiz.')
    } finally {
      setLoading(false)
    }
  }

  const submit = useCallback(async () => {
    if (!questions || submitting) return
    const unanswered = questions.filter((q) => answers[q.id] === undefined).length
    if (unanswered > 0 && !window.confirm(`${unanswered} question${unanswered > 1 ? 's are' : ' is'} unanswered. Submit anyway?`)) return
    setSubmitting(true)
    if (timerRef.current) clearInterval(timerRef.current)
    try {
      const payload = {
        category: cat,
        difficulty: diff,
        timeTakenSec: elapsed,
        answers: questions.map((q) => ({ questionId: q.id, chosen: answers[q.id] ?? -1 })),
      }
      const d = await apiSend<QuizResult>('/api/quiz/submit', 'POST', payload)
      setResult(d)
      setStage('result')
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Submission failed.')
      if (timerRef.current) timerRef.current = setInterval(() => setElapsed((s) => s + 1), 1000)
    } finally {
      setSubmitting(false)
    }
  }, [questions, answers, cat, diff, elapsed, submitting])

  // timer
  useEffect(() => {
    if (stage !== 'run') return
    timerRef.current = setInterval(() => {
      setElapsed((s) => s + 1)
      if (timed) setSecondsLeft((s) => {
        if (s <= 1) {
          clearInterval(timerRef.current!)
          void submit()
          return 0
        }
        return s - 1
      })
    }, 1000)
    return () => { if (timerRef.current) clearInterval(timerRef.current) }
  }, [stage, timed, submit])

  const q = questions?.[cur]
  const answeredCount = questions ? questions.filter((qq) => answers[qq.id] !== undefined).length : 0
  const catMeta = QUIZ_CATS.find((c) => c.key === cat)

  // ================= SETUP =================
  if (stage === 'setup') {
    return (
      <div className="view-enter mx-auto max-w-5xl px-4 sm:px-6 py-10">
        <span className="badge-soft badge-sage mb-3"><Target className="h-3.5 w-3.5" /> Quiz & Learning Challenges</span>
        <h1 className="font-display text-3xl sm:text-4xl font-semibold text-[#2F3625]">Test your financial intelligence</h1>
        <p className="mt-2 text-[#55613F] max-w-2xl">
          Ten questions per run, drawn randomly from our verified question bank. Answers are graded on the server; pass at 60% to record an attempt, and at each certificate’s threshold to unlock it.
        </p>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4 mt-8">
          {QUIZ_CATS.map((c) => (
            <button key={c.key} onClick={() => setCat(c.key)}
              className={`card-lux p-5 text-left transition-all ${cat === c.key ? 'ring-2 ring-[#B08968] ring-offset-2 ring-offset-[#FEFAE0]' : ''}`}>
              <span className="h-10 w-10 rounded-lg bg-[#E9EDC9] flex items-center justify-center text-[#55613F] mb-2.5"><c.icon className="h-5 w-5" /></span>
              <p className="font-display font-semibold text-[#2F3625]">{c.title}</p>
              <p className="text-xs text-[#6B7052] mt-1">{c.desc}</p>
            </button>
          ))}
        </div>

        <div className="card-lux p-6 mt-6 grid md:grid-cols-3 gap-6 items-end">
          <div>
            <p className="text-xs font-semibold uppercase tracking-wider text-[#6B7052] mb-2">Difficulty</p>
            <Tabs value={diff} onValueChange={setDiff}>
              <TabsList className="bg-[#E9EDC9]">
                {DIFFS.map((d) => <TabsTrigger key={d.key} value={d.key} className="text-xs font-semibold">{d.label}</TabsTrigger>)}
              </TabsList>
            </Tabs>
          </div>
          <div>
            <p className="text-xs font-semibold uppercase tracking-wider text-[#6B7052] mb-2">Timer</p>
            <button onClick={() => setTimed((t) => !t)}
              className={`text-sm font-semibold px-4 py-2.5 rounded-lg border transition-colors ${timed ? 'btn-sage' : 'bg-[#FFFDF2] border-[#E3DEC4] text-[#55613F]'}`}>
              {timed ? 'Timed — 1 min / question' : 'Untimed (practice mode)'}
            </button>
          </div>
          <div className="flex flex-col gap-2">
            <Button className="btn-bronze h-11 font-semibold" onClick={start} disabled={loading}>
              {loading ? 'Preparing questions…' : `Start ${catMeta?.title} Quiz`}
            </Button>
            {user && (
              <Button variant="ghost" className="text-[#55613F] text-sm" onClick={() => navigate('/dashboard')}>View my past attempts</Button>
            )}
          </div>
        </div>

        {error && <p className="mt-4 text-sm text-[#A94438] flex items-center gap-2"><AlertCircle className="h-4 w-4" /> {error}</p>}
        {!user && (
          <p className="mt-6 text-sm text-[#8B8F6E] bg-[#F4F0DB] rounded-lg p-3.5">
            You can take quizzes without an account, but attempts are saved (and certificates unlocked) only when signed in.
          </p>
        )}
      </div>
    )
  }

  // ================= RUN =================
  if (stage === 'run' && q) {
    const chosen = answers[q.id]
    return (
      <div className="view-enter mx-auto max-w-3xl px-4 sm:px-6 py-10">
        {/* status bar */}
        <div className="flex items-center justify-between gap-4 mb-4">
          <div className="flex items-center gap-3">
            <span className="badge-soft">{catMeta?.title}</span>
            <span className="badge-soft capitalize">{diff}</span>
          </div>
          {timed ? (
            <span className={`flex items-center gap-1.5 text-sm font-bold font-mono px-3 py-1.5 rounded-lg ${secondsLeft < 60 ? 'bg-[#F6DAD5] text-[#8C3B31] animate-pulse' : 'bg-[#E9EDC9] text-[#3A4229]'}`}>
              <Timer className="h-4 w-4" /> {Math.floor(secondsLeft / 60)}:{String(secondsLeft % 60).padStart(2, '0')}
            </span>
          ) : (
            <span className="text-sm text-[#6B7052] font-mono">{Math.floor(elapsed / 60)}:{String(elapsed % 60).padStart(2, '0')}</span>
          )}
        </div>

        <div className="flex items-center gap-3 mb-6">
          <Progress value={(answeredCount / questions!.length) * 100} className="h-2 bg-[#E3DEC4] [&>div]:bg-[#B08968]" />
          <span className="text-xs font-semibold text-[#6B7052] shrink-0">{cur + 1} / {questions!.length}</span>
        </div>

        {/* question card */}
        <div className="card-lux p-6 sm:p-8">
          <p className="text-xs font-semibold uppercase tracking-widest text-[#8F6B44] mb-3">Question {cur + 1}</p>
          <h2 className="font-display text-xl sm:text-2xl font-semibold text-[#2F3625] leading-snug">{q.question}</h2>
          <div className="mt-6 space-y-2.5">
            {q.options.map((opt, i) => {
              const selected = chosen === i
              return (
                <button key={i}
                  onClick={() => setAnswers((a) => ({ ...a, [q.id]: i }))}
                  className={`w-full text-left px-4 py-3.5 rounded-xl border text-[0.95rem] transition-all flex items-center gap-3 ${
                    selected ? 'border-[#B08968] bg-[#F6E7D2] text-[#5F4527] font-semibold shadow-sm' : 'border-[#E3DEC4] bg-[#FFFDF2] text-[#3A4229] hover:border-[#CCD5AE] hover:bg-[#F6F1DC]'
                  }`}>
                  <span className={`h-7 w-7 rounded-full border flex items-center justify-center text-xs font-bold shrink-0 ${selected ? 'border-[#B08968] bg-[#D4A373] text-white' : 'border-[#D8D2B4] text-[#6B7052]'}`}>
                    {String.fromCharCode(65 + i)}
                  </span>
                  {opt}
                </button>
              )
            })}
          </div>
        </div>

        {/* nav */}
        <div className="flex items-center justify-between mt-6">
          <Button variant="outline" onClick={() => setCur((c) => Math.max(0, c - 1))} disabled={cur === 0} className="border-[#B4C18B] font-semibold">
            <ChevronLeft className="h-4 w-4 mr-1" /> Previous
          </Button>
          {/* question dots */}
          <div className="hidden sm:flex gap-1.5">
            {questions!.map((qq, i) => (
              <button key={qq.id} onClick={() => setCur(i)} aria-label={`Go to question ${i + 1}`}
                className={`h-2.5 w-2.5 rounded-full transition-colors ${i === cur ? 'bg-[#8F6B44] scale-125' : answers[qq.id] !== undefined ? 'bg-[#CCD5AE]' : 'bg-[#E3DEC4]'}`} />
            ))}
          </div>
          {cur < questions!.length - 1 ? (
            <Button className="btn-bronze font-semibold" onClick={() => setCur((c) => c + 1)}>Next <ChevronRight className="h-4 w-4 ml-1" /></Button>
          ) : (
            <Button className="btn-bronze font-semibold" onClick={submit} disabled={submitting}>{submitting ? 'Grading…' : 'Submit Quiz'}</Button>
          )}
        </div>
        {error && <p className="mt-4 text-sm text-[#A94438]">{error}</p>}
      </div>
    )
  }

  // ================= RESULT =================
  if (stage === 'result' && result) {
    const passTone = result.passed
    return (
      <div className="view-enter mx-auto max-w-3xl px-4 sm:px-6 py-10">
        <div className={`card-lux p-8 text-center ${passTone ? 'bg-[#E9EDC9] border-[#C6CFA4]' : 'bg-[#F6DAD5] border-[#DCA093]'}`}>
          <span className={`h-20 w-20 rounded-full mx-auto flex items-center justify-center ${passTone ? 'bg-[#CCD5AE]' : 'bg-[#E8B8B0]'}`}>
            {passTone ? <CheckCircle2 className="h-10 w-10 text-[#3A4229]" /> : <XCircle className="h-10 w-10 text-[#8C3B31]" />}
          </span>
          <h1 className="font-display text-3xl font-semibold text-[#2F3625] mt-4">{result.score} / {result.total} correct</h1>
          <p className="text-lg font-semibold mt-1" style={{ color: passTone ? '#4C5B2E' : '#8C3B31' }}>{result.percent}% · {result.passed ? 'Passed' : 'Not passed (60% to pass)'}</p>
          <p className="text-sm text-[#55613F] mt-2 max-w-md mx-auto">
            {result.saved
              ? result.passed
                ? 'Attempt recorded. If this meets a certificate threshold, visit the Certificate Center to claim it.'
                : 'Attempt recorded. Review the explanations below and try again — repetition builds retention.'
              : (result.note || 'Sign in to save attempts and unlock certificates.')}
          </p>
          <div className="mt-6 flex justify-center gap-3 flex-wrap">
            <Button variant="outline" className="font-semibold border-[#B4C18B]" onClick={() => setReviewOpen((o) => !o)}>
              {reviewOpen ? 'Hide answer review' : `Review answers (${result.details.filter((d) => !d.correct).length} incorrect)`}
            </Button>
            <Button className="btn-bronze font-semibold" onClick={start}><RotateCcw className="h-4 w-4 mr-1.5" /> Retake</Button>
            {result.passed && (
              <Button variant="outline" className="font-semibold border-[#B4C18B] bg-[#FFFDF2]" onClick={() => navigate('/certificates')}>
                <Award className="h-4 w-4 mr-1.5" /> Certificate Center
              </Button>
            )}
          </div>
        </div>

        {reviewOpen && (
          <div className="mt-6 space-y-4">
            {result.details.map((d, i) => (
              <div key={d.questionId} className={`card-lux p-5 ${d.correct ? 'border-l-4 border-l-[#8F9779]' : 'border-l-4 border-l-[#C96B5E]'}`}>
                <div className="flex items-start gap-2.5">
                  {d.correct ? <CheckCircle2 className="h-5 w-5 text-[#8F9779] shrink-0 mt-0.5" /> : <XCircle className="h-5 w-5 text-[#C96B5E] shrink-0 mt-0.5" />}
                  <div className="min-w-0">
                    <p className="font-semibold text-[#2F3625]">{i + 1}. {d.question}</p>
                    <p className="text-sm mt-1.5 text-[#55613F]">
                      Your answer: <span className={d.correct ? 'font-semibold text-[#4C5B2E]' : 'font-semibold text-[#8C3B31]'}>
                        {d.chosen >= 0 ? d.options[d.chosen] : 'Skipped'}
                      </span>
                      {!d.correct && d.correctIndex >= 0 && <> · Correct: <span className="font-semibold text-[#4C5B2E]">{d.options[d.correctIndex]}</span></>}
                    </p>
                    <p className="text-sm text-[#4A5236] bg-[#F4F0DB] rounded-lg p-3 mt-2.5 leading-relaxed"><strong>Why:</strong> {d.explanation}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    )
  }

  // loading state
  return (
    <div className="mx-auto max-w-3xl px-4 py-10 space-y-4">
      <Skeleton className="h-8 w-1/2" /><Skeleton className="h-40 rounded-xl" />
      <div className="space-y-2.5">{Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-14 rounded-xl" />)}</div>
    </div>
  )
}
