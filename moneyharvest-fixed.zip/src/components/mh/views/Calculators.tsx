'use client'

import { useEffect, useMemo, useState } from 'react'
import { navigate, fmtINR, fmtCompact, downloadJson, useRoute } from './../router'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Slider } from '@/components/ui/slider'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { calculatorRegistry, calcSip, calcFd, calcRd, calcCompound, calcEmi, calcBudget, calcInflation, calcSavingsGoal } from '@/lib/calculators'
import {
  AreaChart, Area, BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid,
  Tooltip, ResponsiveContainer, Legend,
} from 'recharts'
import { Download, RotateCcw, Info, Calculator as CalcIcon, TrendingUp } from 'lucide-react'

const COLORS = ['#8F9779', '#D4A373', '#CCD5AE', '#B08968', '#6B7052']

const CHART_TT = { backgroundColor: '#FFFDF2', border: '1px solid #E3DEC4', borderRadius: 8, fontSize: 12, color: '#2F3625' } as const

function Field({ label, children, hint }: { label: string; children: React.ReactNode; hint?: string }) {
  return (
    <div className="space-y-1.5">
      <Label className="text-[0.8rem] font-semibold text-[#3A4229]">{label}</Label>
      {children}
      {hint && <p className="text-[0.68rem] text-[#8B8F6E]">{hint}</p>}
    </div>
  )
}

function NumInput({ value, onChange, min = 0, max = 1e12, step = 1, prefix }: {
  value: number; onChange: (v: number) => void; min?: number; max?: number; step?: number; prefix?: string
}) {
  const [raw, setRaw] = useState(String(value))
  // eslint-disable-next-line react-hooks/set-state-in-effect -- sync controlled input with external prop changes
  useEffect(() => setRaw(String(value)), [value])
  return (
    <div className="relative">
      {prefix && <span className="absolute left-3 top-1/2 -translate-y-1/2 text-sm text-[#8B8F6E]">{prefix}</span>}
      <Input
        type="number" value={raw} min={min} max={max} step={step}
        onChange={(e) => {
          const v = parseFloat(e.target.value)
          setRaw(e.target.value)
          if (!isNaN(v)) onChange(Math.min(Math.max(v, min), max))
          else if (e.target.value === '') onChange(min)
        }}
        className={`h-10 bg-[#FFFDF2] ${prefix ? 'pl-7' : ''}`}
        inputMode="decimal"
      />
    </div>
  )
}

function ResultCard({ label, value, tone, sub }: { label: string; value: string; tone: 'sage' | 'bronze' | 'forest'; sub?: string }) {
  const styles = {
    sage: 'bg-[#E7EDD3] border-[#CBD5A6] text-[#3A4229]',
    bronze: 'bg-[#F6E7D2] border-[#E3C69F] text-[#5F4527]',
    forest: 'bg-[#EDF0DC] border-[#C6CFA4] text-[#2F3625]',
  }[tone]
  return (
    <div className={`rounded-xl border p-4 ${styles}`}>
      <p className="text-[0.7rem] font-semibold uppercase tracking-wider opacity-70">{label}</p>
      <p className="font-display text-xl sm:text-2xl font-semibold mt-1">{value}</p>
      {sub && <p className="text-[0.68rem] opacity-70 mt-0.5">{sub}</p>}
    </div>
  )
}

function Disclaimer({ children }: { children: React.ReactNode }) {
  return (
    <p className="flex items-start gap-2 text-[0.7rem] text-[#8B8F6E] leading-relaxed mt-4">
      <Info className="h-3.5 w-3.5 shrink-0 mt-0.5" />{children}
    </p>
  )
}

// ---------------------------------------------------------------- SIP

function SipCalc() {
  const [monthly, setMonthly] = useState(5000)
  const [rate, setRate] = useState(12)
  const [years, setYears] = useState(10)
  const res = useMemo(() => calcSip(monthly, rate, years), [monthly, rate, years])

  const summary = {
    calculator: 'SIP (Systematic Investment Plan)',
    formula: 'FV = P × ((1+i)^n − 1)/i × (1+i), where i = annual return ÷ 12, n = months',
    inputs: { monthlyInvestment: monthly, expectedAnnualReturnPct: rate, years },
    results: { totalInvested: res.invested, estimatedReturns: res.estimatedReturns, estimatedFinalValue: res.finalValue },
    generatedAt: new Date().toISOString(),
    disclaimer: 'Hypothetical estimate only. Actual market returns vary and are not guaranteed.',
  }

  return (
    <div className="grid lg:grid-cols-5 gap-6">
      <div className="lg:col-span-2 space-y-5 card-lux p-6">
        <Field label="Monthly investment" hint="Amount you invest every month">
          <NumInput value={monthly} onChange={setMonthly} min={100} max={1000000} step={500} prefix="₹" />
        </Field>
        <Field label={`Expected annual return — ${rate}%`} hint="Long-term equity funds have historically returned ~10–12%; this is an assumption, not a promise.">
          <Slider value={[rate]} min={0} max={30} step={0.5} onValueChange={(v) => setRate(v[0])} className="mt-2" />
        </Field>
        <Field label={`Investment duration — ${years} year${years > 1 ? 's' : ''}`}>
          <Slider value={[years]} min={1} max={40} step={1} onValueChange={(v) => setYears(v[0])} className="mt-2" />
        </Field>
        <div className="flex gap-2 pt-2">
          <Button variant="outline" className="flex-1" onClick={() => { setMonthly(5000); setRate(12); setYears(10) }}><RotateCcw className="h-4 w-4 mr-1" /> Reset</Button>
          <Button className="btn-bronze flex-1" onClick={() => downloadJson('money-harvest-sip-summary.json', summary)}><Download className="h-4 w-4 mr-1" /> Summary</Button>
        </div>
        <p className="text-[0.7rem] text-[#8B8F6E] leading-relaxed border-t border-[#EFEAD2] pt-3">
          <strong>Formula:</strong> FV = P × ((1+i)<sup>n</sup> − 1) ÷ i × (1+i), with monthly rate i = annual rate ÷ 12. Zero-return cases are computed as simple totals.
        </p>
      </div>
      <div className="lg:col-span-3 space-y-5">
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <ResultCard label="Invested amount" value={`₹${fmtINR(res.invested)}`} tone="sage" />
          <ResultCard label="Estimated returns" value={`₹${fmtINR(res.estimatedReturns)}`} tone="bronze" />
          <ResultCard label="Estimated value" value={`₹${fmtINR(res.finalValue)}`} tone="forest" sub={`${years} years at ${rate}% p.a.`} />
        </div>
        <div className="card-lux p-4 h-64">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={res.yearly} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
              <defs>
                <linearGradient id="gInv" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#CCD5AE" stopOpacity={0.9} /><stop offset="100%" stopColor="#CCD5AE" stopOpacity={0.4} /></linearGradient>
                <linearGradient id="gVal" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#D4A373" stopOpacity={0.85} /><stop offset="100%" stopColor="#D4A373" stopOpacity={0.35} /></linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#E3DEC4" />
              <XAxis dataKey="year" tick={{ fontSize: 11, fill: '#6B7052' }} />
              <YAxis tickFormatter={(v) => fmtCompact(Number(v))} tick={{ fontSize: 11, fill: '#6B7052' }} width={54} />
              <Tooltip contentStyle={CHART_TT} formatter={(v) => [`₹${fmtINR(Number(v))}`]} />
              <Legend wrapperStyle={{ fontSize: 11 }} />
              <Area type="monotone" dataKey="invested" name="Invested" stroke="#8F9779" fill="url(#gInv)" strokeWidth={2} />
              <Area type="monotone" dataKey="value" name="Portfolio value" stroke="#B08968" fill="url(#gVal)" strokeWidth={2} />
            </AreaChart>
          </ResponsiveContainer>
        </div>
        <div className="card-lux p-4 max-h-56 overflow-y-auto nice-scroll">
          <p className="text-xs font-semibold uppercase tracking-wider text-[#6B7052] mb-2">Year-by-year breakdown</p>
          <table className="w-full text-sm">
            <thead><tr className="text-left text-xs text-[#6B7052] border-b border-[#E3DEC4]"><th className="py-1.5 font-semibold">Year</th><th className="font-semibold">Invested</th><th className="font-semibold">Value</th><th className="font-semibold">Returns</th></tr></thead>
            <tbody>
              {res.yearly.map((y) => (
                <tr key={y.year} className="border-b border-[#F0EBD5]">
                  <td className="py-1.5">{y.year}</td><td>₹{fmtCompact(y.invested)}</td><td>₹{fmtCompact(y.value)}</td>
                  <td className="text-[#7A5A34]">₹{fmtCompact(y.returns)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <Disclaimer>Returns shown are hypothetical estimates based on your assumed rate. Actual market returns vary year to year and can be negative; no return is guaranteed.</Disclaimer>
      </div>
    </div>
  )
}

// ---------------------------------------------------------------- FD

function FdCalc() {
  const [principal, setPrincipal] = useState(100000)
  const [rate, setRate] = useState(7)
  const [years, setYears] = useState(5)
  const [comp, setComp] = useState(4)
  const res = useMemo(() => calcFd(principal, rate, years, comp), [principal, rate, years, comp])
  const compLabel = { 1: 'Yearly', 2: 'Half-yearly', 4: 'Quarterly', 12: 'Monthly' }[comp] || `${comp}×/year`

  return (
    <div className="grid lg:grid-cols-5 gap-6">
      <div className="lg:col-span-2 space-y-5 card-lux p-6">
        <Field label="Deposit amount"><NumInput value={principal} onChange={setPrincipal} min={500} max={1e9} step={1000} prefix="₹" /></Field>
        <Field label={`Annual interest rate — ${rate}%`}><Slider value={[rate]} min={1} max={15} step={0.1} onValueChange={(v) => setRate(v[0])} className="mt-2" /></Field>
        <Field label={`Duration — ${years} year${years > 1 ? 's' : ''}`}><Slider value={[years]} min={0.5} max={20} step={0.5} onValueChange={(v) => setYears(v[0])} className="mt-2" /></Field>
        <Field label="Compounding frequency">
          <div className="grid grid-cols-4 gap-1.5">
            {[1, 2, 4, 12].map((c) => (
              <button key={c} onClick={() => setComp(c)}
                className={`h-9 rounded-md text-xs font-semibold border transition-colors ${comp === c ? 'btn-bronze' : 'bg-[#FFFDF2] border-[#E3DEC4] text-[#55613F] hover:bg-[#F2EBD4]'}`}>
                {{ 1: 'Yearly', 2: 'Half-y', 4: 'Quarterly', 12: 'Monthly' }[c]}
              </button>
            ))}
          </div>
        </Field>
        <div className="flex gap-2 pt-2">
          <Button variant="outline" className="flex-1" onClick={() => { setPrincipal(100000); setRate(7); setYears(5); setComp(4) }}><RotateCcw className="h-4 w-4 mr-1" /> Reset</Button>
          <Button className="btn-bronze flex-1" onClick={() => downloadJson('money-harvest-fd-summary.json', { calculator: 'Fixed Deposit', inputs: { principal, ratePct: rate, years, compoundingPerYear: comp }, results: { invested: res.invested, interest: res.interest, maturityValue: res.maturityValue, effectiveAnnualYieldPct: res.effectiveAnnualYield }, formula: 'A = P × (1 + r/n)^(n×t)', generatedAt: new Date().toISOString() })}><Download className="h-4 w-4 mr-1" /> Summary</Button>
        </div>
        <p className="text-[0.7rem] text-[#8B8F6E] leading-relaxed border-t border-[#EFEAD2] pt-3"><strong>Formula:</strong> A = P × (1 + r/n)<sup>n·t</sup> — n = compounding frequency per year ({compLabel}).</p>
      </div>
      <div className="lg:col-span-3 space-y-5">
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <ResultCard label="Principal" value={`₹${fmtINR(principal)}`} tone="sage" />
          <ResultCard label="Interest earned" value={`₹${fmtINR(res.interest)}`} tone="bronze" />
          <ResultCard label="Maturity value" value={`₹${fmtINR(res.maturityValue)}`} tone="forest" sub={`Effective yield ${res.effectiveAnnualYield.toFixed(2)}% p.a.`} />
        </div>
        <div className="card-lux p-4 h-56">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={res.yearly} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#E3DEC4" />
              <XAxis dataKey="year" tick={{ fontSize: 11, fill: '#6B7052' }} />
              <YAxis tickFormatter={(v) => fmtCompact(Number(v))} tick={{ fontSize: 11, fill: '#6B7052' }} width={54} />
              <Tooltip contentStyle={CHART_TT} formatter={(v) => [`₹${fmtINR(Number(v))}`]} />
              <Bar dataKey="value" name="Value" fill="#CCD5AE" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
        <Disclaimer>FD interest is taxable at your slab rate, which reduces net returns. Deposits are DICGC-insured up to ₹5 lakh per depositor per bank.</Disclaimer>
      </div>
    </div>
  )
}

// ---------------------------------------------------------------- RD

function RdCalc() {
  const [monthly, setMonthly] = useState(5000)
  const [rate, setRate] = useState(7)
  const [years, setYears] = useState(2)
  const res = useMemo(() => calcRd(monthly, rate, Math.round(years)), [monthly, rate, years])
  return (
    <div className="grid lg:grid-cols-5 gap-6">
      <div className="lg:col-span-2 space-y-5 card-lux p-6">
        <Field label="Monthly deposit"><NumInput value={monthly} onChange={setMonthly} min={100} max={500000} step={500} prefix="₹" /></Field>
        <Field label={`Interest rate — ${rate}% p.a.`}><Slider value={[rate]} min={1} max={12} step={0.1} onValueChange={(v) => setRate(v[0])} className="mt-2" /></Field>
        <Field label={`Duration — ${Math.round(years)} year${Math.round(years) > 1 ? 's' : ''}`}><Slider value={[years]} min={1} max={10} step={1} onValueChange={(v) => setYears(v[0])} className="mt-2" /></Field>
        <div className="flex gap-2 pt-2">
          <Button variant="outline" className="flex-1" onClick={() => { setMonthly(5000); setRate(7); setYears(2) }}><RotateCcw className="h-4 w-4 mr-1" /> Reset</Button>
          <Button className="btn-bronze flex-1" onClick={() => downloadJson('money-harvest-rd-summary.json', { calculator: 'Recurring Deposit', inputs: { monthly, ratePct: rate, years }, results: { invested: res.invested, interest: res.interest, maturityValue: res.maturityValue }, formula: 'Each instalment compounds quarterly from its own deposit date', generatedAt: new Date().toISOString() })}><Download className="h-4 w-4 mr-1" /> Summary</Button>
        </div>
        <p className="text-[0.7rem] text-[#8B8F6E] leading-relaxed border-t border-[#EFEAD2] pt-3"><strong>Method:</strong> each monthly instalment compounds quarterly (Indian bank standard) only from its own deposit date — so effective yield is below the headline rate.</p>
      </div>
      <div className="lg:col-span-3 space-y-5">
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <ResultCard label="Total deposited" value={`₹${fmtINR(res.invested)}`} tone="sage" />
          <ResultCard label="Interest earned" value={`₹${fmtINR(res.interest)}`} tone="bronze" />
          <ResultCard label="Maturity value" value={`₹${fmtINR(res.maturityValue)}`} tone="forest" />
        </div>
        <div className="card-lux p-4 h-56">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={res.yearly}>
              <defs><linearGradient id="gRd" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#D4A373" stopOpacity={0.8} /><stop offset="100%" stopColor="#D4A373" stopOpacity={0.3} /></linearGradient></defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#E3DEC4" />
              <XAxis dataKey="year" tick={{ fontSize: 11, fill: '#6B7052' }} />
              <YAxis tickFormatter={(v) => fmtCompact(Number(v))} tick={{ fontSize: 11, fill: '#6B7052' }} width={54} />
              <Tooltip contentStyle={CHART_TT} formatter={(v) => [`₹${fmtINR(Number(v))}`]} />
              <Legend wrapperStyle={{ fontSize: 11 }} />
              <Area type="monotone" dataKey="invested" name="Deposited" stroke="#8F9779" fill="#CCD5AE" fillOpacity={0.5} strokeWidth={2} />
              <Area type="monotone" dataKey="value" name="Value" stroke="#B08968" fill="url(#gRd)" strokeWidth={2} />
            </AreaChart>
          </ResponsiveContainer>
        </div>
        <Disclaimer>RD rates are locked at opening. Missing instalments may attract penalties depending on your bank; premature closure usually pays a lower rate.</Disclaimer>
      </div>
    </div>
  )
}

// ---------------------------------------------------------------- Compound

function CompoundCalc() {
  const [initial, setInitial] = useState(50000)
  const [monthly, setMonthly] = useState(2000)
  const [rate, setRate] = useState(10)
  const [years, setYears] = useState(10)
  const [comp, setComp] = useState(4)
  const res = useMemo(() => calcCompound(initial, monthly, rate, years, comp), [initial, monthly, rate, years, comp])
  return (
    <div className="grid lg:grid-cols-5 gap-6">
      <div className="lg:col-span-2 space-y-5 card-lux p-6">
        <Field label="Initial amount"><NumInput value={initial} onChange={setInitial} min={0} max={1e9} step={1000} prefix="₹" /></Field>
        <Field label="Additional monthly contribution (optional)"><NumInput value={monthly} onChange={setMonthly} min={0} max={1e6} step={500} prefix="₹" /></Field>
        <Field label={`Interest rate — ${rate}% p.a.`}><Slider value={[rate]} min={0} max={25} step={0.25} onValueChange={(v) => setRate(v[0])} className="mt-2" /></Field>
        <Field label={`Duration — ${years} years`}><Slider value={[years]} min={1} max={40} step={1} onValueChange={(v) => setYears(v[0])} className="mt-2" /></Field>
        <Field label="Compounding frequency">
          <div className="grid grid-cols-4 gap-1.5">
            {[1, 2, 4, 12].map((c) => (
              <button key={c} onClick={() => setComp(c)} className={`h-9 rounded-md text-xs font-semibold border ${comp === c ? 'btn-bronze' : 'bg-[#FFFDF2] border-[#E3DEC4] text-[#55613F] hover:bg-[#F2EBD4]'}`}>
                {{ 1: 'Yearly', 2: 'Half-y', 4: 'Quarterly', 12: 'Monthly' }[c]}
              </button>
            ))}
          </div>
        </Field>
        <div className="flex gap-2 pt-2">
          <Button variant="outline" className="flex-1" onClick={() => { setInitial(50000); setMonthly(2000); setRate(10); setYears(10); setComp(4) }}><RotateCcw className="h-4 w-4 mr-1" /> Reset</Button>
          <Button className="btn-bronze flex-1" onClick={() => downloadJson('money-harvest-compound-summary.json', { calculator: 'Compound Interest', inputs: { initial, monthly, ratePct: rate, years, compPerYear: comp }, results: { invested: res.invested, interest: res.interest, finalValue: res.finalValue }, formula: 'A = P × (1 + r/n)^(n×t) + contributions', generatedAt: new Date().toISOString() })}><Download className="h-4 w-4 mr-1" /> Summary</Button>
        </div>
      </div>
      <div className="lg:col-span-3 space-y-5">
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <ResultCard label="Total contributed" value={`₹${fmtINR(res.invested)}`} tone="sage" />
          <ResultCard label="Interest earned" value={`₹${fmtINR(res.interest)}`} tone="bronze" />
          <ResultCard label="Final value" value={`₹${fmtINR(res.finalValue)}`} tone="forest" />
        </div>
        <div className="card-lux p-4 h-56">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={res.yearly}>
              <defs><linearGradient id="gCi" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#8F9779" stopOpacity={0.75} /><stop offset="100%" stopColor="#8F9779" stopOpacity={0.25} /></linearGradient></defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#E3DEC4" />
              <XAxis dataKey="year" tick={{ fontSize: 11, fill: '#6B7052' }} />
              <YAxis tickFormatter={(v) => fmtCompact(Number(v))} tick={{ fontSize: 11, fill: '#6B7052' }} width={54} />
              <Tooltip contentStyle={CHART_TT} formatter={(v) => [`₹${fmtINR(Number(v))}`]} />
              <Legend wrapperStyle={{ fontSize: 11 }} />
              <Area type="monotone" dataKey="invested" name="Contributed" stroke="#6B7052" fill="#CCD5AE" fillOpacity={0.5} strokeWidth={2} />
              <Area type="monotone" dataKey="value" name="Value" stroke="#8F9779" fill="url(#gCi)" strokeWidth={2} />
            </AreaChart>
          </ResponsiveContainer>
        </div>
        <Disclaimer>Monthly contributions are applied within each compounding period (mid-period approximation). Actual account terms may differ slightly.</Disclaimer>
      </div>
    </div>
  )
}

// ---------------------------------------------------------------- EMI

function EmiCalc() {
  const [principal, setPrincipal] = useState(2500000)
  const [rate, setRate] = useState(9)
  const [years, setYears] = useState(20)
  const res = useMemo(() => calcEmi(principal, rate, years), [principal, rate, years])
  const pie = [
    { name: 'Principal', value: principal },
    { name: 'Total interest', value: res.totalInterest },
  ]
  return (
    <div className="grid lg:grid-cols-5 gap-6">
      <div className="lg:col-span-2 space-y-5 card-lux p-6">
        <Field label="Loan amount"><NumInput value={principal} onChange={setPrincipal} min={10000} max={1e9} step={10000} prefix="₹" /></Field>
        <Field label={`Annual interest rate — ${rate}%`} hint="Confirm whether your quote is reducing-balance or flat; flat rates are far costlier.">
          <Slider value={[rate]} min={4} max={24} step={0.1} onValueChange={(v) => setRate(v[0])} className="mt-2" />
        </Field>
        <Field label={`Tenure — ${years} years`}><Slider value={[years]} min={1} max={30} step={1} onValueChange={(v) => setYears(v[0])} className="mt-2" /></Field>
        <div className="flex gap-2 pt-2">
          <Button variant="outline" className="flex-1" onClick={() => { setPrincipal(2500000); setRate(9); setYears(20) }}><RotateCcw className="h-4 w-4 mr-1" /> Reset</Button>
          <Button className="btn-bronze flex-1" onClick={() => downloadJson('money-harvest-emi-summary.json', { calculator: 'Loan EMI', inputs: { principal, ratePct: rate, years }, results: { emi: res.emi, totalInterest: res.totalInterest, totalPayment: res.totalPayment }, formula: 'EMI = P·r·(1+r)^n / ((1+r)^n − 1)', generatedAt: new Date().toISOString() })}><Download className="h-4 w-4 mr-1" /> Summary</Button>
        </div>
      </div>
      <div className="lg:col-span-3 space-y-5">
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <ResultCard label="Monthly EMI" value={`₹${fmtINR(res.emi)}`} tone="bronze" />
          <ResultCard label="Total interest" value={`₹${fmtINR(res.totalInterest)}`} tone="sage" sub={`${((res.totalInterest / principal) * 100).toFixed(0)}% of principal`} />
          <ResultCard label="Total payment" value={`₹${fmtINR(res.totalPayment)}`} tone="forest" />
        </div>
        <div className="grid sm:grid-cols-2 gap-5">
          <div className="card-lux p-4 h-56">
            <p className="text-xs font-semibold text-[#6B7052] mb-2">Payment split</p>
            <ResponsiveContainer width="100%" height="90%">
              <PieChart>
                <Pie data={pie} dataKey="value" nameKey="name" innerRadius={45} outerRadius={70} paddingAngle={3}>
                  <Cell fill="#CCD5AE" /><Cell fill="#D4A373" />
                </Pie>
                <Tooltip contentStyle={CHART_TT} formatter={(v) => [`₹${fmtINR(Number(v))}`]} />
                <Legend wrapperStyle={{ fontSize: 11 }} />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="card-lux p-4 h-56">
            <p className="text-xs font-semibold text-[#6B7052] mb-2">Balance over time</p>
            <ResponsiveContainer width="100%" height="90%">
              <AreaChart data={res.yearly}>
                <defs><linearGradient id="gBal" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#B08968" stopOpacity={0.7} /><stop offset="100%" stopColor="#B08968" stopOpacity={0.2} /></linearGradient></defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#E3DEC4" />
                <XAxis dataKey="year" tick={{ fontSize: 11, fill: '#6B7052' }} />
                <YAxis tickFormatter={(v) => fmtCompact(Number(v))} tick={{ fontSize: 11, fill: '#6B7052' }} width={54} />
                <Tooltip contentStyle={CHART_TT} formatter={(v) => [`₹${fmtINR(Number(v))}`]} />
                <Area type="monotone" dataKey="balance" name="Outstanding" stroke="#8F6B44" fill="url(#gBal)" strokeWidth={2} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
        <div className="card-lux p-4 max-h-48 overflow-y-auto nice-scroll">
          <table className="w-full text-sm">
            <thead><tr className="text-left text-xs text-[#6B7052] border-b border-[#E3DEC4]"><th className="py-1.5">Year</th><th>Principal paid</th><th>Interest paid</th><th>Balance</th></tr></thead>
            <tbody>{res.yearly.map((y) => (
              <tr key={y.year} className="border-b border-[#F0EBD5]"><td className="py-1.5">{y.year}</td><td>₹{fmtCompact(y.principalPaid)}</td><td>₹{fmtCompact(y.interestPaid)}</td><td>₹{fmtCompact(y.balance)}</td></tr>
            ))}</tbody>
          </table>
        </div>
        <Disclaimer>Early EMIs are interest-heavy. Prepaying early and choosing tenure reduction (not EMI reduction) saves the most interest. Floating-rate retail loans carry no prepayment penalty per RBI rules.</Disclaimer>
      </div>
    </div>
  )
}

// ---------------------------------------------------------------- Budget

function BudgetCalc() {
  const [income, setIncome] = useState(50000)
  const [essentials, setEssentials] = useState(22000)
  const [lifestyle, setLifestyle] = useState(12000)
  const [savings, setSavings] = useState(10000)
  const [debt, setDebt] = useState(4000)
  const res = useMemo(() => calcBudget(income, essentials, lifestyle, savings, debt), [income, essentials, lifestyle, savings, debt])
  return (
    <div className="grid lg:grid-cols-5 gap-6">
      <div className="lg:col-span-2 space-y-4 card-lux p-6">
        <Field label="Monthly income (take-home)"><NumInput value={income} onChange={setIncome} min={0} max={1e8} step={1000} prefix="₹" /></Field>
        <Field label="Essential expenses" hint="Rent, groceries, utilities, transport, insurance"><NumInput value={essentials} onChange={setEssentials} min={0} step={500} prefix="₹" /></Field>
        <Field label="Lifestyle expenses" hint="Dining out, entertainment, shopping"><NumInput value={lifestyle} onChange={setLifestyle} min={0} step={500} prefix="₹" /></Field>
        <Field label="Savings & investments"><NumInput value={savings} onChange={setSavings} min={0} step={500} prefix="₹" /></Field>
        <Field label="Debt payments (EMIs)"><NumInput value={debt} onChange={setDebt} min={0} step={500} prefix="₹" /></Field>
        <Button variant="outline" className="w-full" onClick={() => { setIncome(50000); setEssentials(22000); setLifestyle(12000); setSavings(10000); setDebt(4000) }}><RotateCcw className="h-4 w-4 mr-1" /> Reset</Button>
      </div>
      <div className="lg:col-span-3 space-y-5">
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <ResultCard label="Savings rate" value={`${res.savingsRate.toFixed(1)}%`} tone={res.savingsRate >= 20 ? 'sage' : 'bronze'} sub="Target: 20%+" />
          <ResultCard label="Total outflow" value={`₹${fmtINR(res.totalExpenses + savings)}`} tone="forest" />
          <ResultCard label={res.surplus >= 0 ? 'Unallocated surplus' : 'Over-committed'} value={`₹${fmtINR(Math.abs(res.surplus))}`} tone={res.surplus >= 0 ? 'sage' : 'bronze'} />
        </div>
        <div className="grid sm:grid-cols-2 gap-5">
          <div className="card-lux p-4 h-60">
            <p className="text-xs font-semibold text-[#6B7052] mb-2">Where income goes</p>
            <ResponsiveContainer width="100%" height="90%">
              <PieChart>
                <Pie data={res.breakdown.filter((b) => b.amount > 0).concat(res.surplus > 0 ? [{ label: 'Unallocated', amount: res.surplus, percent: 0, color: '#E3DEC4' }] : [])} dataKey="amount" nameKey="label" innerRadius={42} outerRadius={68} paddingAngle={3}>
                  {res.breakdown.map((b, i) => <Cell key={i} fill={b.color} />)}
                </Pie>
                <Tooltip contentStyle={CHART_TT} formatter={(v) => [`₹${fmtINR(Number(v))}`]} />
                <Legend wrapperStyle={{ fontSize: 10 }} />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="card-lux p-5 space-y-2.5 max-h-60 overflow-y-auto nice-scroll">
            <p className="text-xs font-semibold uppercase tracking-wider text-[#6B7052] mb-1">50/30/20 guidance</p>
            {res.guidance.map((g, i) => (
              <p key={i} className="text-sm text-[#4A5236] leading-relaxed flex gap-2"><TrendingUp className="h-3.5 w-3.5 mt-1 shrink-0 text-[#B08968]" />{g}</p>
            ))}
          </div>
        </div>
        <Disclaimer>The 50/30/20 rule is a starting frame, not a mandate — adapt it to your city and life stage while protecting the savings line.</Disclaimer>
      </div>
    </div>
  )
}

// ---------------------------------------------------------------- Inflation

function InflationCalc() {
  const [amount, setAmount] = useState(100000)
  const [rate, setRate] = useState(6)
  const [years, setYears] = useState(10)
  const res = useMemo(() => calcInflation(amount, rate, Math.round(years)), [amount, rate, years])
  return (
    <div className="grid lg:grid-cols-5 gap-6">
      <div className="lg:col-span-2 space-y-5 card-lux p-6">
        <Field label="Current amount / expense"><NumInput value={amount} onChange={setAmount} min={100} max={1e9} step={1000} prefix="₹" /></Field>
        <Field label={`Annual inflation assumption — ${rate}%`} hint="India's CPI has averaged roughly 5–6% over recent decades."><Slider value={[rate]} min={1} max={15} step={0.25} onValueChange={(v) => setRate(v[0])} className="mt-2" /></Field>
        <Field label={`Number of years — ${Math.round(years)}`}><Slider value={[years]} min={1} max={40} step={1} onValueChange={(v) => setYears(v[0])} className="mt-2" /></Field>
        <div className="flex gap-2 pt-2">
          <Button variant="outline" className="flex-1" onClick={() => { setAmount(100000); setRate(6); setYears(10) }}><RotateCcw className="h-4 w-4 mr-1" /> Reset</Button>
          <Button className="btn-bronze flex-1" onClick={() => downloadJson('money-harvest-inflation-summary.json', { calculator: 'Inflation Impact', inputs: { amount, inflationPct: rate, years }, results: { futureCost: res.futureCost, purchasingPowerOfAmount: res.purchasingPower }, formula: 'FV = P × (1 + i)^t', generatedAt: new Date().toISOString() })}><Download className="h-4 w-4 mr-1" /> Summary</Button>
        </div>
      </div>
      <div className="lg:col-span-3 space-y-5">
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <ResultCard label="Today" value={`₹${fmtINR(amount)}`} tone="sage" />
          <ResultCard label={`Cost in ${Math.round(years)} years`} value={`₹${fmtINR(res.futureCost)}`} tone="bronze" />
          <ResultCard label="Future purchasing power" value={`₹${fmtINR(res.purchasingPower)}`} tone="forest" sub="What today's money will feel like" />
        </div>
        <div className="card-lux p-4 h-60">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={res.yearly}>
              <defs><linearGradient id="gInf" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#D4A373" stopOpacity={0.8} /><stop offset="100%" stopColor="#D4A373" stopOpacity={0.25} /></linearGradient></defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#E3DEC4" />
              <XAxis dataKey="year" tick={{ fontSize: 11, fill: '#6B7052' }} />
              <YAxis tickFormatter={(v) => fmtCompact(Number(v))} tick={{ fontSize: 11, fill: '#6B7052' }} width={54} />
              <Tooltip contentStyle={CHART_TT} formatter={(v) => [`₹${fmtINR(Number(v))}`]} />
              <Area type="monotone" dataKey="value" name="Future cost" stroke="#B08968" fill="url(#gInf)" strokeWidth={2} />
            </AreaChart>
          </ResponsiveContainer>
        </div>
        <Disclaimer>This is a straight-line projection using your assumed rate. Actual inflation varies by category and year — education and healthcare often rise faster than headline CPI.</Disclaimer>
      </div>
    </div>
  )
}

// ---------------------------------------------------------------- Goal

function GoalCalc() {
  const [target, setTarget] = useState(500000)
  const [existing, setExisting] = useState(50000)
  const [monthly, setMonthly] = useState(15000)
  const [rate, setRate] = useState(6)
  const [months, setMonths] = useState(36)
  const res = useMemo(() => calcSavingsGoal(target, existing, monthly, rate, months), [target, existing, monthly, rate, months])
  return (
    <div className="grid lg:grid-cols-5 gap-6">
      <div className="lg:col-span-2 space-y-4 card-lux p-6">
        <Field label="Target amount"><NumInput value={target} onChange={setTarget} min={1000} max={1e9} step={1000} prefix="₹" /></Field>
        <Field label="Existing savings"><NumInput value={existing} onChange={setExisting} min={0} max={1e9} step={1000} prefix="₹" /></Field>
        <Field label="Monthly contribution"><NumInput value={monthly} onChange={setMonthly} min={0} max={1e7} step={500} prefix="₹" /></Field>
        <Field label={`Expected interest rate — ${rate}% (if any)`} hint="Savings account ~3%; liquid fund ~6–7%; enter 0 for cash at home."><Slider value={[rate]} min={0} max={15} step={0.25} onValueChange={(v) => setRate(v[0])} className="mt-2" /></Field>
        <Field label={`Time frame — ${months} months`}><Slider value={[months]} min={3} max={120} step={3} onValueChange={(v) => setMonths(v[0])} className="mt-2" /></Field>
        <Button variant="outline" className="w-full" onClick={() => { setTarget(500000); setExisting(50000); setMonthly(15000); setRate(6); setMonths(36) }}><RotateCcw className="h-4 w-4 mr-1" /> Reset</Button>
      </div>
      <div className="lg:col-span-3 space-y-5">
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <ResultCard label={res.reachable ? 'Goal reached in' : 'Shortfall'} value={res.reachable ? `${res.monthsRequired} months` : `₹${fmtINR(res.shortfall)}`} tone={res.reachable ? 'sage' : 'bronze'} sub={res.reachable ? 'Ahead of your deadline' : `at ₹${fmtINR(monthly)}/month`} />
          <ResultCard label="Required monthly" value={`₹${fmtINR(res.requiredMonthly)}`} tone="forest" sub={res.reachable ? 'Your current plan works' : 'to reach target on time'} />
          <ResultCard label="Interest earned" value={`₹${fmtINR(res.interestEarned)}`} tone="sage" sub="along the way" />
        </div>
        <div className="card-lux p-6">
          <p className="font-display text-lg font-semibold text-[#2F3625] mb-2">{res.reachable ? 'Plan summary' : 'How to close the gap'}</p>
          {res.reachable ? (
            <p className="text-sm text-[#4A5236] leading-relaxed">
              Contributing <strong>₹{fmtINR(monthly)}</strong> monthly at {rate}% p.a., you reach <strong>₹{fmtINR(target)}</strong> in about <strong>{res.monthsRequired} months</strong> — within your {months}-month window. Total contributions: ₹{fmtINR(res.totalContributions)} plus ₹{fmtINR(res.interestEarned)} of interest on top of your ₹{fmtINR(existing)} starting balance.
            </p>
          ) : (
            <p className="text-sm text-[#4A5236] leading-relaxed">
              At ₹{fmtINR(monthly)}/month you will have ₹{fmtINR(target - res.shortfall)} by month {months} — a shortfall of ₹{fmtINR(res.shortfall)}. To close the gap: raise contributions to about <strong>₹{fmtINR(res.requiredMonthly)}/month</strong>, extend the deadline, or lower the target. Adjusting one input realistically beats abandoning the goal.
            </p>
          )}
        </div>
        <Disclaimer>Projections assume a constant rate with monthly compounding. Keep goal money under 3 years in safe instruments — market-linked assets can be negative when you need the money.</Disclaimer>
      </div>
    </div>
  )
}

// ---------------------------------------------------------------- Shell

export function Calculators() {
  const route = useRoute()
  const initial = route.query.get('tool') || 'sip'
  const [tab, setTab] = useState(initial)
  // eslint-disable-next-line react-hooks/set-state-in-effect -- respond to deep-link tool query changes
  useEffect(() => { if (route.query.get('tool')) setTab(route.query.get('tool') as string) }, [route.query])

  return (
    <div className="view-enter mx-auto max-w-7xl px-4 sm:px-6 py-10">
      <div className="mb-8">
        <span className="badge-soft badge-bronze mb-3"><CalcIcon className="h-3.5 w-3.5" /> Financial Calculators</span>
        <h1 className="font-display text-3xl sm:text-4xl font-semibold text-[#2F3625]">Real math for real decisions</h1>
        <p className="mt-2 text-[#55613F] max-w-2xl">
          Every calculator performs live calculations from your inputs — with the formula shown, invalid values handled, and downloadable summaries. Results are estimates; markets are not.
        </p>
      </div>

      <Tabs value={tab} onValueChange={setTab} className="w-full">
        <TabsList className="flex-wrap h-auto gap-1 bg-[#E9EDC9] p-1.5 rounded-xl mb-6 justify-start">
          {calculatorRegistry.map((c) => (
            <TabsTrigger key={c.key} value={c.key} className="data-[state=active]:bg-[#FFFDF2] data-[state=active]:shadow-sm text-xs sm:text-[0.8rem] font-semibold rounded-lg px-3 py-1.5">
              {c.title.replace(' Calculator', '').replace(' (FD)', '').replace(' (RD)', '')}
            </TabsTrigger>
          ))}
        </TabsList>

        <TabsContent value="sip"><SipCalc /></TabsContent>
        <TabsContent value="fd"><FdCalc /></TabsContent>
        <TabsContent value="rd"><RdCalc /></TabsContent>
        <TabsContent value="compound"><CompoundCalc /></TabsContent>
        <TabsContent value="emi"><EmiCalc /></TabsContent>
        <TabsContent value="budget"><BudgetCalc /></TabsContent>
        <TabsContent value="inflation"><InflationCalc /></TabsContent>
        <TabsContent value="goal"><GoalCalc /></TabsContent>
      </Tabs>

      <div className="mt-10 card-lux p-5 bg-[#E9EDC9] border-[#D8DCBB] text-sm text-[#4A5236]">
        Want the theory behind these numbers? Read <button className="link-quiet underline font-semibold" onClick={() => navigate('/lesson/compound-interest')}>Compound Interest</button>, <button className="link-quiet underline font-semibold" onClick={() => navigate('/lesson/sip')}>SIP</button>, <button className="link-quiet underline font-semibold" onClick={() => navigate('/lesson/loans-and-interest')}>Loans & Interest</button> or <button className="link-quiet underline font-semibold" onClick={() => navigate('/lesson/understanding-inflation')}>Understanding Inflation</button> in the Education Center.
      </div>
    </div>
  )
}
