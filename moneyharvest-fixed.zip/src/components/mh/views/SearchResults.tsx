'use client'

import { useEffect, useState } from 'react'
import { navigate, apiGet, useDebounced, useRoute } from './../router'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import { Skeleton } from '@/components/ui/skeleton'
import {
  Search, BookOpenCheck, Calculator, Target, Award, Library, Users,
  ArrowRight, SearchX,
} from 'lucide-react'

interface ResultItem {
  type: 'lesson' | 'resource' | 'post' | 'calculator' | 'quiz' | 'certificate'
  title: string; description: string; link: string; category?: string
}

const TYPE_META: Record<string, { icon: React.ComponentType<{ className?: string }>; label: string }> = {
  lesson: { icon: BookOpenCheck, label: 'Lesson' },
  resource: { icon: Library, label: 'Resource' },
  post: { icon: Users, label: 'Community' },
  calculator: { icon: Calculator, label: 'Calculator' },
  quiz: { icon: Target, label: 'Quiz' },
  certificate: { icon: Award, label: 'Certificate' },
}

const FILTERS = ['all', 'lesson', 'calculator', 'quiz', 'certificate', 'resource', 'post']

export function SearchResults() {
  const route = useRoute()
  const initialQ = route.query.get('q') || ''
  const [q, setQ] = useState(initialQ)
  const dq = useDebounced(q, 350)
  const [type, setType] = useState('all')
  const [results, setResults] = useState<ResultItem[] | null>(null)
  const [suggestions, setSuggestions] = useState<string[]>([])

  useEffect(() => { setQ(initialQ) }, [initialQ])

  useEffect(() => {
    if (dq.trim().length < 2) { setResults(null); return }
    setResults(null)
    const params = new URLSearchParams({ q: dq })
    if (type !== 'all') params.set('type', type)
    apiGet<{ results: ResultItem[] }>(`/api/search?${params}`)
      .then((d) => setResults(d.results))
      .catch(() => setResults([]))
  }, [dq, type])

  return (
    <div className="view-enter mx-auto max-w-4xl px-4 sm:px-6 py-10">
      <h1 className="font-display text-3xl font-semibold text-[#2F3625] mb-6 flex items-center gap-2.5">
        <Search className="h-7 w-7 text-[#8F6B44]" /> Search Money Harvest
      </h1>

      <div className="relative">
        <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 h-5 w-5 text-[#8B8F6E]" />
        <Input value={q} onChange={(e) => setQ(e.target.value)} autoFocus
          placeholder="Search lessons, calculators, quizzes, certificates, resources, community…" className="pl-11 h-13 h-[3.25rem] text-base bg-[#FFFDF2]" aria-label="Search query" />
        {q && (
          <button onClick={() => { setQ(''); navigate('/search') }}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-xs font-semibold link-quiet underline">clear</button>
        )}
      </div>

      {/* suggestions */}
      {!dq || dq.length < 2 ? (
        <div className="mt-10">
          <p className="text-sm font-semibold text-[#6B7052] mb-3">Try searching for…</p>
          <div className="flex flex-wrap gap-2">
            {['SIP', 'compound interest', 'UPI safety', 'emergency fund', 'credit score', 'phishing', 'budget planner', 'scam', 'certificates'].map((s) => (
              <button key={s} onClick={() => setQ(s)} className="badge-soft hover:bg-[#CCD5AE] transition-colors">{s}</button>
            ))}
          </div>
        </div>
      ) : (
        <>
          {/* type filters */}
          <div className="flex flex-wrap gap-2 mt-5">
            {FILTERS.map((f) => (
              <button key={f} onClick={() => setType(f)}
                className={`text-xs font-semibold px-3 py-1.5 rounded-full border capitalize transition-colors ${type === f ? 'btn-bronze' : 'bg-[#FFFDF2] border-[#E3DEC4] text-[#55613F] hover:bg-[#F2EBD4]'}`}>
                {f}
              </button>
            ))}
          </div>

          {/* results */}
          <div className="mt-6 space-y-3">
            {results === null ? (
              Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-20 rounded-xl" />)
            ) : results.length === 0 ? (
              <div className="card-lux p-12 text-center">
                <SearchX className="h-10 w-10 mx-auto text-[#D8D2B4] mb-3" />
                <p className="font-display text-lg text-[#2F3625]">No results for “{dq}”</p>
                <p className="text-sm text-[#6B7052] mt-1">Check the spelling, try a broader term, or browse the Education Center directly.</p>
                <Button className="btn-bronze mt-4 font-semibold" onClick={() => navigate('/education')}>Browse lessons</Button>
              </div>
            ) : (
              results.map((r, i) => {
                const meta = TYPE_META[r.type]
                return (
                  <button key={i} onClick={() => navigate(r.link)}
                    className="card-lux p-4.5 p-4 w-full text-left flex items-start gap-4 group">
                    <span className="h-10 w-10 rounded-lg bg-[#E9EDC9] flex items-center justify-center text-[#55613F] shrink-0">
                      <meta.icon className="h-5 w-5" />
                    </span>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2">
                        <p className="font-semibold text-[#2F3625] group-hover:text-[#6E5133] truncate">{r.title}</p>
                        <span className="badge-soft shrink-0 !text-[0.6rem] !py-0">{meta.label}</span>
                      </div>
                      <p className="text-sm text-[#55613F] mt-0.5 line-clamp-2">{r.description}</p>
                    </div>
                    <ArrowRight className="h-4 w-4 text-[#B08968] mt-3 shrink-0 opacity-0 group-hover:opacity-100 transition-opacity" />
                  </button>
                )
              })
            )}
          </div>
        </>
      )}
    </div>
  )
}
