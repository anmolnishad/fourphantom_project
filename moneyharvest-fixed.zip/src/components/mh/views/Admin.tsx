'use client'

import { useEffect, useState } from 'react'
import { navigate, apiGet, apiSend, fmtDate, timeAgo } from './../router'
import { useApp } from './../store'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Skeleton } from '@/components/ui/skeleton'
import { Textarea } from '@/components/ui/textarea'
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs'
import {
  ShieldCheck, Users, FileSearch, MessagesSquare, HelpCircle, Library,
  Award, Trash2, CheckCircle2, XCircle, Ban, ChevronUp, ChevronDown, Plus, Target,
} from 'lucide-react'

const CATEGORIES = ['personal-finance', 'investment-basics', 'banking-awareness', 'cybersecurity', 'scam-detection', 'digital-payments']
const DIFFS = ['beginner', 'intermediate', 'advanced']

export function Admin() {
  const { user, userLoaded } = useApp()
  const [stats, setStats] = useState<AdminStats | null>(null)
  const [reports, setReports] = useState<ReportT[] | null>(null)
  const [users, setUsers] = useState<UserT[] | null>(null)
  const [questions, setQuestions] = useState<QT[] | null>(null)
  const [qCat, setQCat] = useState('')
  const [userQ, setUserQ] = useState('')
  const [newQ, setNewQ] = useState<{ question: string; options: string[]; correctIndex: number; explanation: string; category: string; difficulty: string }>({
    question: '', options: ['', '', '', ''], correctIndex: 0, explanation: '', category: 'personal-finance', difficulty: 'beginner',
  })
  const [creating, setCreating] = useState(false)
  const [qError, setQError] = useState('')

  const isAdmin = user?.role === 'ADMIN'

  useEffect(() => {
    if (!isAdmin) return
    apiGet<AdminStats>('/api/admin/stats').then(setStats).catch(() => setStats(null))
    apiGet<{ reports: ReportT[] }>('/api/admin/reports').then((d) => setReports(d.reports)).catch(() => setReports([]))
    apiGet<{ users: UserT[] }>('/api/admin/users').then((d) => setUsers(d.users)).catch(() => setUsers([]))
  }, [isAdmin])

  useEffect(() => {
    if (!isAdmin) return
    // eslint-disable-next-line react-hooks/set-state-in-effect -- reset to skeleton while loading new filter
    setQuestions(null)
    apiGet<{ questions: QT[] }>(`/api/admin/questions${qCat ? `?category=${qCat}` : ''}`).then((d) => setQuestions(d.questions)).catch(() => setQuestions([]))
  }, [isAdmin, qCat])

  if (userLoaded && !user) { navigate('/signin?next=/admin'); return null }
  if (!user) return null
  if (!isAdmin) {
    return (
      <div className="mx-auto max-w-lg px-4 py-24 text-center">
        <Ban className="h-12 w-12 mx-auto text-[#D8D2B4] mb-4" />
        <h1 className="font-display text-2xl font-semibold text-[#2F3625]">Administrative access required</h1>
        <p className="text-sm text-[#6B7052] mt-2">This dashboard is restricted to authorised administrators. Permissions are enforced on the backend — not just by hiding links.</p>
        <Button className="btn-bronze mt-6 font-semibold" onClick={() => navigate('/dashboard')}>Back to my dashboard</Button>
      </div>
    )
  }

  const handleReport = async (reportId: string, action: 'resolve' | 'dismiss', deletePost = false) => {
    try {
      await apiSend('/api/admin/reports', 'PATCH', { reportId, action, deletePost })
      setReports((rs) => (rs || []).filter((r) => r.id !== reportId))
      apiGet<AdminStats>('/api/admin/stats').then(setStats).catch(() => {})
    } catch { /* silent */ }
  }

  const userAction = async (userId: string, action: string) => {
    try {
      await apiSend('/api/admin/users', 'PATCH', { userId, action })
      const d = await apiGet<{ users: UserT[] }>(`/api/admin/users${userQ ? `?q=${encodeURIComponent(userQ)}` : ''}`)
      setUsers(d.users)
    } catch { /* silent */ }
  }

  const createQuestion = async () => {
    setQError('')
    if (newQ.question.trim().length < 8) { setQError('Question text is too short.'); return }
    const opts = newQ.options.map((o) => o.trim()).filter(Boolean)
    if (opts.length < 2) { setQError('Provide at least 2 non-empty options.'); return }
    if (newQ.correctIndex >= opts.length) { setQError('The correct answer index is outside the option list.'); return }
    setCreating(true)
    try {
      await apiSend('/api/quiz/questions', 'POST', { ...newQ, options: opts })
      setNewQ({ question: '', options: ['', '', '', ''], correctIndex: 0, explanation: '', category: newQ.category, difficulty: newQ.difficulty })
      const d = await apiGet<{ questions: QT[] }>(`/api/admin/questions${qCat ? `?category=${qCat}` : ''}`)
      setQuestions(d.questions)
      apiGet<AdminStats>('/api/admin/stats').then(setStats).catch(() => {})
    } catch (e) { setQError(e instanceof Error ? e.message : 'Failed to create question.') }
    setCreating(false)
  }

  const deleteQuestion = async (id: string) => {
    if (!window.confirm('Delete this question permanently?')) return
    try {
      await apiSend(`/api/admin/questions?id=${id}`, 'DELETE')
      setQuestions((qs) => (qs || []).filter((q) => q.id !== id))
    } catch { /* silent */ }
  }

  return (
    <div className="view-enter mx-auto max-w-7xl px-4 sm:px-6 py-10">
      <div className="flex items-center gap-3 mb-2">
        <span className="h-11 w-11 rounded-xl bg-[#2F3625] flex items-center justify-center"><ShieldCheck className="h-6 w-6 text-[#CCD5AE]" /></span>
        <div>
          <h1 className="font-display text-3xl font-semibold text-[#2F3625]">Admin Dashboard</h1>
          <p className="text-xs text-[#6B7052]">Role-based access enforced server-side · signed in as {user.email}</p>
        </div>
      </div>

      <Tabs defaultValue="overview" className="mt-6">
        <TabsList className="flex-wrap h-auto gap-1 bg-[#E9EDC9] p-1.5 rounded-xl mb-6 justify-start">
          <TabsTrigger value="overview" className="text-xs font-semibold rounded-lg">Overview</TabsTrigger>
          <TabsTrigger value="reports" className="text-xs font-semibold rounded-lg">Reports {reports && reports.length > 0 ? `(${reports.length})` : ''}</TabsTrigger>
          <TabsTrigger value="questions" className="text-xs font-semibold rounded-lg">Quiz Bank</TabsTrigger>
          <TabsTrigger value="users" className="text-xs font-semibold rounded-lg">Users</TabsTrigger>
        </TabsList>

        {/* ============ OVERVIEW ============ */}
        <TabsContent value="overview">
          {stats === null ? (
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">{Array.from({ length: 8 }).map((_, i) => <Skeleton key={i} className="h-28 rounded-xl" />)}</div>
          ) : (
            <>
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                {[
                  { icon: Users, label: 'Registered users', v: stats.counts.users },
                  { icon: FileSearch, label: 'Lessons', v: stats.counts.lessons },
                  { icon: HelpCircle, label: 'Quiz questions', v: stats.counts.questions },
                  { icon: MessagesSquare, label: 'Community posts', v: stats.counts.posts },
                  { icon: ShieldCheck, label: 'Scam scans', v: stats.counts.scans },
                  { icon: Award, label: 'Active certificates', v: stats.counts.certificates },
                  { icon: Target, label: 'Quiz attempts', v: stats.counts.attempts },
                  { icon: CheckCircle2, label: 'QR verifications', v: stats.counts.verifications },
                ].map((s) => (
                  <div key={s.label} className="card-lux p-5">
                    <s.icon className="h-5 w-5 text-[#B08968] mb-2" />
                    <p className="font-display text-2xl font-semibold text-[#2F3625]">{s.v}</p>
                    <p className="text-xs font-semibold uppercase tracking-wider text-[#6B7052]">{s.label}</p>
                  </div>
                ))}
              </div>

              <div className="grid lg:grid-cols-2 gap-5 mt-6">
                <div className="card-lux p-6">
                  <h3 className="font-display font-semibold text-[#2F3625] mb-3">Quiz attempts by category</h3>
                  {stats.attemptBreakdown.length === 0 ? (
                    <p className="text-sm text-[#9B9F7E]">No attempts recorded yet.</p>
                  ) : (
                    <div className="space-y-2.5">
                      {stats.attemptBreakdown.map((a) => (
                        <div key={a.category}>
                          <div className="flex justify-between text-xs mb-1">
                            <span className="font-semibold text-[#2F3625] capitalize">{a.category.replace('-', ' ')}</span>
                            <span className="text-[#6B7052]">{a._count.category} attempts · avg {Math.round(a._avg.percent || 0)}%</span>
                          </div>
                          <div className="h-2 rounded-full bg-[#E3DEC4] overflow-hidden">
                            <div className="h-full bg-[#8F9779] rounded-full" style={{ width: `${Math.min(100, a._count.category * 4)}%` }} />
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
                <div className="card-lux p-6">
                  <h3 className="font-display font-semibold text-[#2F3625] mb-3">Newest users</h3>
                  <div className="space-y-2">
                    {stats.recentUsers.map((u) => (
                      <div key={u.id} className="flex items-center justify-between bg-[#F4F0DB] rounded-lg px-3.5 py-2">
                        <div className="min-w-0">
                          <p className="text-sm font-semibold text-[#2F3625] truncate">{u.name} {u.role === 'ADMIN' && <span className="badge-sage badge-soft !text-[0.58rem] !py-0 ml-1">admin</span>}</p>
                          <p className="text-[0.68rem] text-[#6B7052] truncate">{u.email} · {fmtDate(u.createdAt)}</p>
                        </div>
                        {u.banned && <span className="badge-soft bg-[#F6DAD5] text-[#8C3B31] border-[#DCA093] !text-[0.6rem] shrink-0">banned</span>}
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </>
          )}
        </TabsContent>

        {/* ============ REPORTS ============ */}
        <TabsContent value="reports">
          <div className="card-lux p-6">
            <h3 className="font-display font-semibold text-[#2F3625] mb-1">Reported community posts</h3>
            <p className="text-xs text-[#6B7052] mb-4">Review, dismiss, or remove content. Actions are logged against the report record.</p>
            {reports === null ? <Skeleton className="h-32 rounded-lg" /> : reports.length === 0 ? (
              <p className="text-sm text-[#6B7052] py-8 text-center">No open reports. The community is behaving. 🌿</p>
            ) : (
              <div className="space-y-4">
                {reports.map((r) => (
                  <div key={r.id} className={`border rounded-xl p-4 ${r.status === 'OPEN' ? 'border-[#DCA093] bg-[#FBF3F0]' : 'border-[#E3DEC4] bg-[#F4F0DB] opacity-70'}`}>
                    <div className="flex flex-wrap items-center gap-2 mb-2">
                      <span className="badge-soft bg-[#F6DAD5] text-[#8C3B31] border-[#DCA093] capitalize">{r.reason}</span>
                      <span className={`badge-soft !text-[0.6rem] ${r.status === 'OPEN' ? 'badge-bronze' : ''}`}>{r.status}</span>
                      <span className="text-[0.65rem] text-[#9B9F7E]">reported by {r.user.name} · {timeAgo(r.createdAt)}</span>
                    </div>
                    <p className="text-sm text-[#3A4229] bg-[#FFFDF2] rounded-lg p-3 border border-[#EFEAD2] whitespace-pre-wrap">{r.post.content.slice(0, 400)}{r.post.content.length > 400 ? '…' : ''}</p>
                    <p className="text-[0.65rem] text-[#9B9F7E] mt-1.5">post author: {r.post.user.name} ({r.post.user.email}) · posted {timeAgo(r.post.createdAt)}</p>
                    {r.status === 'OPEN' && (
                      <div className="flex flex-wrap gap-2 mt-3">
                        <Button size="sm" variant="outline" className="border-[#B4C18B] font-semibold" onClick={() => handleReport(r.id, 'dismiss')}>
                          <XCircle className="h-3.5 w-3.5 mr-1" /> Dismiss
                        </Button>
                        <Button size="sm" variant="outline" className="border-[#DCA093] text-[#A94438] hover:bg-[#F7E2DE] font-semibold" onClick={() => handleReport(r.id, 'resolve', true)}>
                          <Trash2 className="h-3.5 w-3.5 mr-1" /> Resolve & delete post
                        </Button>
                        <Button size="sm" variant="ghost" className="text-[#4C5B2E] font-semibold" onClick={() => handleReport(r.id, 'resolve')}>
                          <CheckCircle2 className="h-3.5 w-3.5 mr-1" /> Resolve (keep post)
                        </Button>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        </TabsContent>

        {/* ============ QUESTIONS ============ */}
        <TabsContent value="questions">
          <div className="grid lg:grid-cols-2 gap-6">
            {/* add question */}
            <div className="card-lux p-6">
              <h3 className="font-display font-semibold text-[#2F3625] mb-4 flex items-center gap-2"><Plus className="h-4 w-4 text-[#B08968]" /> Add quiz question</h3>
              <div className="space-y-3">
                <Textarea placeholder="Question text…" value={newQ.question} onChange={(e) => setNewQ((q) => ({ ...q, question: e.target.value }))} className="bg-[#FFFDF2] min-h-16" />
                {newQ.options.map((o, i) => (
                  <div key={i} className="flex items-center gap-2">
                    <button onClick={() => setNewQ((q) => ({ ...q, correctIndex: i }))}
                      title="Mark as correct answer"
                      className={`h-8 w-8 rounded-full border text-xs font-bold shrink-0 ${newQ.correctIndex === i ? 'border-[#8F9779] bg-[#CCD5AE] text-[#3A4229]' : 'border-[#D8D2B4] text-[#9B9F7E]'}`}>
                      {String.fromCharCode(65 + i)}
                    </button>
                    <Input value={o} onChange={(e) => setNewQ((q) => {
                      const options = [...q.options]; options[i] = e.target.value; return { ...q, options }
                    })} placeholder={`Option ${i + 1}${newQ.correctIndex === i ? ' (correct)' : ''}`} className="bg-[#FFFDF2] h-9" />
                  </div>
                ))}
                <Input placeholder="Explanation shown after answering…" value={newQ.explanation} onChange={(e) => setNewQ((q) => ({ ...q, explanation: e.target.value }))} className="bg-[#FFFDF2]" />
                <div className="flex gap-2">
                  <select value={newQ.category} onChange={(e) => setNewQ((q) => ({ ...q, category: e.target.value }))} className="h-9 rounded-md border border-[#E3DEC4] bg-[#FFFDF2] text-sm px-2 flex-1" aria-label="Category">
                    {CATEGORIES.map((c) => <option key={c} value={c}>{c.replace('-', ' ')}</option>)}
                  </select>
                  <select value={newQ.difficulty} onChange={(e) => setNewQ((q) => ({ ...q, difficulty: e.target.value }))} className="h-9 rounded-md border border-[#E3DEC4] bg-[#FFFDF2] text-sm px-2 flex-1" aria-label="Difficulty">
                    {DIFFS.map((d) => <option key={d} value={d}>{d}</option>)}
                  </select>
                </div>
                {qError && <p className="text-sm text-[#A94438]">{qError}</p>}
                <Button className="btn-bronze w-full font-semibold" onClick={createQuestion} disabled={creating}>{creating ? 'Saving…' : 'Add question to bank'}</Button>
                <p className="text-[0.68rem] text-[#8B8F6E]">Click a letter circle to mark the correct answer. Questions are served randomly per quiz run.</p>
              </div>
            </div>

            {/* question list */}
            <div className="card-lux p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-display font-semibold text-[#2F3625]">Question bank</h3>
                <select value={qCat} onChange={(e) => setQCat(e.target.value)} className="h-8 rounded-md border border-[#E3DEC4] bg-[#FFFDF2] text-xs px-2" aria-label="Filter by category">
                  <option value="">All categories</option>
                  {CATEGORIES.map((c) => <option key={c} value={c}>{c.replace('-', ' ')}</option>)}
                </select>
              </div>
              {questions === null ? <Skeleton className="h-64 rounded-lg" /> : questions.length === 0 ? (
                <p className="text-sm text-[#6B7052] py-8 text-center">No questions in this filter.</p>
              ) : (
                <div className="space-y-2.5 max-h-[32rem] overflow-y-auto nice-scroll">
                  {questions.map((q) => (
                    <div key={q.id} className="border border-[#E3DEC4] rounded-lg p-3.5 bg-[#FFFDF2]">
                      <div className="flex items-start justify-between gap-2">
                        <p className="text-sm font-semibold text-[#2F3625] leading-snug">{q.question}</p>
                        <button onClick={() => deleteQuestion(q.id)} className="p-1.5 rounded-md hover:bg-[#F7E2DE] text-[#A94438] shrink-0" aria-label="Delete question"><Trash2 className="h-3.5 w-3.5" /></button>
                      </div>
                      <p className="text-xs text-[#4C5B2E] mt-1.5">✓ {q.options[q.correctIndex]}</p>
                      <div className="flex gap-1.5 mt-2">
                        <span className="badge-soft !text-[0.58rem] !py-0">{q.category}</span>
                        <span className="badge-soft !text-[0.58rem] !py-0 capitalize">{q.difficulty}</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </TabsContent>

        {/* ============ USERS ============ */}
        <TabsContent value="users">
          <div className="card-lux p-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
              <h3 className="font-display font-semibold text-[#2F3625]">User management</h3>
              <div className="flex gap-2">
                <Input value={userQ} onChange={(e) => setUserQ(e.target.value)} placeholder="Search name or email…" className="h-9 bg-[#FFFDF2] w-56" />
                <Button size="sm" variant="outline" className="border-[#B4C18B] font-semibold"
                  onClick={() => apiGet<{ users: UserT[] }>(`/api/admin/users${userQ ? `?q=${encodeURIComponent(userQ)}` : ''}`).then((d) => setUsers(d.users))}>
                  Search
                </Button>
              </div>
            </div>
            {users === null ? <Skeleton className="h-64 rounded-lg" /> : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="text-left text-xs text-[#6B7052] border-b border-[#E3DEC4]">
                      <th className="py-2.5 font-semibold">User</th><th className="font-semibold">Role</th><th className="font-semibold">Joined</th><th className="font-semibold">Status</th><th className="font-semibold text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {(users || []).map((u) => (
                      <tr key={u.id} className="border-b border-[#F0EBD5]">
                        <td className="py-2.5">
                          <p className="font-semibold text-[#2F3625]">{u.name}</p>
                          <p className="text-xs text-[#6B7052]">{u.email}</p>
                        </td>
                        <td>
                          <span className={`badge-soft !text-[0.62rem] ${u.role === 'ADMIN' ? 'badge-sage' : ''}`}>{u.role}</span>
                        </td>
                        <td className="text-xs text-[#6B7052]">{fmtDate(u.createdAt)}</td>
                        <td>
                          {u.banned ? <span className="badge-soft bg-[#F6DAD5] text-[#8C3B31] border-[#DCA093] !text-[0.6rem]">banned</span>
                            : <span className="badge-soft badge-sage !text-[0.6rem]">active</span>}
                        </td>
                        <td className="text-right">
                          {u.id !== user.id && (
                            <div className="flex justify-end gap-1.5">
                              <button onClick={() => userAction(u.id, u.role === 'ADMIN' ? 'demote' : 'promote')}
                                className="p-1.5 rounded-md hover:bg-[#F2EBD4] text-[#55613F]" title={u.role === 'ADMIN' ? 'Demote to user' : 'Promote to admin'}>
                                {u.role === 'ADMIN' ? <ChevronDown className="h-4 w-4" /> : <ChevronUp className="h-4 w-4" />}
                              </button>
                              <button onClick={() => userAction(u.id, u.banned ? 'unban' : 'ban')}
                                className={`p-1.5 rounded-md ${u.banned ? 'hover:bg-[#E7EDD3] text-[#4C5B2E]' : 'hover:bg-[#F7E2DE] text-[#A94438]'}`} title={u.banned ? 'Unban' : 'Ban'}>
                                {u.banned ? <CheckCircle2 className="h-4 w-4" /> : <Ban className="h-4 w-4" />}
                              </button>
                            </div>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
            <p className="text-[0.68rem] text-[#8B8F6E] mt-4">Role and ban changes take effect immediately on the backend (banned users are rejected at authentication).</p>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}

interface AdminStats {
  counts: { users: number; lessons: number; questions: number; posts: number; scans: number; certificates: number; openReports: number; attempts: number; verifications: number }
  recentUsers: UserT[]
  attemptBreakdown: { category: string; _count: { category: number }; _avg: { percent: number | null } }[]
  postCategoryBreakdown: unknown[]
}
interface ReportT { id: string; reason: string; status: string; createdAt: string; user: { name: string }; post: { id: string; content: string; createdAt: string; user: { name: string; email: string } } }
interface UserT { id: string; name: string; email: string; role: string; banned: boolean; emailVerified: boolean; createdAt: string }
interface QT { id: string; category: string; difficulty: string; question: string; options: string[]; correctIndex: number; explanation: string }
