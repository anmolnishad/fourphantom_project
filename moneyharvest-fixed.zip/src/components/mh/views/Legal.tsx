'use client'

import type { ReactNode } from 'react'

// Set NEXT_PUBLIC_CONTACT_EMAIL and NEXT_PUBLIC_GRIEVANCE_OFFICER in your environment before launch.
export const CONTACT_EMAIL = process.env.NEXT_PUBLIC_CONTACT_EMAIL || 'add-contact-email@example.com'
export const GRIEVANCE_OFFICER = process.env.NEXT_PUBLIC_GRIEVANCE_OFFICER || '[Grievance Officer name — to be added]'
const LAST_UPDATED = '1 November 2026'

function LegalShell({ title, children }: { title: string; children: ReactNode }) {
  return (
    <div className="mx-auto max-w-3xl px-4 sm:px-6 py-12 view-enter">
      <h1 className="font-display text-3xl sm:text-4xl font-semibold text-[#2F3625]">{title}</h1>
      <p className="text-xs text-[#6B7052] mt-2">Last updated: {LAST_UPDATED}</p>
      <div className="mt-8 space-y-4 text-[15px] leading-relaxed text-[#3D4630]">{children}</div>
    </div>
  )
}

function H({ children }: { children: ReactNode }) {
  return <h2 className="font-display text-xl font-semibold text-[#2F3625] pt-4">{children}</h2>
}

export function Privacy() {
  return (
    <LegalShell title="Privacy Policy">
      <p>Money Harvest is a financial-education platform. This policy explains what personal data we collect, why, and the choices you have. It is written to align with the Digital Personal Data Protection Act, 2023 (India).</p>
      <H>1. Data we collect</H>
      <ul className="list-disc pl-6 space-y-1">
        <li>Account details: name, email address, and a password stored only as a one-way (bcrypt) hash.</li>
        <li>Learning activity: lesson progress, bookmarks, quiz attempts and scores, learning goals, and certificates issued.</li>
        <li>Community content: posts, comments, likes, and reports you create.</li>
        <li>Scam checks: text you submit for analysis. Sensitive-looking values such as OTPs, PINs and card numbers are masked before storage.</li>
        <li>AI assistant messages you send, used to generate a reply.</li>
        <li>Technical data: a session cookie required for sign-in, and IP addresses used only for rate limiting and abuse prevention.</li>
      </ul>
      <H>2. How we use data</H>
      <p>To provide the service, track your progress, issue and verify certificates, prevent spam and abuse, moderate community content, and improve our educational material. We do not sell your personal data.</p>
      <H>3. Cookies</H>
      <p>We use one essential, httpOnly session cookie (<code>mh_session</code>) to keep you signed in. We do not use advertising cookies.</p>
      <H>4. Service providers</H>
      <p>We share data only with providers needed to run the service, such as hosting and the AI service that generates assistant replies. Chat messages sent to the assistant are processed by that provider.</p>
      <H>5. Retention and deletion</H>
      <p>We keep your data while your account is active. You can ask us to delete your account and associated data by contacting us (see Contact &amp; Grievance). Some records, such as certificate verification logs, may be kept where required by law.</p>
      <H>6. Your rights</H>
      <p>You may request access to, correction of, or erasure of your personal data, withdraw consent, and raise a grievance with our Grievance Officer. We will respond within the timeline required by applicable law.</p>
      <H>7. Children</H>
      <p>Money Harvest is not intended for children under 18 without the involvement of a parent or guardian. If you believe a child has provided personal data to us, please contact us so we can remove it.</p>
      <H>8. Security</H>
      <p>We use reasonable technical and organisational safeguards. No online service can be guaranteed to be completely secure.</p>
      <H>9. Changes</H>
      <p>We may update this policy. The date at the top shows when it was last revised.</p>
      <H>10. Grievance Officer</H>
      <p>{GRIEVANCE_OFFICER} · <a className="underline" href={`mailto:${CONTACT_EMAIL}`}>{CONTACT_EMAIL}</a></p>
    </LegalShell>
  )
}

export function Terms() {
  return (
    <LegalShell title="Terms of Use">
      <p>By creating an account or using Money Harvest, you agree to these terms. If you do not agree, please do not use the service.</p>
      <H>1. Educational purpose</H>
      <p>All content, calculators, quizzes and tools are for educational purposes only. They are not investment, legal, tax or financial advice. Please read the <a className="underline" href="#/disclaimer">Disclaimer</a>.</p>
      <H>2. Accounts</H>
      <p>You are responsible for keeping your login details confidential and for all activity under your account. Provide accurate information and tell us promptly if you suspect unauthorised use.</p>
      <H>3. Community rules</H>
      <p>Do not post content that is abusive, harassing, fraudulent, spammy, impersonating another person or organisation, or that shares someone else’s private information. We may remove content and suspend accounts that break these rules.</p>
      <H>4. Your content</H>
      <p>You keep ownership of the content you post. By posting, you allow us to store and display it within the platform so that it can be shown to other users.</p>
      <H>5. Certificates</H>
      <p>Certificates issued by Money Harvest are platform completion records. They are not government-, university- or accreditation-body qualifications.</p>
      <H>6. Our content</H>
      <p>The lessons, quizzes, design and software belong to Money Harvest or its licensors. You may use them for personal learning but not copy or resell them without permission.</p>
      <H>7. Disclaimers and liability</H>
      <p>The service is provided “as is”. To the maximum extent permitted by law, Money Harvest is not liable for losses arising from reliance on the platform’s content or tools.</p>
      <H>8. Termination</H>
      <p>We may suspend or end access if these terms are violated. You may stop using the service and request account deletion at any time.</p>
      <H>9. Governing law</H>
      <p>These terms are governed by the laws of India. Courts in India have jurisdiction over disputes.</p>
      <H>10. Changes</H>
      <p>We may update these terms. Continued use after an update means you accept the revised terms.</p>
    </LegalShell>
  )
}

export function Disclaimer() {
  return (
    <LegalShell title="Disclaimer">
      <H>Educational content only</H>
      <p>Lessons, articles and quizzes are general educational material. They do not take your personal financial situation into account. Consult a SEBI-registered investment adviser, a qualified tax professional or a lawyer before making decisions.</p>
      <H>Calculators</H>
      <p>Calculator results (SIP, FD, RD, EMI, compound growth, inflation and others) are hypothetical estimates based on the inputs you provide. Market returns vary and past performance does not guarantee future results.</p>
      <H>Scam Detector</H>
      <p>The scam detector uses heuristic, rule-based analysis. It can miss scams and can flag legitimate messages. A result is not a guarantee that something is safe or fraudulent. Never share OTPs, PINs or passwords with anyone.</p>
      <H>AI Assistant</H>
      <p>The AI assistant can make mistakes. Verify important information with official sources.</p>
      <H>Certificates</H>
      <p>Platform certificates are educational completion records, not accredited qualifications.</p>
      <H>External links</H>
      <p>We link to third-party websites for convenience. We do not control or endorse their content.</p>
      <H>Report fraud</H>
      <p>If you have been a victim of cyber fraud in India, call the national helpline <strong>1930</strong> or report at <a className="underline" href="https://cybercrime.gov.in" target="_blank" rel="noopener noreferrer">cybercrime.gov.in</a>.</p>
    </LegalShell>
  )
}

export function Contact() {
  return (
    <LegalShell title="Contact & Grievance">
      <p>For general questions, account help, or data requests, email us at <a className="underline font-semibold" href={`mailto:${CONTACT_EMAIL}`}>{CONTACT_EMAIL}</a>.</p>
      <H>Grievance Officer</H>
      <p>As required under the Information Technology Act, 2000 and the DPDP Act, 2023, grievances about personal data can be sent to:</p>
      <p className="font-semibold">{GRIEVANCE_OFFICER}</p>
      <p>We aim to acknowledge grievances within 48 hours and resolve them within the timeline required by law.</p>
      <H>Reporting a scam</H>
      <p>For active fraud, call <strong>1930</strong> or visit <a className="underline" href="https://cybercrime.gov.in" target="_blank" rel="noopener noreferrer">cybercrime.gov.in</a>. Money Harvest cannot block transactions or recover money.</p>
    </LegalShell>
  )
}
