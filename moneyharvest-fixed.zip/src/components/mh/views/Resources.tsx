'use client'

import { useEffect, useState } from 'react'
import { navigate, apiGet, apiSend } from './../router'
import { useApp } from './../store'
import { Button } from '@/components/ui/button'
import { Skeleton } from '@/components/ui/skeleton'
import {
  BookOpenCheck, ExternalLink, Bookmark, BookmarkCheck, GraduationCap,
  Building2, ShieldCheck, ScanSearch, Landmark, Cpu, Library,
} from 'lucide-react'

const CATS = [
  { key: '', label: 'All', icon: Library },
  { key: 'financial-literacy', label: 'Financial Literacy', icon: BookOpenCheck },
  { key: 'investment', label: 'Investment Fundamentals', icon: GraduationCap },
  { key: 'cybersecurity', label: 'Cybersecurity', icon: ShieldCheck },
  { key: 'scam-prevention', label: 'Online Scam Prevention', icon: ScanSearch },
  { key: 'banking-digital-payments', label: 'Banking & Digital Payments', icon: Landmark },
  { key: 'ai-technology', label: 'AI & Technology', icon: Cpu },
]

interface Res {
  id: string; title: string; description: string; url: string
  category: string; level: string; source: string
}

export function Resources() {
  const { user } = useApp()
  const [cat, setCat] = useState('')
  const [resources, setResources] = useState<Res[] | null>(null)
  const [bookmarks, setBookmarks] = useState<Set<string>>(new Set())

  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect -- reset to skeleton while loading new filter
    setResources(null)
    apiGet<{ resources: Res[] }>(`/api/resources${cat ? `?category=${cat}` : ''}`)
      .then((d) => setResources(d.resources))
      .catch(() => setResources([]))
  }, [cat])

  useEffect(() => {
    if (!user) { setBookmarks(new Set()); return } // eslint-disable-line react-hooks/set-state-in-effect -- reset when signed out
    apiGet<{ bookmarks: { kind: string; refId: string }[] }>('/api/bookmarks')
      .then((d) => setBookmarks(new Set(d.bookmarks.filter((b) => b.kind === 'resource').map((b) => b.refId))))
      .catch(() => {})
  }, [user])

  const toggleBookmark = async (r: Res) => {
    if (!user) { navigate('/signin'); return }
    const next = new Set(bookmarks)
    if (next.has(r.id)) next.delete(r.id); else next.add(r.id)
    setBookmarks(next)
    try { await apiSend('/api/bookmarks', 'POST', { kind: 'resource', refId: r.id, label: r.title }) } catch { /* silent */ }
  }

  return (
    <div className="view-enter mx-auto max-w-6xl px-4 sm:px-6 py-10">
      <span className="badge-soft badge-sage mb-3"><Library className="h-3.5 w-3.5" /> Courses & Resources</span>
      <h1 className="font-display text-3xl sm:text-4xl font-semibold text-[#2F3625]">Curated external learning library</h1>
      <p className="mt-2 text-[#55613F] max-w-2xl leading-relaxed">
        Hand-picked resources from official institutions and reputable educators — each with a short explanation and difficulty level. Internal lesson progress is tracked automatically; external course completion is not tracked by Money Harvest.
      </p>

      <div className="flex flex-wrap gap-2 mt-8">
        {CATS.map((c) => (
          <button key={c.key} onClick={() => setCat(c.key)}
            className={`flex items-center gap-1.5 text-xs font-semibold px-3.5 py-2 rounded-full border transition-colors ${cat === c.key ? 'btn-bronze' : 'bg-[#FFFDF2] border-[#E3DEC4] text-[#55613F] hover:bg-[#F2EBD4]'}`}>
            <c.icon className="h-3.5 w-3.5" /> {c.label}
          </button>
        ))}
      </div>

      {resources === null ? (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5 mt-8">
          {Array.from({ length: 6 }).map((_, i) => <Skeleton key={i} className="h-44 rounded-xl" />)}
        </div>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5 mt-8">
          {resources.map((r) => (
            <div key={r.id} className="card-lux p-5 flex flex-col">
              <div className="flex items-start justify-between gap-2 mb-2">
                <span className="badge-soft">{CATS.find((c) => c.key === r.category)?.label || r.category}</span>
                <button onClick={() => toggleBookmark(r)} disabled={!user}
                  className={`p-1.5 rounded-md transition-colors ${bookmarks.has(r.id) ? 'text-[#B08968]' : 'text-[#9B9F7E] hover:text-[#B08968] disabled:opacity-40'}`}
                  aria-label={bookmarks.has(r.id) ? 'Remove bookmark' : 'Bookmark resource'}>
                  {bookmarks.has(r.id) ? <BookmarkCheck className="h-4 w-4" /> : <Bookmark className="h-4 w-4" />}
                </button>
              </div>
              <h3 className="font-display font-semibold text-[#2F3625] leading-snug">{r.title}</h3>
              <p className="text-sm text-[#55613F] mt-1.5 leading-relaxed flex-1">{r.description}</p>
              <div className="mt-4 flex items-center justify-between">
                <span className="text-xs text-[#6B7052] flex items-center gap-1"><Building2 className="h-3 w-3" /> {r.source} · {r.level}</span>
                <a href={r.url} target="_blank" rel="noopener noreferrer"
                  className="inline-flex items-center gap-1 text-sm font-semibold link-quiet">
                  Visit <ExternalLink className="h-3.5 w-3.5" />
                </a>
              </div>
            </div>
          ))}
        </div>
      )}

      <div className="mt-10 card-lux p-5 bg-[#FAEDCD] border-[#EAD8B6] text-sm text-[#5A5030] leading-relaxed">
        <strong>A note on external links:</strong> these point to official institutions (RBI, SEBI, NPCI, Government of India portals) and established educational bodies. External content is owned by its publishers — Money Harvest doesn’t track your progress on external courses. For tracked learning with certificates, use our internal <button className="link-quiet underline font-semibold" onClick={() => navigate('/education')}>lessons</button> and <button className="link-quiet underline font-semibold" onClick={() => navigate('/quiz')}>quizzes</button>.
      </div>
    </div>
  )
}
