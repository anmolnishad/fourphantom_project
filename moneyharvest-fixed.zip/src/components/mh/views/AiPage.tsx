'use client'

import { useEffect, useRef, useState } from 'react'
import { fmtTime } from './../router'
import { Button } from '@/components/ui/button'
import { RotateCcw, SendHorizonal, Loader2, Leaf, ShieldAlert, Info } from 'lucide-react'

interface Msg { id: string; role: 'user' | 'assistant'; content: string; ts: string; mode?: string }

const SUGGESTIONS = [
  'How can I start saving money?',
  'Explain SIP in simple language.',
  'What is the difference between FD and RD?',
  'How can I identify investment scams?',
  'How does compound interest work?',
  'What is cybersecurity?',
  'How can I create a monthly budget?',
  'Explain mutual funds for beginners.',
]

let idc = 0
const nid = () => `m${Date.now()}_${idc++}`

function renderContent(text: string) {
  const html = text
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
    .replace(/(^|\s)\*(?!\s)(.+?)\*/g, '$1<em>$2</em>')
    .replace(/\n/g, '<br/>')
  return <span dangerouslySetInnerHTML={{ __html: html }} />
}

export function AiPage() {
  const [msgs, setMsgs] = useState<Msg[]>([
    {
      id: 'welcome', role: 'assistant', ts: '',
      content: 'Namaste! I\u2019m **Harvest AI** \uD83C\uDF3F — your financial-education companion on Money Harvest.\n\nI can help you understand:\n- Saving, budgeting and emergency funds\n- SIP, mutual funds, FD/RD and compounding\n- Banking, credit and digital payments\n- Cybersecurity and scam awareness\n\nI teach concepts — I never give personalised investment advice, never recommend specific products, and never guarantee returns.',
    },
  ])
  const [input, setInput] = useState('')
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const scrollRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' })
  }, [msgs, busy])

  const send = async (text: string) => {
    const clean = text.trim()
    if (!clean || busy) return
    setError('')
    const userMsg: Msg = { id: nid(), role: 'user', content: clean, ts: new Date().toISOString() }
    const next = [...msgs, userMsg]
    setMsgs(next)
    setInput('')
    setBusy(true)
    try {
      const res = await fetch('/api/chat', {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, credentials: 'include',
        body: JSON.stringify({ messages: next.filter((m) => m.id !== 'welcome').map((m) => ({ role: m.role, content: m.content })) }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error || 'The assistant is unavailable right now.')
      setMsgs((m) => [...m, { id: nid(), role: 'assistant', content: data.reply, ts: new Date().toISOString(), mode: data.mode }])
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Something went wrong.')
    } finally { setBusy(false) }
  }

  return (
    <div className="view-enter mx-auto max-w-3xl px-4 sm:px-6 py-10">
      <div className="text-center mb-6">
        <span className="inline-flex h-14 w-14 rounded-2xl bg-[#CCD5AE] border border-[#B4C18B] items-center justify-center mb-3">
          <Leaf className="h-7 w-7 text-[#4C5B2E]" />
        </span>
        <h1 className="font-display text-3xl sm:text-4xl font-semibold text-[#2F3625]">Harvest AI</h1>
        <p className="text-[#55613F] mt-2 max-w-xl mx-auto">
          Your financial-education assistant. Ask questions, get clear explanations — conversation context is maintained for your whole session.
        </p>
      </div>

      <div className="card-lux overflow-hidden">
        <div className="flex items-center justify-between px-5 py-3.5 bg-[#E9EDC9] border-b border-[#D8DCBB]">
          <div className="flex items-center gap-2.5">
            <span className="h-8 w-8 rounded-full bg-[#CCD5AE] border border-[#B4C18B] flex items-center justify-center"><Leaf className="h-4 w-4 text-[#4C5B2E]" /></span>
            <div>
              <p className="font-display font-semibold text-sm text-[#2F3625]">Harvest AI</p>
              <p className="text-[0.65rem] text-[#6B7052]">Educational assistant · session context enabled</p>
            </div>
          </div>
          <button onClick={() => setMsgs((m) => m.slice(0, 1))} className="p-1.5 rounded-md hover:bg-[#DDE3C0] text-[#55613F]" aria-label="Clear conversation" title="Clear conversation">
            <RotateCcw className="h-4 w-4" />
          </button>
        </div>

        <div ref={scrollRef} className="h-[30rem] overflow-y-auto nice-scroll px-4 py-4 space-y-3.5 bg-[#FAF6E2]">
          {msgs.map((m) => (
            <div key={m.id} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
              <div className={`max-w-[85%] rounded-2xl px-4 py-3 text-[0.9rem] leading-relaxed ${
                m.role === 'user' ? 'bg-[#8F6B44] text-[#FFF6E3] rounded-br-md' : 'bg-[#FFFDF2] border border-[#E3DEC4] text-[#2F3625] rounded-bl-md'
              }`}>
                {renderContent(m.content)}
                <div className={`mt-1.5 text-[0.62rem] ${m.role === 'user' ? 'text-[#E8D3B8]' : 'text-[#9B9F7E]'}`}>
                  {m.ts ? fmtTime(m.ts) : null}{m.mode === 'offline-faq' && ' · offline knowledge base'}
                </div>
              </div>
            </div>
          ))}
          {busy && (
            <div className="flex justify-start">
              <div className="bg-[#FFFDF2] border border-[#E3DEC4] rounded-2xl rounded-bl-md px-4 py-3 flex items-center gap-1.5">
                <span className="typing-dot h-2 w-2 rounded-full bg-[#B08968] inline-block" />
                <span className="typing-dot h-2 w-2 rounded-full bg-[#B08968] inline-block" />
                <span className="typing-dot h-2 w-2 rounded-full bg-[#B08968] inline-block" />
              </div>
            </div>
          )}
          {error && (
            <div className="rounded-lg bg-[#F7E2DE] border border-[#E5B9B2] px-3.5 py-2.5 text-sm text-[#8C3B31] flex items-start gap-2">
              <ShieldAlert className="h-4 w-4 shrink-0 mt-0.5" /> {error}
            </div>
          )}
        </div>

        <div className="px-4 pt-3 bg-[#FFFDF2] border-t border-[#EFEAD2]">
          <div className="flex gap-1.5 overflow-x-auto nice-scroll pb-2.5" aria-label="Suggested questions">
            {SUGGESTIONS.map((s) => (
              <button key={s} onClick={() => send(s)} disabled={busy}
                className="shrink-0 text-[0.7rem] font-medium px-3 py-1.5 rounded-full border border-[#D8D2B4] bg-[#F4F0DB] text-[#55613F] hover:bg-[#CCD5AE] hover:border-[#B4C18B] disabled:opacity-50 transition-colors">
                {s}
              </button>
            ))}
          </div>
        </div>

        <form onSubmit={(e) => { e.preventDefault(); send(input) }} className="flex items-center gap-2.5 px-4 py-3 bg-[#FFFDF2] border-t border-[#E3DEC4]">
          <input value={input} onChange={(e) => setInput(e.target.value)}
            placeholder="Ask about money, savings, scams…"
            className="flex-1 h-11 rounded-full border border-[#E3DEC4] bg-[#FAF6E2] px-4 text-sm outline-none focus:border-[#B08968] focus:ring-1 focus:ring-[#B08968]/40"
            aria-label="Chat message" maxLength={1000} />
          <Button type="submit" disabled={busy || !input.trim()} className="btn-bronze h-11 w-11 p-0 rounded-full" aria-label="Send message">
            {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <SendHorizonal className="h-4 w-4" />}
          </Button>
        </form>
        <p className="px-5 pb-3 pt-1.5 text-[0.62rem] text-[#9B9F7E] bg-[#FFFDF2] flex items-center gap-1.5">
          <Info className="h-3 w-3 shrink-0" /> Educational content only — not personalised regulated advice, and no guarantee of investment returns. If the live AI service is unavailable, I clearly answer from a labelled offline knowledge base instead.
        </p>
      </div>
    </div>
  )
}
