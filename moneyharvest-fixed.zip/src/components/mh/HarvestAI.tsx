'use client'

import { useEffect, useRef, useState } from 'react'
import { Button } from '@/components/ui/button'
import { ScrollArea } from '@/components/ui/scroll-area'
import { apiSend, fmtTime } from './router'
import { X, Leaf, RotateCcw, SendHorizonal, Loader2, ShieldAlert } from 'lucide-react'

interface Msg {
  id: string
  role: 'user' | 'assistant'
  content: string
  ts: string
  mode?: string
}

const SUGGESTIONS = [
  'How can I start saving money?',
  'Explain SIP in simple language.',
  'What is the difference between FD and RD?',
  'How can I identify investment scams?',
  'How does compound interest work?',
  'What is cybersecurity?',
  'How can I create a monthly budget?',
  'Explain mutual funds for beginners.',
]

let idc = 0
const nid = () => `m${Date.now()}_${idc++}`

function renderContent(text: string) {
  // tiny markdown: **bold**, *italic*, line breaks, and simple - lists
  const html = text
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
    .replace(/(^|\s)\*(?!\s)(.+?)\*/g, '$1<em>$2</em>')
    .replace(/\n/g, '<br/>')
  return <span dangerouslySetInnerHTML={{ __html: html }} />
}

export function HarvestAI() {
  const [open, setOpen] = useState(false)
  const [msgs, setMsgs] = useState<Msg[]>([
    {
      id: 'welcome',
      role: 'assistant',
      content: 'Namaste! I\u2019m **Harvest AI** \uD83C\uDF3F — your financial-education companion.\n\nAsk me about saving, budgeting, investing concepts, banking, UPI safety or scam awareness. I teach concepts — I never give personalised investment advice or guarantee returns.',
      ts: '',
    },
  ])
  const [input, setInput] = useState('')
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const scrollRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' })
  }, [msgs, busy, open])

  const send = async (text: string) => {
    const clean = text.trim()
    if (!clean || busy) return
    setError('')
    const userMsg: Msg = { id: nid(), role: 'user', content: clean, ts: new Date().toISOString() }
    const nextMsgs = [...msgs, userMsg]
    setMsgs(nextMsgs)
    setInput('')
    setBusy(true)
    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({
          messages: nextMsgs.filter((m) => m.id !== 'welcome').map((m) => ({ role: m.role, content: m.content })),
        }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error || 'The assistant is unavailable right now.')
      setMsgs((m) => [...m, { id: nid(), role: 'assistant', content: data.reply, ts: new Date().toISOString(), mode: data.mode }])
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Something went wrong. Please try again.')
    } finally {
      setBusy(false)
    }
  }

  const clearChat = () => {
    setMsgs([{ id: 'welcome', role: 'assistant', content: 'Fresh start! What would you like to learn about today?', ts: new Date().toISOString() }])
    setError('')
  }

  return (
    <>
      {/* Floating toggle */}
      <button
        onClick={() => setOpen((o) => !o)}
        aria-label={open ? 'Close Harvest AI chat' : 'Open Harvest AI chat'}
        className="fixed bottom-5 right-5 z-40 h-14 w-14 rounded-full btn-bronze flex items-center justify-center shadow-xl hover:scale-105 transition-transform"
      >
        {open ? <X className="h-6 w-6" /> : <Leaf className="h-6 w-6" />}
        {!open && (
          <span className="absolute -top-1 -right-1 h-4 w-4 rounded-full bg-[#CCD5AE] border-2 border-[#8F6B44] animate-pulse" aria-hidden />
        )}
      </button>

      {/* Chat panel */}
      {open && (
        <div className="fixed bottom-22 right-4 sm:right-5 z-40 w-[calc(100vw-2rem)] sm:w-96 max-w-[26rem] rounded-2xl border border-[#E3DEC4] bg-[#FFFDF2] shadow-2xl overflow-hidden view-enter"
          style={{ bottom: '5.5rem' }}
          role="dialog" aria-label="Harvest AI chat">
          {/* header */}
          <div className="flex items-center justify-between px-4 py-3 bg-[#E9EDC9] border-b border-[#D8DCBB]">
            <div className="flex items-center gap-2.5">
              <span className="h-9 w-9 rounded-full bg-[#CCD5AE] border border-[#B4C18B] flex items-center justify-center">
                <Leaf className="h-5 w-5 text-[#4C5B2E]" />
              </span>
              <div>
                <p className="font-display font-semibold text-sm text-[#2F3625]">Harvest AI</p>
                <p className="text-[0.68rem] text-[#6B7052]">Financial education assistant</p>
              </div>
            </div>
            <button onClick={clearChat} className="p-1.5 rounded-md hover:bg-[#DDE3C0] text-[#55613F]" aria-label="Clear conversation" title="Clear conversation">
              <RotateCcw className="h-4 w-4" />
            </button>
          </div>

          {/* messages */}
          <div ref={scrollRef} className="h-[26rem] sm:h-[30rem] overflow-y-auto nice-scroll px-3 py-3 space-y-3 bg-[#FAF6E2]">
            {msgs.map((m) => (
              <div key={m.id} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[85%] rounded-2xl px-3.5 py-2.5 text-[0.83rem] leading-relaxed ${
                  m.role === 'user'
                    ? 'bg-[#8F6B44] text-[#FFF6E3] rounded-br-md'
                    : 'bg-[#FFFDF2] border border-[#E3DEC4] text-[#2F3625] rounded-bl-md'
                }`}>
                  {renderContent(m.content)}
                  <div className={`mt-1 text-[0.6rem] ${m.role === 'user' ? 'text-[#E8D3B8]' : 'text-[#9B9F7E]'}`}>
                    {m.ts ? fmtTime(m.ts) : null}
                    {m.mode === 'offline-faq' && ' · offline knowledge base'}
                  </div>
                </div>
              </div>
            ))}
            {busy && (
              <div className="flex justify-start">
                <div className="bg-[#FFFDF2] border border-[#E3DEC4] rounded-2xl rounded-bl-md px-4 py-3 flex items-center gap-1.5">
                  <span className="typing-dot h-2 w-2 rounded-full bg-[#B08968] inline-block" />
                  <span className="typing-dot h-2 w-2 rounded-full bg-[#B08968] inline-block" />
                  <span className="typing-dot h-2 w-2 rounded-full bg-[#B08968] inline-block" />
                </div>
              </div>
            )}
            {error && (
              <div className="rounded-lg bg-[#F7E2DE] border border-[#E5B9B2] px-3 py-2 text-xs text-[#8C3B31] flex items-start gap-2">
                <ShieldAlert className="h-4 w-4 shrink-0 mt-0.5" />
                <span>{error}</span>
              </div>
            )}
          </div>

          {/* suggestions */}
          <div className="px-3 pt-2 pb-1 bg-[#FFFDF2] border-t border-[#EFEAD2]">
            <div className="flex gap-1.5 overflow-x-auto nice-scroll pb-1.5" aria-label="Suggested questions">
              {SUGGESTIONS.map((s) => (
                <button key={s}
                  onClick={() => send(s)}
                  disabled={busy}
                  className="shrink-0 text-[0.68rem] font-medium px-2.5 py-1.5 rounded-full border border-[#D8D2B4] bg-[#F4F0DB] text-[#55613F] hover:bg-[#CCD5AE] hover:border-[#B4C18B] disabled:opacity-50 transition-colors">
                  {s}
                </button>
              ))}
            </div>
          </div>

          {/* input */}
          <form onSubmit={(e) => { e.preventDefault(); send(input) }} className="flex items-center gap-2 px-3 py-2.5 bg-[#FFFDF2] border-t border-[#E3DEC4]">
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask about money, savings, scams…"
              className="flex-1 h-10 rounded-full border border-[#E3DEC4] bg-[#FAF6E2] px-4 text-sm outline-none focus:border-[#B08968] focus:ring-1 focus:ring-[#B08968]/40"
              aria-label="Chat message"
              maxLength={1000}
            />
            <Button type="submit" disabled={busy || !input.trim()} className="btn-bronze h-10 w-10 p-0 rounded-full" aria-label="Send message">
              {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <SendHorizonal className="h-4 w-4" />}
            </Button>
          </form>
          <p className="px-4 pb-2.5 text-[0.6rem] text-[#9B9F7E] bg-[#FFFDF2]">
            Educational content only — not personalised regulated advice and no guarantee of investment returns.
          </p>
        </div>
      )}
    </>
  )
}
