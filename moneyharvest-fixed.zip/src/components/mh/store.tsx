'use client'

import { createContext, useCallback, useContext, useEffect, useState, type ReactNode } from 'react'
import { apiGet, apiSend } from './router'

export interface MhUser {
  id: string
  email: string
  name: string
  role: string
  bio: string
  avatarColor: string
  emailVerified: boolean
  createdAt: string
}

interface AppState {
  user: MhUser | null
  userLoaded: boolean
  unread: number
  refreshUser: () => Promise<void>
  signOut: () => Promise<void>
  bumpUnread: (n: number) => void
}

const Ctx = createContext<AppState>({
  user: null,
  userLoaded: false,
  unread: 0,
  refreshUser: async () => {},
  signOut: async () => {},
  bumpUnread: () => {},
})

export function AppProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<MhUser | null>(null)
  const [userLoaded, setUserLoaded] = useState(false)
  const [unread, setUnread] = useState(0)

  const refreshUser = useCallback(async () => {
    try {
      const data = await apiGet<{ user: MhUser | null; unreadNotifications?: number }>('/api/auth/me')
      setUser(data.user)
      setUnread(data.unreadNotifications || 0)
    } catch {
      setUser(null)
    } finally {
      setUserLoaded(true)
    }
  }, [])

  const signOut = useCallback(async () => {
    try {
      await apiSend('/api/auth/logout', 'POST')
    } finally {
      setUser(null)
      setUnread(0)
    }
  }, [])

  useEffect(() => {
    refreshUser()
  }, [refreshUser])

  // poll unread notifications lightly
  useEffect(() => {
    if (!user) return
    const t = setInterval(async () => {
      try {
        const d = await apiGet<{ unread: number }>('/api/notifications')
        setUnread(d.unread)
      } catch { /* silent */ }
    }, 60000)
    return () => clearInterval(t)
  }, [user])

  return (
    <Ctx.Provider value={{ user, userLoaded, unread, refreshUser, signOut, bumpUnread: setUnread }}>
      {children}
    </Ctx.Provider>
  )
}

export function useApp() {
  return useContext(Ctx)
}
