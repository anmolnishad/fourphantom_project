'use client'

import { Link } from './router'
import { Logo } from './Logo'

export function Footer() {
  return (
    <footer className="mt-auto border-t border-[#E3DEC4] bg-[#E9EDC9]" style={{ paddingBottom: 'env(safe-area-inset-bottom)' }}>
      <div className="mx-auto max-w-7xl px-4 sm:px-6 py-10">
        <div className="grid gap-8 md:grid-cols-4">
          <div className="md:col-span-1">
            <Logo size={40} />
            <p className="mt-4 text-sm leading-relaxed text-[#55613F] max-w-xs">
              A financial-education platform for building money confidence — with honest lessons, practical tools, and scam awareness that protects what you earn.
            </p>
          </div>

          <nav aria-label="Learn">
            <h3 className="font-display font-semibold text-[#2F3625] mb-3">Learn</h3>
            <ul className="space-y-2 text-sm text-[#55613F]">
              <li><Link className="link-quiet" to="/education">Financial Education</Link></li>
              <li><Link className="link-quiet" to="/cyber">Cybersecurity Hub</Link></li>
              <li><Link className="link-quiet" to="/quiz">Quiz Challenges</Link></li>
              <li><Link className="link-quiet" to="/resources">Courses & Resources</Link></li>
            </ul>
          </nav>

          <nav aria-label="Tools">
            <h3 className="font-display font-semibold text-[#2F3625] mb-3">Tools</h3>
            <ul className="space-y-2 text-sm text-[#55613F]">
              <li><Link className="link-quiet" to="/scam">Scam Detector</Link></li>
              <li><Link className="link-quiet" to="/calculators">Financial Calculators</Link></li>
              <li><Link className="link-quiet" to="/certificates">Certificates</Link></li>
              <li><Link className="link-quiet" to="/community">Community</Link></li>
            </ul>
          </nav>

          <div>
            <h3 className="font-display font-semibold text-[#2F3625] mb-3">Official resources</h3>
            <ul className="space-y-2 text-sm text-[#55613F]">
              <li><a className="link-quiet underline" href="https://cybercrime.gov.in" target="_blank" rel="noopener noreferrer">Cyber Crime Portal · 1930</a></li>
              <li><a className="link-quiet underline" href="https://sancharsaathi.gov.in" target="_blank" rel="noopener noreferrer">Chakshu (Sanchar Saathi)</a></li>
              <li><a className="link-quiet underline" href="https://www.rbi.org.in" target="_blank" rel="noopener noreferrer">Reserve Bank of India</a></li>
              <li><a className="link-quiet underline" href="https://investor.sebi.gov.in" target="_blank" rel="noopener noreferrer">SEBI Investor Education</a></li>
            </ul>
          </div>
        </div>

        <div className="mt-10 pt-6 border-t border-[#D8DCBB] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <p className="text-xs text-[#6B7052] leading-relaxed max-w-2xl">
            Money Harvest provides educational content only. It is not investment, legal, or tax advice, and platform-issued certificates are educational completion records — not government- or university-accredited qualifications. Returns shown in calculators are hypothetical estimates; actual market returns vary.
          </p>
          <div className="shrink-0 flex flex-col items-start sm:items-end gap-2">
            <nav aria-label="Legal" className="flex flex-wrap gap-x-4 gap-y-1 text-xs text-[#55613F]">
              <Link className="link-quiet underline" to="/privacy">Privacy Policy</Link>
              <Link className="link-quiet underline" to="/terms">Terms of Use</Link>
              <Link className="link-quiet underline" to="/disclaimer">Disclaimer</Link>
              <Link className="link-quiet underline" to="/contact">Contact &amp; Grievance</Link>
            </nav>
            <p className="text-xs text-[#6B7052]">© {new Date().getFullYear()} Money Harvest</p>
          </div>
        </div>
      </div>
    </footer>
  )
}
