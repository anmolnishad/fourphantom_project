'use client'

import { useEffect, useState, useCallback, type ReactNode, type MouseEvent } from 'react'

// ---------------------------------------------------------------- hash router

export interface RouteInfo {
  path: string // e.g. "/lesson/sip" (without "#")
  parts: string[] // ["lesson", "sip"]
  query: URLSearchParams
}

function parseHash(): RouteInfo {
  const raw = typeof window === 'undefined' ? '/' : window.location.hash.replace(/^#/, '') || '/'
  const [pathRaw, queryRaw = ''] = raw.split('?')
  const path = pathRaw || '/'
  return {
    path,
    parts: path.split('/').filter(Boolean),
    query: new URLSearchParams(queryRaw),
  }
}

export function navigate(to: string, opts?: { replace?: boolean }) {
  const target = to.startsWith('#') ? to : `#${to}`
  if (opts?.replace) {
    window.history.replaceState(null, '', target)
    window.dispatchEvent(new HashChangeEvent('hashchange'))
  } else {
    window.location.hash = target
  }
}

export function useRoute(): RouteInfo {
  // Start from the server-stable default ("/") so SSR and the first client
  // render match, then sync to the real hash right after mount.
  const [route, setRoute] = useState<RouteInfo>(() => ({ path: '/', parts: [], query: new URLSearchParams() }))
  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect -- required hydration sync of hash state
    setRoute(parseHash())
    const onChange = () => {
      setRoute(parseHash())
      // scroll to top on view change (unless it's an in-page anchor)
      window.scrollTo({ top: 0, behavior: 'auto' })
    }
    window.addEventListener('hashchange', onChange)
    return () => window.removeEventListener('hashchange', onChange)
  }, [])
  return route
}

// ---------------------------------------------------------------- Link

export function Link({ to, children, className, onClick, ariaLabel }: {
  to: string
  children: ReactNode
  className?: string
  onClick?: () => void
  ariaLabel?: string
}) {
  const handle = (e: MouseEvent) => {
    e.preventDefault()
    onClick?.()
    navigate(to)
  }
  return (
    <a href={`#${to}`} onClick={handle} className={className} aria-label={ariaLabel}>
      {children}
    </a>
  )
}

// ---------------------------------------------------------------- fetch helpers

export async function apiGet<T>(url: string): Promise<T> {
  const res = await fetch(url, { credentials: 'include' })
  const data = await res.json().catch(() => ({}))
  if (!res.ok) throw new Error((data as { error?: string }).error || `Request failed (${res.status})`)
  return data as T
}

export async function apiSend<T>(url: string, method: 'POST' | 'PATCH' | 'PUT' | 'DELETE', body?: unknown): Promise<T> {
  const res = await fetch(url, {
    method,
    credentials: 'include',
    headers: { 'Content-Type': 'application/json' },
    body: body === undefined ? undefined : JSON.stringify(body),
  })
  const data = await res.json().catch(() => ({}))
  if (!res.ok) throw new Error((data as { error?: string }).error || `Request failed (${res.status})`)
  return data as T
}

// ---------------------------------------------------------------- misc utils

export function useDebounced<T>(value: T, delay = 300): T {
  const [v, setV] = useState(value)
  useEffect(() => {
    const t = setTimeout(() => setV(value), delay)
    return () => clearTimeout(t)
  }, [value, delay])
  return v
}

export function fmtINR(n: number, maxFrac = 0): string {
  if (!isFinite(n)) return '—'
  return n.toLocaleString('en-IN', { maximumFractionDigits: maxFrac, minimumFractionDigits: 0 })
}

export function fmtCompact(n: number): string {
  if (!isFinite(n)) return '—'
  if (Math.abs(n) >= 1e7) return `${(n / 1e7).toFixed(2)} Cr`
  if (Math.abs(n) >= 1e5) return `${(n / 1e5).toFixed(2)} L`
  if (Math.abs(n) >= 1e3) return `${(n / 1e3).toFixed(1)} K`
  return n.toFixed(0)
}

export function timeAgo(date: string | Date): string {
  const d = typeof date === 'string' ? new Date(date) : date
  const s = Math.floor((Date.now() - d.getTime()) / 1000)
  if (s < 60) return 'just now'
  if (s < 3600) return `${Math.floor(s / 60)}m ago`
  if (s < 86400) return `${Math.floor(s / 3600)}h ago`
  if (s < 86400 * 30) return `${Math.floor(s / 86400)}d ago`
  return d.toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })
}

export function fmtDate(date: string | Date): string {
  const d = typeof date === 'string' ? new Date(date) : date
  return d.toLocaleDateString('en-IN', { day: 'numeric', month: 'long', year: 'numeric' })
}

export function fmtTime(date: string | Date): string {
  const d = typeof date === 'string' ? new Date(date) : date
  return d.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })
}

export function initials(name: string): string {
  return name.split(/\s+/).map((w) => w[0]).filter(Boolean).slice(0, 2).join('').toUpperCase()
}

export function downloadJson(filename: string, data: unknown) {
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' })
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = filename
  a.click()
  URL.revokeObjectURL(url)
}
