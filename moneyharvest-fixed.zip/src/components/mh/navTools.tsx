'use client'

import { useRoute } from './router'

export function usePathnameLike(): string {
  const route = useRoute()
  return route.path
}

// paths where the AI floating widget should not show (it has a dedicated page)
const HIDE_AI_ON = ['/ai']

export function useAiWidgetVisible(): boolean {
  const route = useRoute()
  return !HIDE_AI_ON.includes(route.path)
}
