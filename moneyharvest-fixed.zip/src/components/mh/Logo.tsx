'use client'

// Money Harvest logo: a leaf whose midrib is an ascending growth arrow.
export function Logo({ size = 38, withText = true, textClass = '' }: { size?: number; withText?: boolean; textClass?: string }) {
  return (
    <span className="inline-flex items-center gap-2.5 select-none">
      <svg width={size} height={size} viewBox="0 0 64 64" fill="none" aria-hidden="true">
        <circle cx="32" cy="32" r="30" fill="#E9EDC9" stroke="#B4C18B" strokeWidth="2" />
        {/* leaf body */}
        <path d="M32 52 C 12 44, 10 22, 16 12 C 34 16, 46 26, 44 42 C 40 48, 36 51, 32 52 Z" fill="#CCD5AE" stroke="#8F9779" strokeWidth="1.6" strokeLinejoin="round" />
        {/* growth arrow midrib */}
        <path d="M22 42 L 30 32 L 34 36 L 42 22" stroke="#6E5636" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" fill="none" />
        <path d="M36 22 L 42 22 L 42 28" stroke="#6E5636" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" fill="none" />
        {/* stem */}
        <path d="M32 52 C 32 56, 32 58, 32 60" stroke="#8F9779" strokeWidth="2.4" strokeLinecap="round" />
      </svg>
      {withText && (
        <span className={`leading-tight ${textClass}`}>
          <span className="font-display font-semibold tracking-wide text-[1.05rem] text-forest block" style={{ color: '#2F3625' }}>
            MONEY HARVEST
          </span>
          <span className="hidden md:block text-[0.62rem] uppercase tracking-[0.18em] font-semibold max-w-[15rem]" style={{ color: '#8F6B44' }}>
            Grow Your Financial Intelligence
          </span>
        </span>
      )}
    </span>
  )
}
