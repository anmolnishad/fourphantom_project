'use client'

import { useEffect, useRef, useState } from 'react'
import { usePathnameLike } from './navTools'
import { Link, navigate, apiGet, apiSend, fmtTime } from './router'
import { useApp } from './store'
import { Logo } from './Logo'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover'
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel,
  DropdownMenuSeparator, DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import {
  Menu, X, Search, Bell, LogOut, LayoutDashboard, ShieldCheck, UserRound,
  GraduationCap, ScanSearch, Calculator, Sparkles, BookOpenCheck, Users,
  Award, MessagesSquare,
} from 'lucide-react'

const NAV = [
  { to: '/', label: 'Home' },
  { to: '/education', label: 'Financial Education' },
  { to: '/scam', label: 'Scam Detector' },
  { to: '/calculators', label: 'Calculators' },
  { to: '/ai', label: 'AI Assistant' },
  { to: '/cyber', label: 'Cybersecurity' },
  { to: '/resources', label: 'Courses & Resources' },
  { to: '/community', label: 'Community' },
  { to: '/certificates', label: 'Certificates' },
]

export function Nav() {
  const { user, unread, signOut } = useApp()
  const current = usePathnameLike()
  const [open, setOpen] = useState(false)
  const [q, setQ] = useState('')
  const [notifs, setNotifs] = useState<{ id: string; title: string; body: string; kind: string; link: string; read: boolean; createdAt: string }[]>([])
  const searchRef = useRef<HTMLInputElement>(null)

  // eslint-disable-next-line react-hooks/set-state-in-effect -- intentional reset on navigation
  useEffect(() => { setOpen(false) }, [current])

  const loadNotifs = async () => {
    if (!user) return
    try {
      const d = await apiGet<{ notifications: typeof notifs }>('/api/notifications')
      setNotifs(d.notifications)
    } catch { /* silent */ }
  }

  const markAll = async () => {
    try {
      await apiSend('/api/notifications', 'POST', {})
      setNotifs((ns) => ns.map((n) => ({ ...n, read: true })))
    } catch { /* silent */ }
  }

  const doSearch = (e: React.FormEvent) => {
    e.preventDefault()
    if (q.trim().length >= 2) {
      navigate(`/search?q=${encodeURIComponent(q.trim())}`)
      setQ('')
      searchRef.current?.blur()
    }
  }

  const unreadCount = notifs.filter((n) => !n.read).length || unread

  return (
    <header className="sticky top-0 z-50 w-full border-b border-[#E3DEC4] bg-[#FEFAE0]/95 backdrop-blur supports-[backdrop-filter]:bg-[#FEFAE0]/85">
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <div className="flex h-16 items-center justify-between gap-3">
          <Link to="/" ariaLabel="Money Harvest home">
            <Logo size={36} />
          </Link>

          {/* Desktop nav */}
          <nav className="hidden xl:flex items-center gap-0.5" aria-label="Primary">
            {NAV.map((n) => {
              const active = n.to === '/' ? current === '/' : current.startsWith(n.to)
              return (
                <Link key={n.to} to={n.to}
                  className={`px-2.5 py-2 rounded-md text-[0.8rem] font-semibold tracking-wide transition-colors ${
                    active ? 'bg-[#CCD5AE] text-[#33401F]' : 'text-[#55613F] hover:bg-[#F2EBD4] hover:text-[#3A4229]'
                  }`}>
                  {n.label}
                </Link>
              )
            })}
          </nav>

          {/* Right controls */}
          <div className="flex items-center gap-1.5 sm:gap-2">
            <form onSubmit={doSearch} className="hidden md:block relative w-44 lg:w-56" role="search">
              <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-4 w-4 text-[#8B8F6E]" />
              <Input
                ref={searchRef}
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder="Search lessons, tools…"
                className="pl-8 h-9 bg-[#FFFDF2] border-[#E3DEC4] text-sm"
                aria-label="Global search"
              />
            </form>

            <Link to="/search" className="md:hidden p-2 rounded-md hover:bg-[#F2EBD4]" ariaLabel="Search">
              <Search className="h-5 w-5 text-[#55613F]" />
            </Link>

            {user && (
              <Popover onOpenChange={(o) => o && loadNotifs()}>
                <PopoverTrigger asChild>
                  <button className="relative p-2 rounded-md hover:bg-[#F2EBD4]" aria-label={`Notifications (${unreadCount} unread)`}>
                    <Bell className="h-5 w-5 text-[#55613F]" />
                    {unreadCount > 0 && (
                      <span className="absolute -top-0.5 -right-0.5 h-4 min-w-4 px-0.5 rounded-full bg-[#B3413B] text-[0.6rem] font-bold text-white flex items-center justify-center">
                        {unreadCount > 9 ? '9+' : unreadCount}
                      </span>
                    )}
                  </button>
                </PopoverTrigger>
                <PopoverContent align="end" className="w-80 p-0">
                  <div className="flex items-center justify-between px-4 py-3 border-b border-[#E3DEC4]">
                    <span className="font-display font-semibold">Notifications</span>
                    {notifs.length > 0 && (
                      <button onClick={markAll} className="text-xs link-quiet underline">Mark all read</button>
                    )}
                  </div>
                  <div className="max-h-80 overflow-y-auto nice-scroll">
                    {notifs.length === 0 && (
                      <div className="px-4 py-8 text-center text-sm text-[#6B7052]">
                        <Bell className="h-8 w-8 mx-auto mb-2 opacity-30" />
                        No notifications yet. Quiz results and certificates will appear here.
                      </div>
                    )}
                    {notifs.map((n) => (
                      <button key={n.id}
                        onClick={() => { if (n.link) navigate(n.link) }}
                        className={`w-full text-left px-4 py-3 border-b border-[#F0EBD5] hover:bg-[#F6F1DC] transition-colors ${!n.read ? 'bg-[#F4EFDA]' : ''}`}>
                        <div className="flex items-start gap-2">
                          <span className={`mt-1.5 h-2 w-2 rounded-full shrink-0 ${!n.read ? 'bg-[#B08968]' : 'bg-transparent'}`} />
                          <div>
                            <p className="text-sm font-semibold text-[#2F3625]">{n.title}</p>
                            <p className="text-xs text-[#6B7052] mt-0.5 line-clamp-2">{n.body}</p>
                            <p className="text-[0.65rem] text-[#9B9F7E] mt-1">{fmtTime(n.createdAt)}</p>
                          </div>
                        </div>
                      </button>
                    ))}
                  </div>
                </PopoverContent>
              </Popover>
            )}

            {user ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <button className="flex items-center gap-2 rounded-full pl-1 pr-2 py-1 hover:bg-[#F2EBD4]" aria-label="Account menu">
                    <Avatar className="h-8 w-8 border border-[#E3DEC4]">
                      <AvatarFallback style={{ background: user.avatarColor || '#D4A373' }} className="text-white text-xs font-bold">
                        {user.name.slice(0, 2).toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                    <span className="hidden lg:block text-sm font-semibold max-w-24 truncate text-[#2F3625]">{user.name}</span>
                  </button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56">
                  <DropdownMenuLabel>
                    <div className="text-sm font-semibold">{user.name}</div>
                    <div className="text-xs text-[#6B7052] font-normal truncate">{user.email}</div>
                  </DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={() => navigate('/dashboard')}><LayoutDashboard className="h-4 w-4 mr-2" /> My Dashboard</DropdownMenuItem>
                  <DropdownMenuItem onClick={() => navigate('/certificates')}><Award className="h-4 w-4 mr-2" /> My Certificates</DropdownMenuItem>
                  <DropdownMenuItem onClick={() => navigate('/settings')}><UserRound className="h-4 w-4 mr-2" /> Profile & Settings</DropdownMenuItem>
                  {user.role === 'ADMIN' && (
                    <DropdownMenuItem onClick={() => navigate('/admin')}><ShieldCheck className="h-4 w-4 mr-2" /> Admin Dashboard</DropdownMenuItem>
                  )}
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={() => signOut()}><LogOut className="h-4 w-4 mr-2" /> Sign Out</DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <div className="hidden sm:flex items-center gap-2">
                <Button variant="ghost" className="h-9 text-[#55613F] hover:bg-[#F2EBD4] hover:text-[#3A4229] text-sm font-semibold" onClick={() => navigate('/signin')}>
                  Sign In
                </Button>
                <Button className="btn-bronze h-9 text-sm font-semibold px-4" onClick={() => navigate('/signup')}>
                  Get Started
                </Button>
              </div>
            )}

            {/* Mobile hamburger */}
            <button
              className="xl:hidden p-2 rounded-md hover:bg-[#F2EBD4]"
              onClick={() => setOpen((o) => !o)}
              aria-expanded={open}
              aria-label="Toggle navigation menu"
            >
              {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5 text-[#3A4229]" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      {open && (
        <div className="xl:hidden border-t border-[#E3DEC4] bg-[#FEFAE0]">
          <nav className="mx-auto max-w-7xl px-4 py-3 grid grid-cols-1 sm:grid-cols-2 gap-1" aria-label="Mobile">
            {NAV.map((n) => {
              const icons: Record<string, React.ReactNode> = {
                '/': <Sparkles className="h-4 w-4" />, '/education': <GraduationCap className="h-4 w-4" />,
                '/scam': <ScanSearch className="h-4 w-4" />, '/calculators': <Calculator className="h-4 w-4" />,
                '/ai': <MessagesSquare className="h-4 w-4" />, '/cyber': <BookOpenCheck className="h-4 w-4" />,
                '/resources': <BookOpenCheck className="h-4 w-4" />, '/community': <Users className="h-4 w-4" />,
                '/certificates': <Award className="h-4 w-4" />,
              }
              return (
                <Link key={n.to} to={n.to}
                  className={`flex items-center gap-2.5 px-3 py-2.5 rounded-lg text-sm font-semibold ${
                    current.startsWith(n.to) ? 'bg-[#CCD5AE] text-[#33401F]' : 'text-[#3A4229] hover:bg-[#F2EBD4]'
                  }`}>
                  {icons[n.to]}{n.label}
                </Link>
              )
            })}
            {!user && (
              <div className="sm:col-span-2 flex gap-2 pt-2 border-t border-[#E3DEC4] mt-1">
                <Button variant="outline" className="flex-1 h-10" onClick={() => navigate('/signin')}>Sign In</Button>
                <Button className="btn-bronze flex-1 h-10" onClick={() => navigate('/signup')}>Get Started</Button>
              </div>
            )}
          </nav>
        </div>
      )}
    </header>
  )
}
