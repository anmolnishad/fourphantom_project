import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getAuthUser } from '@/lib/auth'

export async function GET(req: NextRequest) {
  const user = await getAuthUser(req)
  if (!user) return NextResponse.json({ goals: [] })
  const goals = await db.learningGoal.findMany({ where: { userId: user.id }, orderBy: [{ done: 'asc' }, { createdAt: 'desc' }] })
  return NextResponse.json({ goals })
}

export async function POST(req: NextRequest) {
  const user = await getAuthUser(req)
  if (!user) return NextResponse.json({ error: 'Sign in required.' }, { status: 401 })
  try {
    const body = await req.json()
    const title = String(body.title || '').trim()
    if (title.length < 2 || title.length > 120) return NextResponse.json({ error: 'Goal title must be 2-120 characters.' }, { status: 400 })
    const goal = await db.learningGoal.create({
      data: { userId: user.id, title, note: String(body.note || '').slice(0, 300), targetDate: String(body.targetDate || '').slice(0, 40) },
    })
    return NextResponse.json({ goal })
  } catch {
    return NextResponse.json({ error: 'Failed to add goal.' }, { status: 500 })
  }
}

export async function PATCH(req: NextRequest) {
  const user = await getAuthUser(req)
  if (!user) return NextResponse.json({ error: 'Sign in required.' }, { status: 401 })
  try {
    const body = await req.json()
    const goal = await db.learningGoal.findUnique({ where: { id: String(body.id || '') } })
    if (!goal || goal.userId !== user.id) return NextResponse.json({ error: 'Goal not found.' }, { status: 404 })
    const updated = await db.learningGoal.update({ where: { id: goal.id }, data: { done: !goal.done } })
    return NextResponse.json({ goal: updated })
  } catch {
    return NextResponse.json({ error: 'Failed to update goal.' }, { status: 500 })
  }
}

export async function DELETE(req: NextRequest) {
  const user = await getAuthUser(req)
  if (!user) return NextResponse.json({ error: 'Sign in required.' }, { status: 401 })
  try {
    const { searchParams } = new URL(req.url)
    const goal = await db.learningGoal.findUnique({ where: { id: searchParams.get('id') || '' } })
    if (!goal || goal.userId !== user.id) return NextResponse.json({ error: 'Goal not found.' }, { status: 404 })
    await db.learningGoal.delete({ where: { id: goal.id } })
    return NextResponse.json({ ok: true })
  } catch {
    return NextResponse.json({ error: 'Failed to delete goal.' }, { status: 500 })
  }
}
