import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getAuthUser } from '@/lib/auth'
import { rateLimit, getClientIp } from '@/lib/rateLimit'

const CATEGORIES = ['saving-tips', 'investment-education', 'cybersecurity', 'scam-alerts', 'learning-achievements', 'general']
const BANNED_NAME_PATTERNS = /\b(rbi|reserve bank|sebi|bank official|bank manager|government|income tax dept|police|cbi|customer care)\b/i

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url)
    const category = searchParams.get('category') || ''
    const q = (searchParams.get('q') || '').trim()
    const sort = searchParams.get('sort') || 'new'
    const page = Math.max(1, parseInt(searchParams.get('page') || '1', 10))
    const perPage = 12
    const user = await getAuthUser(req)

    const where: Record<string, unknown> = {}
    if (category) where.category = category
    if (q) where.content = { contains: q }

    const orderBy = sort === 'popular' ? [{ likeCount: 'desc' as const }, { createdAt: 'desc' as const }] : [{ createdAt: 'desc' as const }]

    const [posts, total] = await Promise.all([
      db.communityPost.findMany({
        where,
        orderBy,
        skip: (page - 1) * perPage,
        take: perPage,
        include: {
          user: { select: { id: true, name: true, avatarColor: true, role: true } },
          _count: { select: { comments: true, likes: true } },
        },
      }),
      db.communityPost.count({ where }),
    ])

    let likedIds: string[] = []
    let bookmarkedIds: string[] = []
    if (user && posts.length > 0) {
      const ids = posts.map((p) => p.id)
      const [likes, marks] = await Promise.all([
        db.like.findMany({ where: { userId: user.id, postId: { in: ids } }, select: { postId: true } }),
        db.bookmark.findMany({ where: { userId: user.id, kind: 'post', refId: { in: ids } }, select: { refId: true } }),
      ])
      likedIds = likes.map((l) => l.postId)
      bookmarkedIds = marks.map((m) => m.refId)
    }

    return NextResponse.json({
      posts: posts.map((p) => ({
        id: p.id,
        content: p.content,
        category: p.category,
        image: p.image,
        likeCount: p.likeCount,
        commentCount: p._count.comments,
        edited: p.edited,
        createdAt: p.createdAt,
        updatedAt: p.updatedAt,
        author: { id: p.user.id, name: p.user.name, avatarColor: p.user.avatarColor, role: p.user.role },
        liked: likedIds.includes(p.id),
        bookmarked: bookmarkedIds.includes(p.id),
        mine: user ? p.userId === user.id : false,
      })),
      total,
      page,
      pages: Math.max(1, Math.ceil(total / perPage)),
    })
  } catch {
    return NextResponse.json({ error: 'Failed to load posts.' }, { status: 500 })
  }
}

export async function POST(req: NextRequest) {
  const user = await getAuthUser(req)
  if (!user) return NextResponse.json({ error: 'Sign in to post in the community.' }, { status: 401 })

  const ip = getClientIp(req)
  const rl = rateLimit(`post:${user.id}:${ip}`, 8, 10 * 60 * 1000)
  if (!rl.allowed) return NextResponse.json({ error: 'Posting too quickly — please wait a few minutes (spam prevention).' }, { status: 429 })

  try {
    const body = await req.json()
    const content = String(body.content || '').trim()
    const category = CATEGORIES.includes(body.category) ? body.category : 'general'
    let image: string | null = null
    if (typeof body.image === 'string' && body.image.startsWith('data:image/') && body.image.length < 1_400_000) {
      image = body.image
    }

    if (content.length < 5) return NextResponse.json({ error: 'Posts need at least 5 characters.' }, { status: 400 })
    if (content.length > 4000) return NextResponse.json({ error: 'Posts are limited to 4000 characters.' }, { status: 400 })

    // Impersonation guard
    if (BANNED_NAME_PATTERNS.test(content) && /\b(official|authorized|authorised|verified)\b/i.test(content)) {
      return NextResponse.json({ error: 'Posts may not present personal views as official statements of banks, regulators or authorities.' }, { status: 400 })
    }

    // Duplicate-spam guard
    const dup = await db.communityPost.findFirst({ where: { userId: user.id, content, createdAt: { gte: new Date(Date.now() - 10 * 60 * 1000) } } })
    if (dup) return NextResponse.json({ error: 'You already posted this content just now.' }, { status: 409 })

    const post = await db.communityPost.create({
      data: { userId: user.id, content, category, image },
    })

    return NextResponse.json({
      post: { id: post.id, content: post.content, category: post.category, createdAt: post.createdAt },
    })
  } catch {
    return NextResponse.json({ error: 'Failed to create post.' }, { status: 500 })
  }
}
