import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getAuthUser } from '@/lib/auth'
import { rateLimit, getClientIp } from '@/lib/rateLimit'

const REASONS = ['spam', 'abuse', 'misinformation', 'impersonation', 'other']

export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const user = await getAuthUser(req)
  if (!user) return NextResponse.json({ error: 'Sign in to report content.' }, { status: 401 })
  const rl = rateLimit(`report:${user.id}`, 10, 60 * 60 * 1000)
  if (!rl.allowed) return NextResponse.json({ error: 'Too many reports. Our moderators will review shortly.' }, { status: 429 })
  try {
    const { id } = await params
    const post = await db.communityPost.findUnique({ where: { id } })
    if (!post) return NextResponse.json({ error: 'Post not found.' }, { status: 404 })

    const body = await req.json()
    const reason = REASONS.includes(body.reason) ? body.reason : 'other'
    const detail = String(body.detail || '').slice(0, 400)

    const already = await db.report.findFirst({ where: { postId: id, userId: user.id } })
    if (already) return NextResponse.json({ ok: true, message: 'You have already reported this post. Moderators are reviewing it.' })

    await db.report.create({ data: { postId: id, userId: user.id, reason, detail } })
    return NextResponse.json({ ok: true, message: 'Report submitted. A moderator will review this post. Thank you for keeping the community safe.' })
  } catch {
    return NextResponse.json({ error: 'Report failed.' }, { status: 500 })
  }
}
