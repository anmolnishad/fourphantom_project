import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getAuthUser } from '@/lib/auth'

// Toggle bookmark on a post
export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const user = await getAuthUser(req)
  if (!user) return NextResponse.json({ error: 'Sign in to bookmark.' }, { status: 401 })
  try {
    const { id } = await params
    const post = await db.communityPost.findUnique({ where: { id } })
    if (!post) return NextResponse.json({ error: 'Post not found.' }, { status: 404 })

    const existing = await db.bookmark.findUnique({ where: { userId_kind_refId: { userId: user.id, kind: 'post', refId: id } } })
    if (existing) {
      await db.bookmark.delete({ where: { id: existing.id } })
      return NextResponse.json({ bookmarked: false })
    }
    await db.bookmark.create({ data: { userId: user.id, kind: 'post', refId: id, label: post.content.slice(0, 100) } })
    return NextResponse.json({ bookmarked: true })
  } catch {
    return NextResponse.json({ error: 'Bookmark failed.' }, { status: 500 })
  }
}
