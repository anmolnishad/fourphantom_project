import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getAuthUser, requireAdmin } from '@/lib/auth'

// PATCH: edit own post; DELETE: delete own post (or admin)
export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const user = await getAuthUser(req)
  if (!user) return NextResponse.json({ error: 'Sign in required.' }, { status: 401 })
  try {
    const { id } = await params
    const post = await db.communityPost.findUnique({ where: { id } })
    if (!post) return NextResponse.json({ error: 'Post not found.' }, { status: 404 })
    if (post.userId !== user.id) return NextResponse.json({ error: 'You can only edit your own posts.' }, { status: 403 })

    const body = await req.json()
    const content = String(body.content || '').trim()
    if (content.length < 5 || content.length > 4000) return NextResponse.json({ error: 'Content must be 5-4000 characters.' }, { status: 400 })

    const updated = await db.communityPost.update({ where: { id }, data: { content, edited: true } })
    return NextResponse.json({ post: { id: updated.id, content: updated.content, edited: updated.edited } })
  } catch {
    return NextResponse.json({ error: 'Edit failed.' }, { status: 500 })
  }
}

export async function DELETE(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const user = await getAuthUser(req)
  if (!user) return NextResponse.json({ error: 'Sign in required.' }, { status: 401 })
  try {
    const { id } = await params
    const post = await db.communityPost.findUnique({ where: { id } })
    if (!post) return NextResponse.json({ error: 'Post not found.' }, { status: 404 })
    const admin = user.role === 'ADMIN'
    if (post.userId !== user.id && !admin) return NextResponse.json({ error: 'You can only delete your own posts.' }, { status: 403 })

    await db.communityPost.delete({ where: { id } })
    return NextResponse.json({ ok: true })
  } catch {
    return NextResponse.json({ error: 'Delete failed.' }, { status: 500 })
  }
}
