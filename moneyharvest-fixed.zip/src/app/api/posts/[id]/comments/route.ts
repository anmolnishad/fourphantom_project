import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getAuthUser } from '@/lib/auth'
import { rateLimit, getClientIp } from '@/lib/rateLimit'

// GET comments (with one level of replies)
export async function GET(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params
    const comments = await db.comment.findMany({
      where: { postId: id, parentId: null },
      orderBy: { createdAt: 'asc' },
      include: {
        user: { select: { id: true, name: true, avatarColor: true, role: true } },
        replies: {
          orderBy: { createdAt: 'asc' },
          include: { user: { select: { id: true, name: true, avatarColor: true, role: true } } },
        },
      },
    })
    return NextResponse.json({
      comments: comments.map((c) => ({
        id: c.id, content: c.content, createdAt: c.createdAt,
        author: { id: c.user.id, name: c.user.name, avatarColor: c.user.avatarColor, role: c.user.role },
        replies: c.replies.map((r) => ({
          id: r.id, content: r.content, createdAt: r.createdAt, parentId: r.parentId,
          author: { id: r.user.id, name: r.user.name, avatarColor: r.user.avatarColor, role: r.user.role },
        })),
      })),
    })
  } catch {
    return NextResponse.json({ error: 'Failed to load comments.' }, { status: 500 })
  }
}

// POST comment or reply { content, parentId? }
export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const user = await getAuthUser(req)
  if (!user) return NextResponse.json({ error: 'Sign in to comment.' }, { status: 401 })
  const ip = getClientIp(req)
  const rl = rateLimit(`comment:${user.id}:${ip}`, 20, 5 * 60 * 1000)
  if (!rl.allowed) return NextResponse.json({ error: 'Commenting too quickly — slow down a little.' }, { status: 429 })
  try {
    const { id } = await params
    const post = await db.communityPost.findUnique({ where: { id } })
    if (!post) return NextResponse.json({ error: 'Post not found.' }, { status: 404 })

    const body = await req.json()
    const content = String(body.content || '').trim()
    if (content.length < 1 || content.length > 1000) return NextResponse.json({ error: 'Comments must be 1-1000 characters.' }, { status: 400 })

    let parentId: string | null = null
    if (body.parentId) {
      const parent = await db.comment.findUnique({ where: { id: String(body.parentId) } })
      if (!parent || parent.postId !== id) return NextResponse.json({ error: 'Invalid parent comment.' }, { status: 400 })
      parentId = parent.parentId ?? parent.id // keep threads one level deep
    }

    const comment = await db.comment.create({ data: { postId: id, userId: user.id, content, parentId } })

    if (post.userId !== user.id) {
      await db.notification.create({
        data: { userId: post.userId, title: 'New comment on your post', body: `${user.name}: ${content.slice(0, 80)}`, kind: 'info', link: '#/community' },
      })
    }

    return NextResponse.json({
      comment: {
        id: comment.id, content: comment.content, createdAt: comment.createdAt, parentId: comment.parentId,
        author: { id: user.id, name: user.name, avatarColor: user.avatarColor, role: user.role },
        replies: [],
      },
    })
  } catch {
    return NextResponse.json({ error: 'Comment failed.' }, { status: 500 })
  }
}
