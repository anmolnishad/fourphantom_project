import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getAuthUser } from '@/lib/auth'

// Toggle like on a post
export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const user = await getAuthUser(req)
  if (!user) return NextResponse.json({ error: 'Sign in to like posts.' }, { status: 401 })
  try {
    const { id } = await params
    const post = await db.communityPost.findUnique({ where: { id } })
    if (!post) return NextResponse.json({ error: 'Post not found.' }, { status: 404 })

    const existing = await db.like.findUnique({ where: { postId_userId: { postId: id, userId: user.id } } })
    if (existing) {
      await db.like.delete({ where: { id: existing.id } })
      const likeCount = await db.like.count({ where: { postId: id } })
      await db.communityPost.update({ where: { id }, data: { likeCount } })
      return NextResponse.json({ liked: false, likeCount })
    }
    await db.like.create({ data: { postId: id, userId: user.id } })
    const likeCount = await db.like.count({ where: { postId: id } })
    await db.communityPost.update({ where: { id }, data: { likeCount } })

    if (post.userId !== user.id) {
      await db.notification.create({
        data: { userId: post.userId, title: 'New like on your post', body: `${user.name} liked your community post.`, kind: 'info', link: '#/community' },
      })
    }
    return NextResponse.json({ liked: true, likeCount })
  } catch {
    return NextResponse.json({ error: 'Like failed.' }, { status: 500 })
  }
}
