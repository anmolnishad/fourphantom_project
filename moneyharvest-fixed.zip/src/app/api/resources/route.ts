import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireAdmin } from '@/lib/auth'

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url)
    const category = searchParams.get('category') || ''
    const where: Record<string, unknown> = {}
    if (category) where.category = category
    const resources = await db.educationalResource.findMany({ where, orderBy: { createdAt: 'asc' } })
    return NextResponse.json({ resources })
  } catch {
    return NextResponse.json({ error: 'Failed to load resources.' }, { status: 500 })
  }
}

export async function POST(req: NextRequest) {
  const admin = await requireAdmin(req)
  if (!admin) return NextResponse.json({ error: 'Admin access required.' }, { status: 403 })
  try {
    const body = await req.json()
    let url = String(body.url || '').trim()
    if (!/^https?:\/\//i.test(url)) return NextResponse.json({ error: 'URL must start with http:// or https://.' }, { status: 400 })
    const resource = await db.educationalResource.create({
      data: {
        title: String(body.title || '').trim(),
        description: String(body.description || '').trim(),
        url,
        category: String(body.category || 'financial-literacy'),
        level: String(body.level || 'Beginner'),
        source: String(body.source || '').trim(),
      },
    })
    return NextResponse.json({ resource })
  } catch {
    return NextResponse.json({ error: 'Failed to add resource.' }, { status: 500 })
  }
}

export async function PATCH(req: NextRequest) {
  const admin = await requireAdmin(req)
  if (!admin) return NextResponse.json({ error: 'Admin access required.' }, { status: 403 })
  try {
    const body = await req.json()
    const { id, ...rest } = body
    const data: Record<string, unknown> = {}
    for (const k of ['title', 'description', 'url', 'category', 'level', 'source']) {
      if (rest[k] !== undefined) data[k] = String(rest[k])
    }
    const resource = await db.educationalResource.update({ where: { id: String(id) }, data })
    return NextResponse.json({ resource })
  } catch {
    return NextResponse.json({ error: 'Failed to update resource.' }, { status: 500 })
  }
}

export async function DELETE(req: NextRequest) {
  const admin = await requireAdmin(req)
  if (!admin) return NextResponse.json({ error: 'Admin access required.' }, { status: 403 })
  try {
    const { searchParams } = new URL(req.url)
    const id = searchParams.get('id') || ''
    await db.educationalResource.delete({ where: { id } })
    return NextResponse.json({ ok: true })
  } catch {
    return NextResponse.json({ error: 'Failed to delete resource.' }, { status: 500 })
  }
}
