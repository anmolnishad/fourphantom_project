import { NextRequest, NextResponse } from 'next/server'
import ZAI from 'z-ai-web-dev-sdk'
import { rateLimit, getClientIp } from '@/lib/rateLimit'

export const maxDuration = 60

const SYSTEM_PROMPT = `You are "Harvest AI", the friendly financial education assistant of Money Harvest, a financial-literacy platform.

STYLE: Warm, encouraging, and clear. Use short paragraphs and simple language. When helpful, use small markdown lists. Keep answers under 220 words unless the user asks for depth. Use ₹ and Indian context (UPI, SIP, FD, RD, RBI, SEBI) by default.

SCOPE: Financial education only — personal finance, saving, budgeting, investing concepts, banking, credit, digital payments, cybersecurity and scam awareness. You may also explain Money Harvest features (lessons, calculators, quizzes, certificates, community, scam scanner).

RULES:
1. Education only. Never give personalised investment advice, never recommend specific stocks/funds/products, never predict markets. If asked, explain concepts generally and suggest consulting a SEBI-registered adviser for personal decisions.
2. Never guarantee or imply guaranteed returns.
3. For safety topics, promote the official channels: cybercrime.gov.in, helpline 1930, sancharsaathi.gov.in (Chakshu), rbi.org.in, sebi.gov.in.
4. Never ask the user for OTPs, PINs, passwords, card numbers, or account credentials. If a user pastes such data, warn them to change it immediately and continue without using it.
5. If a question is outside finance/education, politely steer back to money and safety topics.
6. End long educational answers with one short follow-up suggestion when natural.`

const FALLBACK_FAQ: { match: RegExp; answer: string }[] = [
  { match: /sip|systematic investment/i, answer: 'A Systematic Investment Plan (SIP) invests a fixed amount into a mutual fund on a fixed date every month. Benefits: automation, rupee-cost averaging (more units bought at low prices), and compounding over years. Example: ₹5,000/month at ~11% annualised for 20 years has historically grown to roughly ₹40 lakh — though actual returns vary and are never guaranteed. Try the SIP Calculator in our Calculators section to model your own numbers.' },
  { match: /compound interest/i, answer: 'Compound interest means your interest also earns interest. Formula: Principal × (1 + r/n)^(n×t). Handy shortcut — the Rule of 72: divide 72 by your annual return to estimate doubling time (at 9%, money doubles in ~8 years). The same force works in reverse on credit-card debt at ~42% annualised — that debt doubles in under 2 years. Start early: the first rupees compound the longest.' },
  { match: /fd|fixed deposit/i, answer: 'A Fixed Deposit locks a lump sum at a fixed rate for a chosen tenure. Interest compounds (commonly quarterly) — 7% quarterly compounding is effectively ~7.19% a year. FDs are DICGC-insured up to ₹5 lakh per bank per depositor. Remember: interest is taxable at your slab, so post-tax returns may barely beat inflation — best for goals within 0–3 years, not long-term wealth.' },
  { match: /rd|recurring deposit/i, answer: 'A Recurring Deposit builds the saving habit: deposit a fixed amount monthly for a fixed tenure at a locked rate, and receive everything at maturity. Each instalment earns interest only from its own date, so effective yield is lower than the headline rate. Ideal for known future expenses (insurance premiums, fees). RD = certainty; SIP = growth with volatility. Match the instrument to your timeline.' },
  { match: /saving|save money/i, answer: 'Three habits that actually work: (1) Automate — move savings out on salary day before you can spend ("pay yourself first"). (2) Separate — keep savings in a different account without a debit card. (3) Name goals — "₹30,000 Goa trip by December" beats vague "save more". Start with 5–10% of income and raise it 1–2% each quarter. Our Budget Planner and Savings Goal Calculator can model your exact numbers.' },
  { match: /budget/i, answer: 'Start with the 50/30/20 rule: 50% of take-home pay for needs, 30% for wants, 20% for savings and extra debt payoff. Steps: pull last month\u2019s bank statement, group spending into those buckets, pick the most surprising category, and automate your savings transfer on salary day. Review 5 minutes weekly. Use our Budget Planner for a personalised breakdown.' },
  { match: /scam|fraud|phish/i, answer: 'Top red flags in any message: requests for OTP/PIN/password/CVV (no institution ever asks), guaranteed high returns, urgency ("act in 30 minutes"), payment to "receive" money, and suspicious links. If money is already lost: call 1930 immediately and file at cybercrime.gov.in — the first hour matters most. Report fraudulent messages via Chakshu at sancharsaathi.gov.in. Try our Scam Detector to scan a suspicious message.' },
  { match: /upi/i, answer: 'Golden UPI rules: (1) Receiving money NEVER requires a PIN — any "approve to receive" flow is theft. (2) Verify payments in your own bank app, never via screenshots. (3) Read the "You are paying ₹X to NAME" line before every PIN. (4) Set low daily limits. If defrauded: in-app report → bank → 1930 → cybercrime.gov.in, within the golden hour.' },
  { match: /cybersecurity|cyber security/i, answer: 'Cybersecurity for your money means: unique passwords via a password manager, app-based MFA (authenticator apps beat SMS), phone app-locks, official app stores only, and navigating to banks by typing their address instead of clicking links. Check SIMs registered to your ID at sancharsaathi.gov.in. Explore our Cybersecurity Hub lessons for the full playbook.' },
  { match: /mutual fund/i, answer: 'A mutual fund pools money from many investors; a professional manager invests it across dozens of securities. Key facts: returns are never guaranteed, expense ratios compound against you (prefer low-cost direct/index funds), and match the fund type to your goal horizon — equity for 7+ years, debt for shorter. Verify any fund/AMC via AMFI (amfiindia.com) and SEBI\u2019s registry before investing.' },
]

export async function POST(req: NextRequest) {
  const ip = getClientIp(req)
  const rl = rateLimit(`chat:${ip}`, 12, 5 * 60 * 1000)
  if (!rl.allowed) {
    return NextResponse.json(
      { error: 'You are sending messages quickly. Please wait a moment and try again.', retryAfterSec: rl.retryAfterSec, mode: 'rate-limited' },
      { status: 429 }
    )
  }

  let messages: { role: string; content: string }[] = []
  try {
    const body = await req.json()
    if (!Array.isArray(body.messages)) return NextResponse.json({ error: 'Invalid request.' }, { status: 400 })
    messages = body.messages
      .slice(-12) // maintain bounded conversation context for the session
      .filter((m: { role?: string; content?: string }) => m && (m.role === 'user' || m.role === 'assistant') && typeof m.content === 'string' && m.content.trim().length > 0)
      .map((m: { role: string; content: string }) => ({ role: m.role, content: m.content.slice(0, 2000) }))
    if (messages.length === 0) return NextResponse.json({ error: 'Message required.' }, { status: 400 })
  } catch {
    return NextResponse.json({ error: 'Invalid request body.' }, { status: 400 })
  }

  // Try the configured AI backend; on failure, fall back to the clearly-labelled offline knowledge base
  try {
    const zai = await ZAI.create()
    const completion = await zai.chat.completions.create({
      messages: [{ role: 'system', content: SYSTEM_PROMPT }, ...messages],
      thinking: { type: 'disabled' },
    })
    const content = completion.choices[0]?.message?.content
    if (!content) throw new Error('Empty completion')
    return NextResponse.json({ reply: content, mode: 'ai' })
  } catch {
    const lastUser = [...messages].reverse().find((m) => m.role === 'user')?.content || ''
    const hit = FALLBACK_FAQ.find((f) => f.match.test(lastUser))
    const reply = hit
      ? `${hit.answer}\n\n— *Offline knowledge-base mode: the live AI service is currently unavailable, so I answered from Money Harvest\u2019s curated educational FAQ.*`
      : `I\u2019m currently in **offline knowledge-base mode** (the live AI service is unavailable), so I can only answer curated topics: SIP, FD/RD, compound interest, budgeting, saving, mutual funds, UPI safety, scam red flags and cybersecurity basics.\n\nAsk me about one of those, or explore our Lessons, Calculators, and Scam Detector meanwhile.\n\n— *This is a static educational FAQ, not a live AI model.*`
    return NextResponse.json({ reply, mode: 'offline-faq' })
  }
}
