import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireAdmin, getAuthUser } from '@/lib/auth'

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url)
    const category = searchParams.get('category') || ''
    const q = (searchParams.get('q') || '').trim()
    const user = await getAuthUser(req)

    const where: Record<string, unknown> = { published: true }
    if (category) where.category = category
    if (q) {
      where.OR = [
        { title: { contains: q } },
        { summary: { contains: q } },
        { topic: { contains: q } },
      ]
    }

    const lessons = await db.lesson.findMany({
      where,
      orderBy: [{ category: 'asc' }, { order: 'asc' }],
      select: {
        id: true, slug: true, category: true, topic: true, title: true,
        summary: true, level: true, readMinutes: true, tags: true,
      },
    })

    let progressMap: Record<string, { completed: boolean; bookmarked: boolean }> = {}
    if (user) {
      const ids = lessons.map((l) => l.id)
      const [progress, bookmarks] = await Promise.all([
        db.lessonProgress.findMany({ where: { userId: user.id, lessonId: { in: ids } } }),
        db.bookmark.findMany({ where: { userId: user.id, kind: 'lesson', refId: { in: lessons.map((l) => l.slug) } } }),
      ])
      progressMap = Object.fromEntries(
        lessons.map((l) => [
          l.slug,
          {
            completed: progress.some((p) => p.lessonId === l.id && p.completed),
            bookmarked: bookmarks.some((b) => b.refId === l.slug),
          },
        ])
      )
    }

    return NextResponse.json({ lessons, progress: progressMap })
  } catch {
    return NextResponse.json({ error: 'Failed to load lessons.' }, { status: 500 })
  }
}

// Admin: create a lesson
export async function POST(req: NextRequest) {
  const admin = await requireAdmin(req)
  if (!admin) return NextResponse.json({ error: 'Admin access required.' }, { status: 403 })
  try {
    const body = await req.json()
    const slug = String(body.slug || '').trim().toLowerCase().replace(/[^a-z0-9-]/g, '-')
    if (!slug) return NextResponse.json({ error: 'A URL slug is required.' }, { status: 400 })
    const exists = await db.lesson.findUnique({ where: { slug } })
    if (exists) return NextResponse.json({ error: 'A lesson with this slug already exists.' }, { status: 409 })

    const lesson = await db.lesson.create({
      data: {
        slug,
        category: String(body.category || 'personal-finance'),
        topic: String(body.topic || body.title || '').trim(),
        title: String(body.title || '').trim(),
        summary: String(body.summary || '').trim(),
        content: JSON.stringify(body.content || { intro: '', sections: [], keyTerms: [], takeaways: [] }),
        level: String(body.level || 'Beginner'),
        readMinutes: Number(body.readMinutes) || 6,
        tags: JSON.stringify(body.tags || []),
        order: Number(body.order) || 99,
      },
    })
    return NextResponse.json({ lesson })
  } catch {
    return NextResponse.json({ error: 'Failed to create lesson.' }, { status: 500 })
  }
}
