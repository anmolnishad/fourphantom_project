import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireAdmin, getAuthUser } from '@/lib/auth'

export async function GET(req: NextRequest, { params }: { params: Promise<{ slug: string }> }) {
  try {
    const { slug } = await params
    const lesson = await db.lesson.findUnique({ where: { slug } })
    if (!lesson || !lesson.published) return NextResponse.json({ error: 'Lesson not found.' }, { status: 404 })

    const user = await getAuthUser(req)
    let progress = { completed: false, bookmarked: false }
    if (user) {
      const [p, b] = await Promise.all([
        db.lessonProgress.findUnique({ where: { userId_lessonId: { userId: user.id, lessonId: lesson.id } } }),
        db.bookmark.findUnique({ where: { userId_kind_refId: { userId: user.id, kind: 'lesson', refId: slug } } }),
      ])
      progress = { completed: !!p?.completed, bookmarked: !!b }
    }

    return NextResponse.json({ lesson: { ...lesson, content: JSON.parse(lesson.content), progress }, tags: JSON.parse(lesson.tags) })
  } catch {
    return NextResponse.json({ error: 'Failed to load lesson.' }, { status: 500 })
  }
}

// Admin: update lesson
export async function PATCH(req: NextRequest, { params }: { params: Promise<{ slug: string }> }) {
  const admin = await requireAdmin(req)
  if (!admin) return NextResponse.json({ error: 'Admin access required.' }, { status: 403 })
  try {
    const { slug } = await params
    const body = await req.json()
    const data: Record<string, unknown> = {}
    if (body.title) data.title = String(body.title)
    if (body.summary !== undefined) data.summary = String(body.summary)
    if (body.topic !== undefined) data.topic = String(body.topic)
    if (body.level) data.level = String(body.level)
    if (body.readMinutes) data.readMinutes = Number(body.readMinutes)
    if (body.published !== undefined) data.published = !!body.published
    if (body.content) data.content = JSON.stringify(body.content)
    if (body.tags) data.tags = JSON.stringify(body.tags)
    const lesson = await db.lesson.update({ where: { slug }, data })
    return NextResponse.json({ lesson: { ...lesson, content: JSON.parse(lesson.content) } })
  } catch {
    return NextResponse.json({ error: 'Failed to update lesson.' }, { status: 500 })
  }
}

// Admin: delete lesson
export async function DELETE(req: NextRequest, { params }: { params: Promise<{ slug: string }> }) {
  const admin = await requireAdmin(req)
  if (!admin) return NextResponse.json({ error: 'Admin access required.' }, { status: 403 })
  try {
    const { slug } = await params
    await db.lesson.delete({ where: { slug } })
    return NextResponse.json({ ok: true })
  } catch {
    return NextResponse.json({ error: 'Failed to delete lesson.' }, { status: 500 })
  }
}
