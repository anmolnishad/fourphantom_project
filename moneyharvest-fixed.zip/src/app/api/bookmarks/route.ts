import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getAuthUser } from '@/lib/auth'

// GET: list user's bookmarks
export async function GET(req: NextRequest) {
  const user = await getAuthUser(req)
  if (!user) return NextResponse.json({ bookmarks: [] })
  const bookmarks = await db.bookmark.findMany({
    where: { userId: user.id },
    orderBy: { createdAt: 'desc' },
  })
  return NextResponse.json({ bookmarks })
}

// POST: toggle a bookmark { kind: 'lesson'|'resource'|'post', refId, label }
export async function POST(req: NextRequest) {
  const user = await getAuthUser(req)
  if (!user) return NextResponse.json({ error: 'Sign in to bookmark.' }, { status: 401 })
  try {
    const body = await req.json()
    const kind = String(body.kind || '')
    const refId = String(body.refId || '')
    const label = String(body.label || '').slice(0, 160)
    if (!['lesson', 'resource', 'post'].includes(kind) || !refId) {
      return NextResponse.json({ error: 'Invalid bookmark.' }, { status: 400 })
    }
    const existing = await db.bookmark.findUnique({
      where: { userId_kind_refId: { userId: user.id, kind, refId } },
    })
    if (existing) {
      await db.bookmark.delete({ where: { id: existing.id } })
      return NextResponse.json({ bookmarked: false })
    }
    await db.bookmark.create({ data: { userId: user.id, kind, refId, label } })
    return NextResponse.json({ bookmarked: true })
  } catch {
    return NextResponse.json({ error: 'Bookmark failed.' }, { status: 500 })
  }
}
