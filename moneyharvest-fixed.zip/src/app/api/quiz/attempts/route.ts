import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getAuthUser } from '@/lib/auth'

export async function GET(req: NextRequest) {
  const user = await getAuthUser(req)
  if (!user) return NextResponse.json({ attempts: [] })
  const attempts = await db.quizAttempt.findMany({
    where: { userId: user.id },
    orderBy: { createdAt: 'desc' },
    take: 50,
    select: { id: true, category: true, difficulty: true, score: true, total: true, percent: true, passed: true, createdAt: true },
  })
  return NextResponse.json({ attempts })
}
