import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireAdmin } from '@/lib/auth'

// GET a randomized question set: ?category=&difficulty=&count=10
export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url)
    const category = searchParams.get('category') || ''
    const difficulty = searchParams.get('difficulty') || ''
    const count = Math.min(Math.max(parseInt(searchParams.get('count') || '10', 10), 5), 20)

    const where: Record<string, unknown> = {}
    if (category) where.category = category
    if (difficulty) where.difficulty = difficulty

    let questions = await db.quizQuestion.findMany({ where })
    if (questions.length === 0) return NextResponse.json({ questions: [], error: 'No questions available for this selection yet.' }, { status: 404 })

    // Fisher-Yates shuffle
    for (let i = questions.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1))
      ;[questions[i], questions[j]] = [questions[j], questions[i]]
    }
    questions = questions.slice(0, count)

    return NextResponse.json({
      questions: questions.map((q, idx) => ({
        id: q.id,
        index: idx,
        category: q.category,
        difficulty: q.difficulty,
        question: q.question,
        options: JSON.parse(q.options),
        // correctIndex intentionally NOT sent to client before submission
      })),
      totalAvailable: questions.length,
    })
  } catch {
    return NextResponse.json({ error: 'Failed to load questions.' }, { status: 500 })
  }
}

// Admin CRUD for questions
export async function POST(req: NextRequest) {
  const admin = await requireAdmin(req)
  if (!admin) return NextResponse.json({ error: 'Admin access required.' }, { status: 403 })
  try {
    const body = await req.json()
    const options = body.options
    if (!Array.isArray(options) || options.length < 2 || options.length > 6) {
      return NextResponse.json({ error: 'Provide 2-6 options.' }, { status: 400 })
    }
    const correctIndex = Number(body.correctIndex)
    if (!Number.isInteger(correctIndex) || correctIndex < 0 || correctIndex >= options.length) {
      return NextResponse.json({ error: 'Correct answer index is invalid.' }, { status: 400 })
    }
    const q = await db.quizQuestion.create({
      data: {
        category: String(body.category || 'personal-finance'),
        difficulty: String(body.difficulty || 'beginner'),
        question: String(body.question || '').trim(),
        options: JSON.stringify(options.map((o: unknown) => String(o).slice(0, 200))),
        correctIndex,
        explanation: String(body.explanation || '').trim(),
      },
    })
    return NextResponse.json({ question: q })
  } catch {
    return NextResponse.json({ error: 'Failed to create question.' }, { status: 500 })
  }
}
