import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getAuthUser } from '@/lib/auth'
import { rateLimit, getClientIp } from '@/lib/rateLimit'

interface SubmittedAnswer { questionId: string; chosen: number }

// POST: submit answers. Server re-grades from the database — client scores are never trusted.
export async function POST(req: NextRequest) {
  const ip = getClientIp(req)
  const rl = rateLimit(`quiz:${ip}`, 30, 10 * 60 * 1000)
  if (!rl.allowed) return NextResponse.json({ error: 'Too many submissions. Take a short break.' }, { status: 429 })

  try {
    const body = await req.json()
    const category = String(body.category || '')
    const difficulty = String(body.difficulty || 'beginner')
    const timeTakenSec = Math.max(0, Number(body.timeTakenSec) || 0)
    const answers: SubmittedAnswer[] = Array.isArray(body.answers) ? body.answers.slice(0, 40) : []
    if (!category || answers.length === 0) return NextResponse.json({ error: 'Category and answers are required.' }, { status: 400 })

    const ids = answers.map((a) => a.questionId)
    const questions = await db.quizQuestion.findMany({ where: { id: { in: ids }, category } })
    const qMap = new Map(questions.map((q) => [q.id, q]))

    let score = 0
    const details = answers.map((a) => {
      const q = qMap.get(a.questionId)
      const correct = q ? q.correctIndex === a.chosen : false
      if (correct) score++
      return {
        questionId: a.questionId,
        question: q?.question || '',
        options: q ? JSON.parse(q.options) : [],
        chosen: a.chosen,
        correctIndex: q?.correctIndex ?? -1,
        correct,
        explanation: q?.explanation || '',
      }
    })

    const total = answers.length
    const percent = total > 0 ? Math.round((score / total) * 100) : 0
    const passed = percent >= 60 // baseline passing bar for quiz completion tracking

    const user = await getAuthUser(req)
    if (user) {
      await db.quizAttempt.create({
        data: { userId: user.id, category, difficulty, score, total, percent, passed, details: JSON.stringify(details), createdAt: new Date() },
      })
    }

    return NextResponse.json({
      score, total, percent, passed, details, timeTakenSec,
      saved: !!user,
      note: user ? undefined : 'Sign in to save attempts and unlock certificates.',
    })
  } catch {
    return NextResponse.json({ error: 'Submission failed.' }, { status: 500 })
  }
}
