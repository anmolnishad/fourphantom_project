import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// Public certificate verification: GET ?certId=MH-XXXX-XXXX
export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url)
    const certId = (searchParams.get('certId') || '').trim().toUpperCase()
    if (!certId) return NextResponse.json({ status: 'INVALID', message: 'Certificate ID required.' }, { status: 400 })

    const cert = await db.certificate.findUnique({
      where: { certId },
      select: {
        id: true,
        certId: true, courseTitle: true, learnerName: true, score: true, percent: true,
        issuedAt: true, revoked: true, userId: true,
        user: { select: { name: true } },
      },
    })

    if (!cert) {
      return NextResponse.json({ status: 'INVALID', message: 'No certificate found with this ID on the Money Harvest registry.' })
    }
    if (cert.revoked) {
      return NextResponse.json({ status: 'REVOKED', message: 'This certificate has been revoked by the issuer.', certificate: { certId, courseTitle: cert.courseTitle } })
    }

    // Record the verification event (public verification page)
    await db.certificateVerification.create({ data: { certificateId: cert.id } })
    const timesVerified = await db.certificateVerification.count({ where: { certificateId: cert.id } })

    return NextResponse.json({
      status: 'VALID',
      message: 'This certificate is genuine and currently valid.',
      certificate: {
        certId: cert.certId,
        learnerName: cert.learnerName,
        courseTitle: cert.courseTitle,
        percent: cert.percent,
        score: cert.score,
        issuedAt: cert.issuedAt,
        timesVerified,
      },
      issuer: 'Money Harvest — platform-issued educational completion certificate (not a government or university-accredited qualification).',
    })
  } catch (e) {
    console.error('verify error:', e instanceof Error ? e.message : e)
    return NextResponse.json({ status: 'INVALID', message: 'Verification failed.' }, { status: 500 })
  }
}
