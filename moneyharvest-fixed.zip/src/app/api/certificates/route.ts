import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getAuthUser } from '@/lib/auth'
import { certCourses } from '@/lib/content/certCourses'

function makeCertId(): string {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'
  const part = (n: number) => Array.from({ length: n }, () => chars[Math.floor(Math.random() * chars.length)]).join('')
  return `MH-${part(4)}-${part(4)}`
}

// GET: list my certificates + eligibility for each course
export async function GET(req: NextRequest) {
  const user = await getAuthUser(req)
  if (!user) return NextResponse.json({ certificates: [], eligibility: [] })

  const certificates = await db.certificate.findMany({
    where: { userId: user.id },
    orderBy: { issuedAt: 'desc' },
  })

  const attempts = await db.quizAttempt.findMany({
    where: { userId: user.id, passed: true },
    orderBy: { percent: 'desc' },
  })

  const eligibility = certCourses.map((course) => {
    const best = attempts
      .filter((a) => a.category === course.quizCategory)
      .reduce((max, a) => Math.max(max, a.percent), 0)
    const alreadyHeld = certificates.some((c) => c.courseKey === course.key && !c.revoked)
    return {
      courseKey: course.key,
      title: course.title,
      requiredPercent: course.passPercent,
      quizCategory: course.quizCategory,
      bestPercent: best,
      eligible: !alreadyHeld && best >= course.passPercent,
      alreadyHeld,
    }
  })

  return NextResponse.json({ certificates, eligibility })
}

// POST: claim a certificate (server re-verifies eligibility from DB records)
export async function POST(req: NextRequest) {
  const user = await getAuthUser(req)
  if (!user) return NextResponse.json({ error: 'Sign in to claim certificates.' }, { status: 401 })
  try {
    const body = await req.json()
    const course = certCourses.find((c) => c.key === String(body.courseKey || ''))
    if (!course) return NextResponse.json({ error: 'Unknown course.' }, { status: 400 })

    const existing = await db.certificate.findFirst({ where: { userId: user.id, courseKey: course.key, revoked: false } })
    if (existing) return NextResponse.json({ error: 'You already hold this certificate.' }, { status: 409 })

    // Re-verify: a passing attempt at required threshold must exist in DB
    const bestAttempt = await db.quizAttempt.findFirst({
      where: { userId: user.id, category: course.quizCategory, percent: { gte: course.passPercent } },
      orderBy: { percent: 'desc' },
    })
    if (!bestAttempt) {
      return NextResponse.json({ error: `Not eligible yet. Pass the ${course.quizCategory.replace('-', ' ')} quiz with at least ${course.passPercent}% first.` }, { status: 403 })
    }

    let certId = makeCertId()
    for (let i = 0; i < 5; i++) {
      const clash = await db.certificate.findUnique({ where: { certId } })
      if (!clash) break
      certId = makeCertId()
    }

    const certificate = await db.certificate.create({
      data: {
        certId,
        userId: user.id,
        courseKey: course.key,
        courseTitle: course.title,
        learnerName: user.name,
        score: bestAttempt.score,
        percent: bestAttempt.percent,
      },
    })

    await db.notification.create({
      data: {
        userId: user.id,
        title: 'Certificate earned',
        body: `Congratulations! Your "${course.title}" certificate (ID ${certId}) is ready to download and share.`,
        kind: 'success',
        link: '#/certificates',
      },
    })

    return NextResponse.json({ certificate })
  } catch {
    return NextResponse.json({ error: 'Certificate claim failed.' }, { status: 500 })
  }
}
