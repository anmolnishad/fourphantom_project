import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getAuthUser } from '@/lib/auth'
import { rateLimit, getClientIp } from '@/lib/rateLimit'
import { runScamScan } from '@/lib/scamEngine'

const ALLOWED_TYPES = ['message', 'url', 'payment', 'ad', 'description']

export async function POST(req: NextRequest) {
  const ip = getClientIp(req)
  const rl = rateLimit(`scan:${ip}`, 20, 10 * 60 * 1000)
  if (!rl.allowed) return NextResponse.json({ error: `Scan limit reached. Try again in ${rl.retryAfterSec}s.` }, { status: 429 })

  try {
    const body = await req.json()
    const content = String(body.content || '').trim()
    const inputType = ALLOWED_TYPES.includes(body.inputType) ? body.inputType : 'message'
    if (content.length < 5) return NextResponse.json({ error: 'Please paste at least a few words to analyse.' }, { status: 400 })
    if (content.length > 6000) return NextResponse.json({ error: 'Text is too long (6000 character limit).' }, { status: 400 })

    const result = runScamScan(content, inputType)

    const user = await getAuthUser(req)
    if (user) {
      await db.scamScan.create({
        data: {
          userId: user.id,
          inputType,
          content: result.sanitizedContent.slice(0, 6000),
          riskLabel: result.riskLabel,
          riskScore: result.riskScore,
          findings: JSON.stringify(result.findings),
        },
      })
    }

    return NextResponse.json({ result, saved: !!user })
  } catch {
    return NextResponse.json({ error: 'Scan failed. Please try again.' }, { status: 500 })
  }
}
