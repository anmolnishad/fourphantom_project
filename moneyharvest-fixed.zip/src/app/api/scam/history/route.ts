import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getAuthUser } from '@/lib/auth'

export async function GET(req: NextRequest) {
  const user = await getAuthUser(req)
  if (!user) return NextResponse.json({ scans: [] })
  const scans = await db.scamScan.findMany({
    where: { userId: user.id },
    orderBy: { createdAt: 'desc' },
    take: 100,
  })
  return NextResponse.json({
    scans: scans.map((s) => ({
      id: s.id,
      inputType: s.inputType,
      content: s.content.slice(0, 300),
      riskLabel: s.riskLabel,
      riskScore: s.riskScore,
      findingsCount: JSON.parse(s.findings).length,
      createdAt: s.createdAt,
    })),
  })
}

// DELETE one scan (?id=) or clear all (?all=1) — strictly own records
export async function DELETE(req: NextRequest) {
  const user = await getAuthUser(req)
  if (!user) return NextResponse.json({ error: 'Sign in required.' }, { status: 401 })
  try {
    const { searchParams } = new URL(req.url)
    const id = searchParams.get('id')
    if (searchParams.get('all')) {
      await db.scamScan.deleteMany({ where: { userId: user.id } })
      return NextResponse.json({ ok: true, cleared: 'all' })
    }
    if (!id) return NextResponse.json({ error: 'Scan id required.' }, { status: 400 })
    const rec = await db.scamScan.findUnique({ where: { id } })
    if (!rec || rec.userId !== user.id) return NextResponse.json({ error: 'Scan not found.' }, { status: 404 })
    await db.scamScan.delete({ where: { id } })
    return NextResponse.json({ ok: true })
  } catch {
    return NextResponse.json({ error: 'Delete failed.' }, { status: 500 })
  }
}
