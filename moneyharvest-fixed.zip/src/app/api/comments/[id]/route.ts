import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getAuthUser } from '@/lib/auth'

// DELETE own comment
export async function DELETE(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const user = await getAuthUser(req)
  if (!user) return NextResponse.json({ error: 'Sign in required.' }, { status: 401 })
  try {
    const { id } = await params
    const comment = await db.comment.findUnique({ where: { id } })
    if (!comment) return NextResponse.json({ error: 'Comment not found.' }, { status: 404 })
    if (comment.userId !== user.id && user.role !== 'ADMIN') {
      return NextResponse.json({ error: 'You can only delete your own comments.' }, { status: 403 })
    }
    await db.comment.delete({ where: { id } })
    return NextResponse.json({ ok: true })
  } catch {
    return NextResponse.json({ error: 'Delete failed.' }, { status: 500 })
  }
}
