import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { calculatorRegistry } from '@/lib/calculators'
import { certCourses } from '@/lib/content/certCourses'
import { quizCategories } from '@/lib/content/quizBank'

interface ResultItem {
  type: 'lesson' | 'resource' | 'post' | 'calculator' | 'quiz' | 'certificate'
  title: string
  description: string
  link: string
  category?: string
}

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url)
    const q = (searchParams.get('q') || '').trim()
    const type = searchParams.get('type') || ''
    if (q.length < 2) return NextResponse.json({ results: [], message: 'Type at least 2 characters.' })

    const results: ResultItem[] = []
    const want = (t: string) => !type || type === t

    if (want('lesson')) {
      const lessons = await db.lesson.findMany({
        where: {
          published: true,
          OR: [{ title: { contains: q } }, { summary: { contains: q } }, { topic: { contains: q } }, { tags: { contains: q } }],
        },
        take: 8,
      })
      for (const l of lessons) {
        results.push({ type: 'lesson', title: l.title, description: l.summary, link: `#/lesson/${l.slug}`, category: l.category })
      }
    }

    if (want('resource')) {
      const resources = await db.educationalResource.findMany({
        where: { OR: [{ title: { contains: q } }, { description: { contains: q } }, { source: { contains: q } }] },
        take: 6,
      })
      for (const r of resources) {
        results.push({ type: 'resource', title: r.title, description: r.description, link: `#/resources`, category: r.category })
      }
    }

    if (want('post')) {
      const posts = await db.communityPost.findMany({ where: { content: { contains: q } }, orderBy: { createdAt: 'desc' }, take: 6 })
      for (const p of posts) {
        results.push({ type: 'post', title: `Community post`, description: p.content.slice(0, 140), link: '#/community' })
      }
    }

    if (want('calculator')) {
      for (const c of calculatorRegistry) {
        if ((c.title + ' ' + c.description).toLowerCase().includes(q.toLowerCase())) {
          results.push({ type: 'calculator', title: c.title, description: c.description, link: `#/calculators?tool=${c.key}` })
        }
      }
    }

    if (want('quiz')) {
      for (const qz of quizCategories) {
        if ((qz.title + ' ' + qz.description).toLowerCase().includes(q.toLowerCase())) {
          results.push({ type: 'quiz', title: `${qz.title} Quiz`, description: qz.description, link: `#/quiz?category=${qz.key}` })
        }
      }
    }

    if (want('certificate')) {
      for (const c of certCourses) {
        if ((c.title + ' ' + c.description).toLowerCase().includes(q.toLowerCase())) {
          results.push({ type: 'certificate', title: c.title, description: c.description, link: '#/certificates' })
        }
      }
    }

    return NextResponse.json({ results: results.slice(0, 30) })
  } catch {
    return NextResponse.json({ error: 'Search failed.' }, { status: 500 })
  }
}
