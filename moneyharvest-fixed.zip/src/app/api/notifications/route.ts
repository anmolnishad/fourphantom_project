import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getAuthUser } from '@/lib/auth'

export async function GET(req: NextRequest) {
  const user = await getAuthUser(req)
  if (!user) return NextResponse.json({ notifications: [], unread: 0 })
  const notifications = await db.notification.findMany({
    where: { userId: user.id },
    orderBy: { createdAt: 'desc' },
    take: 30,
  })
  return NextResponse.json({ notifications, unread: notifications.filter((n) => !n.read).length })
}

// POST: mark all read or one read { id }
export async function POST(req: NextRequest) {
  const user = await getAuthUser(req)
  if (!user) return NextResponse.json({ error: 'Sign in required.' }, { status: 401 })
  try {
    const body = await req.json().catch(() => ({}))
    if (body.id) {
      await db.notification.updateMany({ where: { id: String(body.id), userId: user.id }, data: { read: true } })
    } else {
      await db.notification.updateMany({ where: { userId: user.id, read: false }, data: { read: true } })
    }
    return NextResponse.json({ ok: true })
  } catch {
    return NextResponse.json({ error: 'Failed.' }, { status: 500 })
  }
}
