import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getAuthUser } from '@/lib/auth'

// Toggle lesson completion
export async function POST(req: NextRequest) {
  const user = await getAuthUser(req)
  if (!user) return NextResponse.json({ error: 'Sign in to track your progress.' }, { status: 401 })
  try {
    const body = await req.json()
    const slug = String(body.lessonSlug || '')
    const lesson = await db.lesson.findUnique({ where: { slug } })
    if (!lesson) return NextResponse.json({ error: 'Lesson not found.' }, { status: 404 })

    const existing = await db.lessonProgress.findUnique({
      where: { userId_lessonId: { userId: user.id, lessonId: lesson.id } },
    })

    const nowCompleted = !existing?.completed
    await db.lessonProgress.upsert({
      where: { userId_lessonId: { userId: user.id, lessonId: lesson.id } },
      create: { userId: user.id, lessonId: lesson.id, completed: nowCompleted, completedAt: nowCompleted ? new Date() : null },
      update: { completed: nowCompleted, completedAt: nowCompleted ? new Date() : null },
    })
    return NextResponse.json({ completed: nowCompleted })
  } catch {
    return NextResponse.json({ error: 'Failed to update progress.' }, { status: 500 })
  }
}
