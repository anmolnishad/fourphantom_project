import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { verifyPassword, signSession, SESSION_COOKIE } from '@/lib/auth'
import { rateLimit, getClientIp } from '@/lib/rateLimit'

export async function POST(req: NextRequest) {
  const ip = getClientIp(req)
  const rl = rateLimit(`login:${ip}`, 20, 15 * 60 * 1000)
  if (!rl.allowed) return NextResponse.json({ error: `Too many login attempts. Retry after ${rl.retryAfterSec}s.` }, { status: 429, headers: { 'Retry-After': String(rl.retryAfterSec) } })

  try {
    const body = await req.json()
    const email = String(body.email || '').trim().toLowerCase()
    const password = String(body.password || '')
    if (!email || !password) return NextResponse.json({ error: 'Email and password are required.' }, { status: 400 })

    const user = await db.user.findUnique({ where: { email } })
    if (!user) return NextResponse.json({ error: 'Invalid email or password.' }, { status: 401 })
    if (user.banned) return NextResponse.json({ error: 'This account has been suspended. Contact support.' }, { status: 403 })

    const ok = await verifyPassword(password, user.passwordHash)
    if (!ok) return NextResponse.json({ error: 'Invalid email or password.' }, { status: 401 })

    const token = await signSession({ userId: user.id, email: user.email, role: user.role })
    const res = NextResponse.json({ user: { id: user.id, email: user.email, name: user.name, role: user.role } })
    res.cookies.set(SESSION_COOKIE, token, { httpOnly: true, sameSite: 'lax', path: '/', maxAge: 60 * 60 * 24 * 7 })
    return res
  } catch {
    return NextResponse.json({ error: 'Sign-in failed. Please try again.' }, { status: 500 })
  }
}
