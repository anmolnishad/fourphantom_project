import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getAuthUser, hashPassword, verifyPassword, passwordProblem } from '@/lib/auth'

// Update profile (name, bio, avatarColor) and/or change password
export async function PATCH(req: NextRequest) {
  const user = await getAuthUser(req)
  if (!user) return NextResponse.json({ error: 'Please sign in.' }, { status: 401 })

  try {
    const body = await req.json()
    const data: Record<string, string> = {}

    if (typeof body.name === 'string') {
      const name = body.name.trim()
      if (name.length < 2 || name.length > 60) return NextResponse.json({ error: 'Name must be 2-60 characters.' }, { status: 400 })
      data.name = name
    }
    if (typeof body.bio === 'string') {
      if (body.bio.length > 300) return NextResponse.json({ error: 'Bio must be under 300 characters.' }, { status: 400 })
      data.bio = body.bio.trim()
    }
    if (typeof body.avatarColor === 'string' && /^#[0-9a-fA-F]{6}$/.test(body.avatarColor)) {
      data.avatarColor = body.avatarColor
    }

    if (body.newPassword) {
      const current = String(body.currentPassword || '')
      const rec = await db.user.findUnique({ where: { id: user.id } })
      if (!rec || !(await verifyPassword(current, rec.passwordHash))) {
        return NextResponse.json({ error: 'Current password is incorrect.' }, { status: 403 })
      }
      const problem = passwordProblem(String(body.newPassword))
      if (problem) return NextResponse.json({ error: problem }, { status: 400 })
      data.passwordHash = await hashPassword(String(body.newPassword))
    }

    const updated = await db.user.update({
      where: { id: user.id },
      data,
      select: { id: true, email: true, name: true, role: true, bio: true, avatarColor: true, createdAt: true },
    })
    return NextResponse.json({ user: updated })
  } catch {
    return NextResponse.json({ error: 'Update failed.' }, { status: 500 })
  }
}
