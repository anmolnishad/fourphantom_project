import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { hashPassword, passwordProblem, validateEmail } from '@/lib/auth'
import { rateLimit, getClientIp } from '@/lib/rateLimit'
import { randomBytes, createHash } from 'crypto'

// POST: request a password reset.
// The reset token is NEVER returned to the client in production. Until an email
// provider is wired (SES/SendGrid/SMTP), the token is only exposed when
// NODE_ENV !== 'production' AND ALLOW_DEV_RESET_TOKEN=true (local development only).
export async function POST(req: NextRequest) {
  const ip = getClientIp(req)
  const rl = rateLimit(`reset:${ip}`, 5, 60 * 60 * 1000)
  if (!rl.allowed) return NextResponse.json({ error: 'Too many reset requests. Try later.' }, { status: 429 })

  try {
    const body = await req.json()
    const email = String(body.email || '').trim().toLowerCase()
    if (!validateEmail(email)) return NextResponse.json({ error: 'Enter a valid email.' }, { status: 400 })

    const user = await db.user.findUnique({ where: { email } })
    // Always return ok to avoid account enumeration
    if (!user) return NextResponse.json({ ok: true, message: 'If an account exists for this email, a reset link has been generated.' })

    const token = randomBytes(32).toString('hex')
    await db.passwordResetToken.create({
      data: { token: createHash('sha256').update(token).digest('hex'), userId: user.id, expiresAt: new Date(Date.now() + 30 * 60 * 1000) },
    })

    const devMode = process.env.NODE_ENV !== 'production' && process.env.ALLOW_DEV_RESET_TOKEN === 'true'
    return NextResponse.json({
      ok: true,
      message: 'If an account exists for this email, a reset link has been sent.',
      ...(devMode
        ? { devResetToken: token, message: 'Development mode: use the one-time reset link below. It expires in 30 minutes.' }
        : {}),
    })
  } catch {
    return NextResponse.json({ error: 'Reset request failed.' }, { status: 500 })
  }
}

// PUT: confirm the reset with token + new password
export async function PUT(req: NextRequest) {
  try {
    const body = await req.json()
    const token = String(body.token || '')
    const password = String(body.password || '')
    const problem = passwordProblem(password)
    if (problem) return NextResponse.json({ error: problem }, { status: 400 })

    const hashed = createHash('sha256').update(token).digest('hex')
    const rec = await db.passwordResetToken.findUnique({ where: { token: hashed } })
    if (!rec || rec.usedAt || rec.expiresAt < new Date()) {
      return NextResponse.json({ error: 'This reset link is invalid or has expired. Request a new one.' }, { status: 400 })
    }
    await db.user.update({ where: { id: rec.userId }, data: { passwordHash: await hashPassword(password) } })
    await db.passwordResetToken.update({ where: { id: rec.id }, data: { usedAt: new Date() } })
    return NextResponse.json({ ok: true, message: 'Password updated. You can now sign in with your new password.' })
  } catch {
    return NextResponse.json({ error: 'Reset failed.' }, { status: 500 })
  }
}
