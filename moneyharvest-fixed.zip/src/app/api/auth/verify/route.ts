import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getAuthUser } from '@/lib/auth'

// Email verification — development mode.
// No email provider is configured, so verification is auto-completed when the
// signed-in user confirms their own address from the app. In production, send a
// signed verification link to the user's inbox instead.
export async function POST(req: NextRequest) {
  const user = await getAuthUser(req)
  if (!user) return NextResponse.json({ error: 'Please sign in.' }, { status: 401 })
  if (user.emailVerified) return NextResponse.json({ ok: true, message: 'Email already verified.' })
  await db.user.update({ where: { id: user.id }, data: { emailVerified: true } })
  return NextResponse.json({ ok: true, message: 'Email verified (development mode: no email provider configured).' })
}
