import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { hashPassword, validateEmail, passwordProblem, signSession, SESSION_COOKIE } from '@/lib/auth'
import { rateLimit, getClientIp } from '@/lib/rateLimit'

export async function POST(req: NextRequest) {
  const ip = getClientIp(req)
  const rl = rateLimit(`register:${ip}`, 10, 60 * 60 * 1000)
  if (!rl.allowed) return NextResponse.json({ error: 'Too many attempts. Try again later.' }, { status: 429 })

  try {
    const body = await req.json()
    const name = String(body.name || '').trim()
    const email = String(body.email || '').trim().toLowerCase()
    const password = String(body.password || '')

    if (name.length < 2 || name.length > 60) return NextResponse.json({ error: 'Please enter your full name (2-60 characters).' }, { status: 400 })
    if (!validateEmail(email)) return NextResponse.json({ error: 'Please enter a valid email address.' }, { status: 400 })
    const pwProblem = passwordProblem(password)
    if (pwProblem) return NextResponse.json({ error: pwProblem }, { status: 400 })

    const existing = await db.user.findUnique({ where: { email } })
    if (existing) return NextResponse.json({ error: 'An account with this email already exists. Try signing in.' }, { status: 409 })

    const passwordHash = await hashPassword(password)
    const user = await db.user.create({
      data: { name, email, passwordHash },
      select: { id: true, email: true, name: true, role: true },
    })

    await db.notification.create({
      data: {
        userId: user.id,
        title: 'Welcome to Money Harvest',
        body: 'Your learning journey begins here. Explore lessons, try calculators, and take your first quiz.',
        kind: 'success',
        link: '#/education',
      },
    })

    const token = await signSession({ userId: user.id, email: user.email, role: user.role })
    const res = NextResponse.json({ user })
    res.cookies.set(SESSION_COOKIE, token, { httpOnly: true, sameSite: 'lax', path: '/', maxAge: 60 * 60 * 24 * 7 })
    return res
  } catch {
    return NextResponse.json({ error: 'Registration failed. Please try again.' }, { status: 500 })
  }
}
