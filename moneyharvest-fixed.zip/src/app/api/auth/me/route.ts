import { NextRequest, NextResponse } from 'next/server'
import { getAuthUser } from '@/lib/auth'
import { db } from '@/lib/db'

export async function GET(req: NextRequest) {
  const user = await getAuthUser(req)
  if (!user) return NextResponse.json({ user: null }, { status: 200 })
  const unread = await db.notification.count({ where: { userId: user.id, read: false } })
  return NextResponse.json({ user, unreadNotifications: unread })
}
