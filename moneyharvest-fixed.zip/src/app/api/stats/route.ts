import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { calculatorRegistry } from '@/lib/calculators'

// Genuine platform content statistics only — no fabricated user numbers.
export async function GET() {
  try {
    const [lessons, questions, resources, posts, certificates] = await Promise.all([
      db.lesson.count({ where: { published: true } }),
      db.quizQuestion.count(),
      db.educationalResource.count(),
      db.communityPost.count(),
      db.certificate.count(),
    ])
    return NextResponse.json({
      lessons,
      questions,
      resources,
      posts,
      certificatesIssued: certificates,
      calculators: calculatorRegistry.length,
      statsBasis: 'Actual database record counts — updated live.',
    })
  } catch {
    return NextResponse.json({ lessons: 0, questions: 0, resources: 0, posts: 0, certificatesIssued: 0, calculators: calculatorRegistry.length, degraded: true })
  }
}
