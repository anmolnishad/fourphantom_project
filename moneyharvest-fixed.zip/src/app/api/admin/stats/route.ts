import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireAdmin } from '@/lib/auth'

export async function GET(req: NextRequest) {
  const admin = await requireAdmin(req)
  if (!admin) return NextResponse.json({ error: 'Admin access required.' }, { status: 403 })
  try {
    const [users, lessons, questions, posts, scans, certificates, reports, attempts, verifications] = await Promise.all([
      db.user.count(),
      db.lesson.count(),
      db.quizQuestion.count(),
      db.communityPost.count(),
      db.scamScan.count(),
      db.certificate.count({ where: { revoked: false } }),
      db.report.count({ where: { status: 'OPEN' } }),
      db.quizAttempt.count(),
      db.certificateVerification.count(),
    ])
    const recentUsers = await db.user.findMany({ orderBy: { createdAt: 'desc' }, take: 8, select: { id: true, name: true, email: true, role: true, createdAt: true, banned: true } })
    const categoryBreakdown = await db.communityPost.groupBy({
      by: ['category'],
      _count: { category: true },
    }).catch(() => []) as { category: string; _count: { category: number } }[]

    const attemptBreakdown = await db.quizAttempt.groupBy({
      by: ['category'],
      _count: { category: true },
      _avg: { percent: true },
    }).catch(() => [])

    return NextResponse.json({
      counts: { users, lessons, questions, posts, scans, certificates, openReports: reports, attempts, verifications },
      recentUsers,
      postCategoryBreakdown: categoryBreakdown,
      attemptBreakdown,
    })
  } catch {
    return NextResponse.json({ error: 'Failed to load stats.' }, { status: 500 })
  }
}
