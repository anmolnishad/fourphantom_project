import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireAdmin } from '@/lib/auth'

export async function GET(req: NextRequest) {
  const admin = await requireAdmin(req)
  if (!admin) return NextResponse.json({ error: 'Admin access required.' }, { status: 403 })
  try {
    const { searchParams } = new URL(req.url)
    const category = searchParams.get('category') || ''
    const questions = await db.quizQuestion.findMany({
      where: category ? { category } : {},
      orderBy: { createdAt: 'desc' },
      take: 200,
    })
    return NextResponse.json({
      questions: questions.map((q) => ({ ...q, options: JSON.parse(q.options) })),
    })
  } catch {
    return NextResponse.json({ error: 'Failed to load questions.' }, { status: 500 })
  }
}

export async function PATCH(req: NextRequest) {
  const admin = await requireAdmin(req)
  if (!admin) return NextResponse.json({ error: 'Admin access required.' }, { status: 403 })
  try {
    const body = await req.json()
    const id = String(body.id || '')
    const q = await db.quizQuestion.findUnique({ where: { id } })
    if (!q) return NextResponse.json({ error: 'Question not found.' }, { status: 404 })

    const data: Record<string, unknown> = {}
    if (body.question) data.question = String(body.question).trim()
    if (body.explanation !== undefined) data.explanation = String(body.explanation).trim()
    if (body.category) data.category = String(body.category)
    if (body.difficulty) data.difficulty = String(body.difficulty)
    if (Array.isArray(body.options) && body.options.length >= 2) {
      data.options = JSON.stringify(body.options.map((o: unknown) => String(o).slice(0, 200)))
    }
    if (body.correctIndex !== undefined) {
      const ci = Number(body.correctIndex)
      const optsCount = Array.isArray(body.options) ? body.options.length : JSON.parse(q.options).length
      if (!Number.isInteger(ci) || ci < 0 || ci >= optsCount) return NextResponse.json({ error: 'Invalid correct index.' }, { status: 400 })
      data.correctIndex = ci
    }
    const updated = await db.quizQuestion.update({ where: { id }, data })
    return NextResponse.json({ question: { ...updated, options: JSON.parse(updated.options) } })
  } catch {
    return NextResponse.json({ error: 'Update failed.' }, { status: 500 })
  }
}

export async function DELETE(req: NextRequest) {
  const admin = await requireAdmin(req)
  if (!admin) return NextResponse.json({ error: 'Admin access required.' }, { status: 403 })
  try {
    const { searchParams } = new URL(req.url)
    await db.quizQuestion.delete({ where: { id: searchParams.get('id') || '' } })
    return NextResponse.json({ ok: true })
  } catch {
    return NextResponse.json({ error: 'Delete failed.' }, { status: 500 })
  }
}
