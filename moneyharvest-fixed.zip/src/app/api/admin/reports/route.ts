import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireAdmin } from '@/lib/auth'

export async function GET(req: NextRequest) {
  const admin = await requireAdmin(req)
  if (!admin) return NextResponse.json({ error: 'Admin access required.' }, { status: 403 })
  try {
    const reports = await db.report.findMany({
      orderBy: [{ status: 'asc' }, { createdAt: 'desc' }],
      take: 100,
      include: {
        post: { select: { id: true, content: true, createdAt: true, user: { select: { name: true, email: true } } } },
        user: { select: { name: true } },
      },
    })
    return NextResponse.json({ reports })
  } catch {
    return NextResponse.json({ error: 'Failed to load reports.' }, { status: 500 })
  }
}

// PATCH { reportId, action: 'resolve' | 'dismiss', deletePost?: boolean }
export async function PATCH(req: NextRequest) {
  const admin = await requireAdmin(req)
  if (!admin) return NextResponse.json({ error: 'Admin access required.' }, { status: 403 })
  try {
    const body = await req.json()
    const report = await db.report.findUnique({ where: { id: String(body.reportId || '') } })
    if (!report) return NextResponse.json({ error: 'Report not found.' }, { status: 404 })

    const status = body.action === 'dismiss' ? 'DISMISSED' : 'RESOLVED'
    await db.report.update({ where: { id: report.id }, data: { status } })

    if (body.deletePost) {
      await db.communityPost.delete({ where: { id: report.postId } })
    }
    return NextResponse.json({ ok: true })
  } catch {
    return NextResponse.json({ error: 'Action failed.' }, { status: 500 })
  }
}
