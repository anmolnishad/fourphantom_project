import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { requireAdmin } from '@/lib/auth'

export async function GET(req: NextRequest) {
  const admin = await requireAdmin(req)
  if (!admin) return NextResponse.json({ error: 'Admin access required.' }, { status: 403 })
  try {
    const { searchParams } = new URL(req.url)
    const q = (searchParams.get('q') || '').trim()
    const users = await db.user.findMany({
      where: q ? { OR: [{ name: { contains: q } }, { email: { contains: q } }] } : {},
      orderBy: { createdAt: 'desc' },
      take: 100,
      select: { id: true, name: true, email: true, role: true, banned: true, emailVerified: true, createdAt: true },
    })
    return NextResponse.json({ users })
  } catch {
    return NextResponse.json({ error: 'Failed to load users.' }, { status: 500 })
  }
}

// PATCH { userId, action: 'ban' | 'unban' | 'promote' | 'demote' }
export async function PATCH(req: NextRequest) {
  const admin = await requireAdmin(req)
  if (!admin) return NextResponse.json({ error: 'Admin access required.' }, { status: 403 })
  try {
    const body = await req.json()
    const user = await db.user.findUnique({ where: { id: String(body.userId || '') } })
    if (!user) return NextResponse.json({ error: 'User not found.' }, { status: 404 })
    if (user.id === admin.id) return NextResponse.json({ error: 'You cannot modify your own account here.' }, { status: 400 })

    switch (body.action) {
      case 'ban':
        await db.user.update({ where: { id: user.id }, data: { banned: true } })
        break
      case 'unban':
        await db.user.update({ where: { id: user.id }, data: { banned: false } })
        break
      case 'promote':
        await db.user.update({ where: { id: user.id }, data: { role: 'ADMIN' } })
        break
      case 'demote':
        await db.user.update({ where: { id: user.id }, data: { role: 'USER' } })
        break
      default:
        return NextResponse.json({ error: 'Unknown action.' }, { status: 400 })
    }
    return NextResponse.json({ ok: true })
  } catch {
    return NextResponse.json({ error: 'Action failed.' }, { status: 500 })
  }
}
