'use client'

import { useEffect } from 'react'
import { AppProvider, useApp } from '@/components/mh/store'
import { useRoute, navigate } from '@/components/mh/router'
import { Nav } from '@/components/mh/Nav'
import { Footer } from '@/components/mh/Footer'
import { HarvestAI } from '@/components/mh/HarvestAI'
import { useAiWidgetVisible } from '@/components/mh/navTools'
import { Home } from '@/components/mh/views/Home'
import { EducationHub, LessonDetail } from '@/components/mh/views/Education'
import { Calculators } from '@/components/mh/views/Calculators'
import { Scam } from '@/components/mh/views/Scam'
import { Quiz } from '@/components/mh/views/Quiz'
import { Certificates, VerifyPage } from '@/components/mh/views/Certificates'
import { Community } from '@/components/mh/views/Community'
import { Resources } from '@/components/mh/views/Resources'
import { Cyber } from '@/components/mh/views/Cyber'
import { SignIn, SignUp, Forgot } from '@/components/mh/views/Auth'
import { Dashboard } from '@/components/mh/views/Dashboard'
import { Admin } from '@/components/mh/views/Admin'
import { SearchResults } from '@/components/mh/views/SearchResults'
import { Settings } from '@/components/mh/views/Settings'
import { AiPage } from '@/components/mh/views/AiPage'
import { Privacy, Terms, Disclaimer, Contact } from '@/components/mh/views/Legal'
import { Button } from '@/components/ui/button'
import { Compass } from 'lucide-react'

function View() {
  const route = useRoute()
  const { userLoaded } = useApp()
  const [head, second] = route.parts

  // default hash to #/ so back/forward behave consistently
  useEffect(() => {
    if (!window.location.hash) navigate('/', { replace: true })
  }, [])

  if (!userLoaded) {
    return (
      <div className="min-h-[60vh] flex items-center justify-center">
        <div className="flex flex-col items-center gap-3">
          <span className="h-10 w-10 rounded-full border-[3px] border-[#CCD5AE] border-t-[#8F6B44] animate-spin" aria-label="Loading" />
          <p className="text-sm text-[#8B8F6E] font-semibold">Loading Money Harvest…</p>
        </div>
      </div>
    )
  }

  let content: React.ReactNode
  switch (head) {
    case undefined:
    case '':
      content = <Home />
      break
    case 'education':
      content = <EducationHub initialCat={route.query.get('cat') || undefined} />
      break
    case 'lesson':
      content = second ? <LessonDetail slug={second} /> : <EducationHub />
      break
    case 'calculators':
      content = <Calculators />
      break
    case 'scam':
      content = <Scam />
      break
    case 'quiz':
      content = <Quiz />
      break
    case 'certificates':
      content = <Certificates />
      break
    case 'verify':
      content = second ? <VerifyPage certId={second.toUpperCase()} /> : <Certificates />
      break
    case 'community':
      content = <Community />
      break
    case 'resources':
      content = <Resources />
      break
    case 'cyber':
      content = <Cyber />
      break
    case 'ai':
      content = <AiPage />
      break
    case 'signin':
      content = <SignIn />
      break
    case 'signup':
      content = <SignUp />
      break
    case 'forgot':
      content = <Forgot />
      break
    case 'dashboard':
      content = <Dashboard />
      break
    case 'admin':
      content = <Admin />
      break
    case 'search':
      content = <SearchResults />
      break
    case 'settings':
      content = <Settings />
      break
    case 'privacy':
      content = <Privacy />
      break
    case 'terms':
      content = <Terms />
      break
    case 'disclaimer':
      content = <Disclaimer />
      break
    case 'contact':
      content = <Contact />
      break
    default:
      content = (
        <div className="mx-auto max-w-lg px-4 py-28 text-center view-enter">
          <Compass className="h-12 w-12 mx-auto text-[#D8D2B4] mb-4" />
          <h1 className="font-display text-3xl font-semibold text-[#2F3625]">Page not found</h1>
          <p className="text-sm text-[#6B7052] mt-2">The path <code className="font-mono bg-[#F4F0DB] px-1.5 py-0.5 rounded">#{route.path}</code> doesn’t exist on Money Harvest.</p>
          <Button className="btn-bronze mt-6 font-semibold" onClick={() => navigate('/')}>Back to Home</Button>
        </div>
      )
  }

  return <main className="flex-1">{content}</main>
}

function Shell() {
  const showAi = useAiWidgetVisible()
  return (
    <div className="min-h-screen flex flex-col bg-[#FEFAE0]">
      <Nav />
      <View />
      <Footer />
      {showAi && <HarvestAI />}
    </div>
  )
}

export default function Page() {
  return (
    <AppProvider>
      <Shell />
    </AppProvider>
  )
}
