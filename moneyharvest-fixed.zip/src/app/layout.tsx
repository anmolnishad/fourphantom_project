import type { Metadata, Viewport } from "next";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

export const metadata: Metadata = {
  title: "Money Harvest — Grow Your Financial Intelligence",
  description:
    "Learn smarter money management, detect scams, use financial calculators, and build lasting financial confidence with Money Harvest's education platform.",
  keywords: ["financial literacy", "money education", "scam detector", "SIP calculator", "cybersecurity", "personal finance"],
  authors: [{ name: "Money Harvest" }],
  icons: { icon: "/icon.svg" },
  openGraph: {
    title: "Money Harvest — Grow Your Financial Intelligence",
    description:
      "Learn smarter money management, detect scams, use financial calculators, and build lasting financial confidence.",
    siteName: "Money Harvest",
    type: "website",
  },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  themeColor: "#FEFAE0",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className="antialiased bg-background text-foreground min-h-screen flex flex-col">
        {children}
        <Toaster />
      </body>
    </html>
  );
}
