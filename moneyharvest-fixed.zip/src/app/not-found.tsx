import Link from 'next/link'

export default function NotFound() {
  return (
    <main className="flex-1 flex items-center justify-center px-4 py-28 text-center">
      <div>
        <h1 className="font-display text-3xl font-semibold text-[#2F3625]">Page not found</h1>
        <p className="text-sm text-[#6B7052] mt-2">This page doesn’t exist on Money Harvest.</p>
        <Link href="/" className="inline-block mt-6 underline font-semibold text-[#8F6B44]">Back to Home</Link>
      </div>
    </main>
  )
}
