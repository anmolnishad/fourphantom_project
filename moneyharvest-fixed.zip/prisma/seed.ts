import { randomBytes } from 'crypto'
const ADMIN_PASSWORD = process.env.SEED_ADMIN_PASSWORD || randomBytes(12).toString('base64url')
const DEMO_PASSWORD = process.env.SEED_DEMO_PASSWORD || randomBytes(12).toString('base64url')
// Money Harvest — database seed script
// Run: bun prisma/seed.ts
import { PrismaClient } from '@prisma/client'
import bcrypt from 'bcryptjs'
import { allLessons } from '../src/lib/content/lessons'
import { quizBank } from '../src/lib/content/quizBank'
import { resourceSeeds } from '../src/lib/content/resources'

const hashPassword = (pw: string) => bcrypt.hash(pw, 12)
const db = new PrismaClient()

async function main() {
  console.log('Seeding Money Harvest database...')

  // ---- Admin & demo users ----
  const adminEmail = 'admin@moneyharvest.app'
  const adminExists = await db.user.findUnique({ where: { email: adminEmail } })
  let adminId: string
  if (adminExists) {
    adminId = adminExists.id
    console.log('Admin already exists, skipping.')
  } else {
    const admin = await db.user.create({
      data: {
        email: adminEmail,
        passwordHash: await hashPassword(ADMIN_PASSWORD),
        name: 'Money Harvest Team',
        role: 'ADMIN',
        emailVerified: true,
        bio: 'Official Money Harvest education account. We share learning tips only — never investment advice.',
        avatarColor: '#8F9779',
      },
    })
    adminId = admin.id
    console.log('Admin user created:', adminEmail, process.env.SEED_ADMIN_PASSWORD ? '(password from SEED_ADMIN_PASSWORD)' : '(generated password: ' + ADMIN_PASSWORD + ')')
  }

  const demoEmail = 'demo@moneyharvest.app'
  const demoExists = await db.user.findUnique({ where: { email: demoEmail } })
  let demoId: string
  if (demoExists) {
    demoId = demoExists.id
  } else {
    const demo = await db.user.create({
      data: {
        email: demoEmail,
        passwordHash: await hashPassword(DEMO_PASSWORD),
        name: 'Demo Learner',
        emailVerified: true,
        bio: 'Exploring Money Harvest, one lesson at a time.',
        avatarColor: '#D4A373',
      },
    })
    demoId = demo.id
    console.log('Demo user created:', demoEmail, process.env.SEED_DEMO_PASSWORD ? '(password from SEED_DEMO_PASSWORD)' : '(generated password: ' + DEMO_PASSWORD + ')')
  }

  // ---- Lessons ----
  let lessonOrder = 0
  for (const l of allLessons) {
    const exists = await db.lesson.findUnique({ where: { slug: l.slug } })
    if (exists) continue
    await db.lesson.create({
      data: {
        slug: l.slug,
        category: l.category,
        topic: l.topic,
        title: l.title,
        summary: l.summary,
        content: JSON.stringify({ ...l.content, related: l.related }),
        level: l.level,
        readMinutes: l.readMinutes,
        tags: JSON.stringify(l.tags),
        order: lessonOrder++,
      },
    })
  }
  console.log(`Lessons ensured: ${allLessons.length}`)

  // ---- Quiz questions ----
  const questionCount = await db.quizQuestion.count()
  if (questionCount === 0) {
    for (const q of quizBank) {
      await db.quizQuestion.create({
        data: {
          category: q.category,
          difficulty: q.difficulty,
          question: q.question,
          options: JSON.stringify(q.options),
          correctIndex: q.correctIndex,
          explanation: q.explanation,
        },
      })
    }
    console.log(`Quiz questions seeded: ${quizBank.length}`)
  } else {
    console.log(`Quiz questions already present: ${questionCount}`)
  }

  // ---- Resources ----
  const resourceCount = await db.educationalResource.count()
  if (resourceCount === 0) {
    for (const r of resourceSeeds) {
      await db.educationalResource.create({ data: r })
    }
    console.log(`Resources seeded: ${resourceSeeds.length}`)
  } else {
    console.log(`Resources already present: ${resourceCount}`)
  }

  // ---- Sample community posts (from official team account, honest labels) ----
  const postCount = await db.communityPost.count()
  if (postCount === 0) {
    await db.communityPost.create({
      data: {
        userId: adminId,
        category: 'saving-tips',
        content: 'Welcome to the Money Harvest community! 🌱\n\nHouse rule: we share educational tips and questions only — never investment advice, never "guaranteed returns", and never links asking for OTPs or payments.\n\nTip to start: automate your savings on salary day. Money you never see is money you never miss.',
      },
    })
    await db.communityPost.create({
      data: {
        userId: adminId,
        category: 'cybersecurity',
        content: 'Reminder: No bank, regulator, or genuine platform will EVER ask for your OTP, PIN, password, or CVV — not to "verify KYC", not to "stop a fraud transaction", not for any reason.\n\nIf a caller asks for these, they are a fraudster. Hang up and call the number printed on your card.\n\nReport fraudulent messages via Chakshu: sancharsaathi.gov.in. Financial fraud helpline: 1930.',
      },
    })
    await db.communityPost.create({
      data: {
        userId: demoId,
        category: 'learning-achievements',
        content: 'Just finished the "Compound Interest: The Eighth Wonder" lesson and the Rule of 72 finally makes sense! 72 ÷ 9 = 8 years to double. Small start, long runway — beginning my first SIP this month using the SIP calculator here.',
      },
    })
    console.log('Sample community posts seeded: 3')
  }

  console.log('Seed complete.')
}

main()
  .catch((e) => {
    console.error(e)
    process.exit(1)
  })
  .finally(async () => {
    await db.$disconnect()
  })
