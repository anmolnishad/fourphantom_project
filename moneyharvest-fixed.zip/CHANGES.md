# Money Harvest — fixes applied

## Security
- `src/app/api/auth/reset/route.ts`: reset token is no longer returned to the browser in production. Only returned when `NODE_ENV !== 'production'` AND `ALLOW_DEV_RESET_TOKEN=true`.
- `src/components/mh/views/Auth.tsx`: demo/admin credentials removed from the public sign-in page.
- `src/lib/auth.ts`: app refuses to start in production without `AUTH_SECRET` (no public fallback secret).
- `prisma/seed.ts`: seed passwords come from `SEED_ADMIN_PASSWORD` / `SEED_DEMO_PASSWORD`, or are generated and printed once.
- `.env` untracked from git (kept locally). `.env.example` added.

## Missing pages & content
- New `src/components/mh/views/Legal.tsx`: Privacy Policy, Terms of Use, Disclaimer, Contact & Grievance (routes `#/privacy`, `#/terms`, `#/disclaimer`, `#/contact`).
- Footer: legal links added; "Cybersecurity Hub" now points to `#/cyber` (same as nav).
- `src/app/not-found.tsx` (404) and `src/app/icon.svg` (favicon) added.
- `src/app/layout.tsx`: Open Graph metadata and icon.

## Before going live (you must do)
- Set `NEXT_PUBLIC_CONTACT_EMAIL` and `NEXT_PUBLIC_GRIEVANCE_OFFICER`. Placeholders are shown until set.
- Have the Privacy Policy and Terms reviewed by a lawyer (drafted as a starting point, not legal advice).
- Set `AUTH_SECRET` to a long random value.
- Wire an email provider for password reset. Until then, reset emails are not sent, so users cannot reset passwords in production.
- Change the admin password if the old `Harvest@2025` was ever used.
