// One-off helper: create a passing quiz attempt for the demo user (certificate flow test)
import { PrismaClient } from '@prisma/client'
const db = new PrismaClient()

async function main() {
  const user = await db.user.findUnique({ where: { email: 'demo@moneyharvest.app' } })
  if (!user) throw new Error('demo user missing')

  const questions = await db.quizQuestion.findMany({ where: { category: 'personal-finance' } })
  const answers = questions.map((q) => ({ questionId: q.id, chosen: q.correctIndex }))

  const res = await fetch('http://localhost:3000/api/quiz/submit', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Cookie: process.env.DEMO_COOKIE || '' },
    body: JSON.stringify({ category: 'personal-finance', difficulty: 'intermediate', timeTakenSec: 300, answers }),
  })
  const data = await res.json()
  console.log('submit status:', res.status, 'percent:', data.percent, 'passed:', data.passed)
}

main().finally(() => db.$disconnect())
